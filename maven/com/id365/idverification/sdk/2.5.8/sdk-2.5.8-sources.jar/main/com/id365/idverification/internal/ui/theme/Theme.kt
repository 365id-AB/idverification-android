package com.id365.idverification.internal.ui.theme

import androidx.annotation.Keep
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.Text
import androidx.compose.material3.contentColorFor
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

internal val lightColorPalette: ColorScheme = lightColorScheme().copy(
    // Primary
    primary = AppColors.purple,
    onPrimary = AppColors.white,
    primaryContainer = AppColors.lightPurple,
    onPrimaryContainer = AppColors.darkGray,
    inversePrimary = AppColors.lightPurple,

    // Secondary
    secondary = AppColors.gray,
    onSecondary = AppColors.white,
    secondaryContainer = AppColors.lightGray,
    onSecondaryContainer = AppColors.darkGray,

    // Tertiary
    tertiary = AppColors.purple,
    onTertiary = AppColors.white,
    tertiaryContainer = AppColors.lightPurple,
    onTertiaryContainer = AppColors.white,
    background = AppColors.white, // UNUSED
    onBackground = AppColors.black, // UNUSED

    // Surface
    surface = AppColors.white,
    onSurface = AppColors.black,
    surfaceVariant = AppColors.lightGray,
    // surfaceTint = Color.Magenta, // UNUSED
    onSurfaceVariant = AppColors.darkGray,
    inverseSurface = AppColors.black,
    inverseOnSurface = AppColors.white,

    // Surface for Containers
    surfaceContainer = AppColors.lightBlue,

    // Error
    // error = Color.Red,
    // onError = Color.White,
    // errorContainer = Color(0xffbb3333),
    // onErrorContainer = Color(0xff330000),

    // outline = Color.Magenta, // UNUSED
    // outlineVariant = Color.Magenta, // UNUSED
    // scrim = Color.Magenta, // UNUSED
)

/**
 * Default Material Design Theme provided by 365ID. This will be used
 * if launching a ScannerSdkActivity. Otherwise, you can set your own
 * theme when including the IdVerificationView directly.
 * The IdVerificationView should *not* be used without a Material Design theme.
 */
@Keep
@Composable
fun Id365ScannerSdkTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit)
{
    MaterialTheme(
        colorScheme = lightColorPalette,
        typography = Typography,
        shapes = Shapes,
        content = content
    )
}

@Preview
@Composable
private fun Id365ScannerSdkThemePreview() {
    val colors = sequenceOf(
        Pair("primary", lightColorPalette.primary),
        Pair("onPrimary", lightColorPalette.onPrimary),
        Pair("primaryContainer", lightColorPalette.primaryContainer),
        Pair("onPrimaryContainer", lightColorPalette.onPrimaryContainer),
        Pair("inversePrimary", lightColorPalette.inversePrimary),
        Pair("secondary", lightColorPalette.secondary),
        Pair("onSecondary", lightColorPalette.onSecondary),
        Pair("secondaryContainer", lightColorPalette.secondaryContainer),
        Pair("onSecondaryContainer", lightColorPalette.onSecondaryContainer),
        Pair("tertiary", lightColorPalette.tertiary),
        Pair("onTertiary", lightColorPalette.onTertiary),
        Pair("tertiaryContainer", lightColorPalette.tertiaryContainer),
        Pair("onTertiaryContainer", lightColorPalette.onTertiaryContainer),
        Pair("background", lightColorPalette.background),
        Pair("onBackground", lightColorPalette.onBackground),
        Pair("surface", lightColorPalette.surface),
        Pair("onSurface", lightColorPalette.onSurface),
        Pair("surfaceVariant", lightColorPalette.surfaceVariant),
        Pair("surfaceTint", lightColorPalette.surfaceTint),
        Pair("onSurfaceVariant", lightColorPalette.onSurfaceVariant),
        Pair("inverseSurface", lightColorPalette.inverseSurface),
        Pair("inverseOnSurface", lightColorPalette.inverseOnSurface),
        Pair("error", lightColorPalette.error),
        Pair("onError", lightColorPalette.onError),
        Pair("errorContainer", lightColorPalette.errorContainer),
        Pair("onErrorContainer", lightColorPalette.onErrorContainer),
        Pair("outline", lightColorPalette.outline),
        Pair("outlineVariant", lightColorPalette.outlineVariant),
        Pair("inverseSurface", lightColorPalette.inverseSurface),
        Pair("inverseOnSurface", lightColorPalette.inverseOnSurface),
        Pair("surfaceContainer", lightColorPalette.surfaceContainer),
        Pair("scrim", lightColorPalette.scrim),
    )
    Id365ScannerSdkTheme {
        Column {
            for (c in colors) {
                Text(text = c.first,
                    modifier = Modifier
                        .height(20.dp)
                        .fillMaxWidth()
                        .background(color=c.second),
                    color = MaterialTheme.colorScheme.contentColorFor(c.second))
            }
        }
    }
}


@Preview
@Composable
private fun Id365ScannerSdkThemePreview2() {
    val colors = sequenceOf(
        Triple("primary", lightColorPalette.onPrimary, lightColorPalette.primary),
        Triple("primaryContainer", lightColorPalette.onPrimaryContainer, lightColorPalette.primaryContainer),
        Triple("secondary", lightColorPalette.onSecondary, lightColorPalette.secondary),
        Triple("secondaryContainer", lightColorPalette.onSecondaryContainer, lightColorPalette.secondaryContainer),
        Triple("tertiary", lightColorPalette.onTertiary, lightColorPalette.tertiary),
        Triple("tertiaryContainer", lightColorPalette.onTertiaryContainer, lightColorPalette.tertiaryContainer),
        Triple("error", lightColorPalette.onError, lightColorPalette.error),
        Triple("errorContainer", lightColorPalette.onErrorContainer, lightColorPalette.errorContainer),
        Triple("surface", lightColorPalette.onSurface, lightColorPalette.surface),
        Triple("surfaceVariant", lightColorPalette.surfaceVariant, lightColorPalette.onSurfaceVariant),
        Triple("background", lightColorPalette.onBackground, lightColorPalette.background),
    )
    Id365ScannerSdkTheme {
        Column {
            for (c in colors) {
                Text(text = c.first,
                    modifier = Modifier
                        .height(20.dp)
                        .fillMaxWidth()
                        .background(color=c.third),
                    color = c.second)
            }
        }
    }
}