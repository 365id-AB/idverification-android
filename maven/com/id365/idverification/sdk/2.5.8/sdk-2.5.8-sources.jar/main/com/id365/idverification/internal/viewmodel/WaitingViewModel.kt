package com.id365.idverification.internal.viewmodel

import android.content.Context
import com.id365.idverification.internal.communication.AbortReason
import com.id365.idverification.internal.core.IdScannerKoinComponent
import com.id365.idverification.internal.core.SdkContext
import com.id365.idverification.internal.model.ITransactionModel
import org.koin.core.component.inject

internal class WaitingViewModel(
    val context: Context
) : IWaitingViewModel, IdScannerKoinComponent() {
    private val transactionModel: ITransactionModel by inject()

    /** Run the transaction callback with an empty response when user quits early */
    override val cancelButtonCallback: () -> Unit = {
        SdkContext.abortJob = transactionModel.abortTransactionRequest(AbortReason.UserCancelled)
        SdkContext.eventHandler.onUserDismissed()
    }
}