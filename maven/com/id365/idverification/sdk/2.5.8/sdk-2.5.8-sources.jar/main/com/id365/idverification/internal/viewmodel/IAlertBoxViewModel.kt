package com.id365.idverification.internal.viewmodel

import androidx.compose.runtime.MutableState
import androidx.lifecycle.MutableLiveData

/**
 * Interface describing an AlertBoxViewModel to the AlertBoxView.
 */
internal interface IAlertBoxViewModel {

    /**
     * True if luminance is OK. An extra conditional to control visibility of scan button
     */
    val luminanceIsAcceptable: MutableState<Boolean>

    /**
     * Control visibility of the Alert box
     */
    val visible: MutableLiveData<Boolean>

    /**
     * Control visibility of the button
     */
    val buttonVisible: MutableLiveData<Boolean>

    /**
     * Set the text that should be drawn inside the AlertBox
     */
    fun setText(caption: String?, details: String?)

    /**
     * Set the progress in a range of 0-1 that the progress bar should show
     */
    fun setProgress(progress: Float?)

    /**
     * Hide the alert box and unset the caption + details
     */
    fun hide()

    /**
     * Caption for the Alert box
     */
    val caption: MutableState<String>

    /**
     * Detailed text for the Alert box
     */
    val details: MutableState<String>

    /**
     * Show a progress bar if not null,
     * filled to value where 0 = empty and 1 = full
     */
    val progress: MutableState<Float?>

    /**
     * Sets button label and callback. Incidentally also brings it into view.
     */
    fun setButton(label: String, callback: () -> Unit)

    /**
     * Hide the button, clearing the label and registered callback
     */
    fun hideButton()

    /**
     * Tells the view whether the button should be "enabled" or not
     */
    val buttonEnabled: MutableState<Boolean>

    /**
     * Text to show on the button when visible
     */
    val buttonLabel: MutableState<String>

    /**
     * The function to call when user presses the button
     */
    val buttonCallback: MutableState<() -> Unit>
}
