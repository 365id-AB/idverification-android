package com.id365.idverification

import androidx.annotation.Keep

/**
 * Enumeration of Facematch feedback
 */
@Keep
enum class FacematchFeedback {
    Undefined,
    /** User aborted the facematch */
    Aborted,
    /** Facematch completed and the face matched */
    Matched,
    /** Facematch completed, but the face did NOT match */
    NoMatch
}

/**
 * Enumeration of the facematch source used
 */
@Keep
enum class FacematchSource {
    Undefined,
    /** The source used was from the NFC chip */
    Nfc,
    /** The source used was the image from the front of the document */
    Document,
    /** There was no match performed */
    None
}
