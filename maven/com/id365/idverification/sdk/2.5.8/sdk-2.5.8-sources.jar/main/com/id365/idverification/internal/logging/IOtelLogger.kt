package com.id365.idverification.internal.logging

interface IOtelLogger {
    fun log(tag: String, message: String, transactionId: String?, severity: Int)
}