package com.id365.idverification.internal.communication

/**
 * This is the UserMessage type as defined by the Coordinator Contract.
 * We translate the type used for transport into this type to ensure we can
 * use it in a portable way across platforms.
 */
internal data class UserMessage(
    val title: String = "",
    val subtitle: String = "",
    val level: Level,
) {
    constructor(
        title: String = "", subtitle: String = "", level: String = ""
    ) : this(title = title, subtitle = subtitle, level = mapping.getOrDefault(level, Level.UNDEFINED))

    enum class Level {
        UNDEFINED,
        WAIT,
        INFORMATION,
        SUCCESS,
        WARNING,
        ERROR,
    }

    companion object {
        private val mapping = mapOf(
            "UNDEFINED" to Level.UNDEFINED,
            "WAIT" to Level.WAIT,
            "INFORMATION" to Level.INFORMATION,
            "SUCCESS" to Level.SUCCESS,
            "WARNING" to Level.WARNING,
            "ERROR" to Level.ERROR,
        )
    }
}