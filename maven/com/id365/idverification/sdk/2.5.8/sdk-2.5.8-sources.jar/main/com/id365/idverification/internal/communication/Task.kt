package com.id365.idverification.internal.communication

/**
 * This is the Task type as defined by the Coordinator Contract.
 * We translate the type used for transport into this type to ensure portability between
 * platforms
 */
internal data class Task(
    val state: String = "",
    val token: String = "",
    val message: UserMessage,
    val nextTask: Level,
    val taskPayload: String = "",
    val clientPayload: String = "",
    val taskCountEstimate: Int = 0,
    val taskCountCurrent: Int = 0,
    val feedback: Feedback = Feedback(),
) {

    constructor(
        state: String = "",
        token: String = "",
        message: UserMessage = UserMessage(),
        nextTask: String = "",
        taskPayload: String = "",
        clientPayload: String = "",
        taskCountEstimate: Int = 0,
        taskCountCurrent: Int = 0,
        feedback: Feedback = Feedback(),
    ) : this(
        state = state,
        token = token,
        message = message,
        nextTask = mapping.getOrDefault(nextTask, Level.UNDEFINED),
        taskPayload = taskPayload,
        clientPayload = clientPayload,
        taskCountEstimate = taskCountEstimate,
        taskCountCurrent = taskCountCurrent,
        feedback = feedback,
    )


    enum class Level {
        UNDEFINED,
        WAIT,
        FRONT_SIDE,
        BACK_SIDE,
        NFC,
        FINISHED_SUCCESSFULLY,
        FINISHED_BUT_FAILED,
        IPROOV,
        NO_ACTIVE_PACKAGE,
        INVALID_VERSION,
        WAIT_DOCUMENT,
        WAIT_NFC,
        WAIT_IPROOV,
        ODD_SIZE_IMAGE_CAPTURE
    }

    companion object {
        private val mapping = mapOf(
            "UNDEFINED" to Level.UNDEFINED,
            "WAIT" to Level.WAIT,
            "FRONT_SIDE" to Level.FRONT_SIDE,
            "BACK_SIDE" to Level.BACK_SIDE,
            "NFC" to Level.NFC,
            "FACE_RECOGNITION" to Level.UNDEFINED,
            "LIVENESS" to Level.UNDEFINED,
            "FINISHED_SUCCESSFULLY" to Level.FINISHED_SUCCESSFULLY,
            "FINISHED_BUT_FAILED" to Level.FINISHED_BUT_FAILED,
            "IPROOV" to Level.IPROOV,
            "NO_ACTIVE_PACKAGE" to Level.NO_ACTIVE_PACKAGE,
            "INVALID_VERSION" to Level.INVALID_VERSION,
            "WAIT_DOCUMENT" to Level.WAIT_DOCUMENT,
            "WAIT_NFC" to Level.WAIT_NFC,
            "WAIT_IPROOV" to Level.WAIT_IPROOV,
            "ODD_SIZE_IMAGE_CAPTURE" to Level.ODD_SIZE_IMAGE_CAPTURE
        )
    }
}
