package com.id365.idverification.internal.communication

import android.content.Context
import android.nfc.NfcManager
import android.os.Build
import com.id365.idverification.BuildConfig
import com.id365.idverification.internal.model.CameraUtils.getCameraMaxSupportedResolution
import com.id365.idverification.internal.model.CameraUtils.getDeviceResolution


// This class holds the functions for getting all the data for the device information
internal data class DeviceInformation(
    val context: Context,
    val model: String = getDeviceModel(),
    val cameraResolution: String = getCameraResolution(context),
    val displayResolution: String = getDisplayResolution(context),
    val manufacturer: String = getManufacturer(),
    val sdkVersion: String = getSdkVersion(),
    val osVersion: String = getOsVersion(),
    val platform: String = getPlatform(),
    val nfcAvailable: Boolean = nfcAvailable(context),
)
private fun getDeviceModel(): String {
    return Build.MODEL
}

private fun getCameraResolution(context: Context): String {
    // TODO: Do something about this!!
    return getCameraMaxSupportedResolution(context).toString()
}

private fun getDisplayResolution(context: Context): String {
    return getDeviceResolution(context).toString()
}

private fun getManufacturer(): String {
    return Build.MANUFACTURER
}

private fun getSdkVersion(): String {
    return BuildConfig.AAR_VERSION
}

private fun getOsVersion(): String {
    return Build.VERSION.SDK_INT.toString()
}

private fun getPlatform(): String {
    return "Android"
}

private fun nfcAvailable(context: Context): Boolean {
    val manager = context.getSystemService(Context.NFC_SERVICE) as NfcManager
    val adapter = manager.defaultAdapter
    return adapter != null
}
