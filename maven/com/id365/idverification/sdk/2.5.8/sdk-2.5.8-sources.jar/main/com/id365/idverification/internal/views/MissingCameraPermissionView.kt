package com.id365.idverification.internal.views

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.LifecycleOwner
import com.id365.idverification.R
import com.id365.idverification.internal.communication.UserMessage
import com.id365.idverification.internal.core.SdkContext
import com.id365.idverification.internal.viewmodel.IIdVerificationViewModel
import com.id365.idverification.internal.viewmodel.IPermissionsViewModel
import com.id365.idverification.internal.views.informationview.InformationTextView
import org.koin.core.parameter.parametersOf

@Composable
internal fun MissingCameraPermissionView(
    request: () -> Unit,
    lfo: LifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current,
    viewModel: IIdVerificationViewModel? = try {
        SdkContext.sdk.koin.get(parameters = { parametersOf(lfo) })
    } catch(e: Exception) {
        null
    }
) {
    val ctx = LocalContext.current
    LaunchedEffect(key1 = true) {
        request.invoke()
    }
    Box(modifier = Modifier.fillMaxSize().padding(10.dp)) {
        Card(
            modifier = Modifier.align(Alignment.Center)
        ) {
            Column(
                modifier = Modifier.padding(10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                InformationTextView(
                    alignment = Alignment.CenterHorizontally,
                    userMessage = UserMessage(
                        title = ctx.getString(R.string.camera_permission_title),
                        subtitle = ctx.getString(R.string.camera_permission_message),
                        level = UserMessage.Level.INFORMATION
                    )
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Button(modifier = Modifier, onClick = {
                        request.invoke()
                    }) {
                        Text(text = ctx.getString(R.string.camera_permission_ok_button))
                    }
                    Button(modifier = Modifier, onClick = {
                        SdkContext.sdk.koin.get<IPermissionsViewModel>().openSettings(ctx)
                    }) {
                        Text(text = ctx.getString(R.string._365id_button_enable_settings))
                    }
                    Button(modifier = Modifier, onClick = {
                        viewModel?.callback?.invoke()
                    }) {
                        Text(text = ctx.getString(R.string.camera_permission_cancel_button))
                    }
                }

            }
        }
    }
}