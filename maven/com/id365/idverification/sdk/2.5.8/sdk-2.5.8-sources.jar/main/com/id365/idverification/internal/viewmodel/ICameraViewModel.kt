package com.id365.idverification.internal.viewmodel

import android.content.Context
import android.graphics.Bitmap
import android.view.View
import androidx.camera.view.PreviewView
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.core.content.res.ResourcesCompat
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.id365.idverification.R
import com.id365.idverification.internal.model.ICameraModel
import com.id365.idverification.internal.model.mockedCameraModel
import java.io.Closeable

/**
 * The interface describing what the FrontView expects from its' ViewModel
 */
internal interface ICameraViewModel : Closeable {

    /**
     * Reference to the view this camera view should be drawing
     */
    val previewView: View

    /**
     * Which state is the view in?
     */
    val previewStreamState: LiveData<PreviewView.StreamState>

    /**
     * Should the Shutter button be visible?
     */
    val cameraViewState: MutableLiveData<CameraViewState>

    /**
     * Tells whether or not the alert box should be visible
     */
    val isCameraRunning: MutableLiveData<Boolean>

    /**
     * Tells whether or not a message should be displayed for the user saying that the light is bad.
     */
    val isLuminanceAcceptable: MutableState<Boolean>

    enum class CameraViewState {
        INIT,
        AUTO,
        MANUAL,
        PERMISSION,
    }

    fun getPreviewImage(): Bitmap?

    fun start()
}

internal fun mockedCameraViewModel(
    context: Context,
    model: ICameraModel = mockedCameraModel(context),
    callback: () -> Unit = {}
): ICameraViewModel {
    return object : ICameraViewModel {
        override val previewView: View
            get() = View(context).apply {
                this.background = ResourcesCompat.getDrawable(resources, R.drawable.preview_2, null)
            }
        override val previewStreamState = MutableLiveData(PreviewView.StreamState.STREAMING)
        override val cameraViewState = MutableLiveData(ICameraViewModel.CameraViewState.AUTO)
        override val isCameraRunning = MutableLiveData(true)
        override val isLuminanceAcceptable = mutableStateOf(model.luminanceIsAcceptable.value)

        override fun close() {}

        override fun getPreviewImage(): Bitmap? {
            TODO("Not yet implemented")
        }

        override fun start() {
            // NYI
        }
    }
}