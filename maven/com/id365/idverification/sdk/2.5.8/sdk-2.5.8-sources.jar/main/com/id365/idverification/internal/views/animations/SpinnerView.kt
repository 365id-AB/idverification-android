package com.id365.idverification.internal.views.animations

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import kotlin.math.*

@Composable
internal fun SpinnerView(modifier: Modifier = Modifier) {
    val animatedValue = rememberInfiniteTransition(label = "").animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ), label = ""
    ).value
    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        val tintColor = MaterialTheme.colorScheme.primary
        Canvas(modifier = Modifier.fillMaxSize()) {

            // Get strokeWidth of the circle
            // The minimum width or height divided into a smaller part
            val strokeWidth = size.minDimension / 20

            // Get values of start/sweep-angle
            val startValue = ((-cos(Math.PI * animatedValue)) / 2) + 0.51
            val endValue = ((-cos(Math.PI * animatedValue.pow(3))) / 2) + 0.5
            val startAngle = startValue * 360 - 90
            val endAngle = endValue * 360 - 90
            val sweepAngle = endAngle - startAngle

            drawArc(
                color = tintColor,
                startAngle = startAngle.toFloat(),
                sweepAngle = sweepAngle.toFloat(),
                useCenter = false,
                style = Stroke(width = strokeWidth,
                    cap = StrokeCap.Round,
                )
            )
        }
    }
}

@Preview
@Composable
private fun SpinnerViewPreview() {
    Box(modifier = Modifier.fillMaxSize()) {
        SpinnerView(
            modifier = Modifier
                .aspectRatio(1f)
                .align(Alignment.Center)
                .padding(all = 50.dp)
        )
    }
}
