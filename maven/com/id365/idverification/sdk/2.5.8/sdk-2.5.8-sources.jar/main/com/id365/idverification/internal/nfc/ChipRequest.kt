package com.id365.idverification.internal.nfc

import kotlinx.serialization.Serializable

/**
 * A single NFC request
 */
@Serializable
internal data class ChipRequest(
    /**
     * The APDU command to be run on an NFC chip
     */
    val apdu: ByteArray,

    /**
     * First checksum byte expected for this apdu
     */
    val sw1: UByte,

    /**
     * Second checksum byte expected for this apdu
     */
    val sw2: UByte
) {
    /**
     * Auto generated code to enable equality operations
     */
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as ChipRequest

        if (!apdu.contentEquals(other.apdu)) return false
        if (sw1 != other.sw1) return false
        if (sw2 != other.sw2) return false

        return true
    }

    /**
     * Auto generated code to enable comparison between objects
     */
    override fun hashCode(): Int {
        var result = apdu.contentHashCode()
        result = 31 * result + sw1.hashCode()
        result = 31 * result + sw2.hashCode()
        return result
    }
}
