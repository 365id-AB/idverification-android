package com.id365.idverification.internal.views

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.id365.idverification.internal.model.CameraConstants
import com.id365.idverification.internal.ui.theme.Id365ScannerSdkTheme


/**
 * Renders a rectangular cutout in an "ID3" shape that will fill to
 * cover as much space as possible, prioritizing width.
 */
@Composable
internal fun RoundedRectangleView(
    modifier: Modifier = Modifier,
    radius: Float = 25f,
    padding: PaddingValues = PaddingValues(all=10.dp),
    color: Color = Color.Magenta
) {
    Box(
        modifier = modifier
            .fillMaxSize()
    ) {
        Canvas(
            modifier = modifier
                .fillMaxWidth()
        ) {
            val radii = radius.dp.toPx()
            val marginLeft = padding.calculateLeftPadding(LayoutDirection.Ltr).toPx()
            val marginRight = padding.calculateRightPadding(LayoutDirection.Ltr).toPx()
            val marginTop = padding.calculateTopPadding().toPx()
            val marginBtm = padding.calculateBottomPadding().toPx()
            drawPath(
                path = Path().apply {
                    // Fill background
                    moveTo(0f, 0f)
                    relativeLineTo(0f, size.height)
                    relativeLineTo(size.width, 0f)
                    relativeLineTo(0f, -size.height)
                    relativeLineTo(-size.width, 0f)

                    moveTo(marginLeft, marginTop + radii)
                    val tl = Rect(center = Offset(marginLeft + radii, marginTop + radii), radius = radii)
                    val tr = Rect(
                        center = Offset(size.width - marginRight - radii, marginTop + radii),
                        radius = radii
                    )
                    val br = Rect(
                        center = Offset(
                            size.width - marginRight - radii,
                            size.height - marginBtm - radii
                        ), radius = radii
                    )
                    val bl = Rect(
                        center = Offset(marginLeft + radii, size.height - marginBtm - radii),
                        radius = radii
                    )

                    arcTo(tl, 180f, 90f, false)
                    arcTo(tr, 270f, 90f, false)
                    arcTo(br, 0f, 90f, false)
                    arcTo(bl, 90f, 90f, false)

                }, color = color
            )
        }
    }
}

@Composable
internal fun RoundedRectangleView(
    modifier: Modifier = Modifier,
    radius: Float = 25f,
    margin: Float = 10f,
    color: Color = Color.Magenta
) {
    RoundedRectangleView(
        modifier = modifier,
        radius = radius,
        padding = PaddingValues(all=margin.dp),
        color = color,
    )
}

@Preview
@Composable
private fun  RoundedRectanglePreview() {
    Id365ScannerSdkTheme {
        Box(modifier=Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            RoundedRectangleView(
                modifier = Modifier.fillMaxWidth().aspectRatio(CameraConstants.ID3_RELATIONSHIP),
                margin=15f
            )
        }
    }
}
