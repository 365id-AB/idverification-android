package com.id365.idverification.internal.dida

import com.google.mlkit.vision.barcode.common.Barcode

/**
 * The interface describing a DIDA Processor to the rest of the SDK
 */
internal interface DidaProcessor {
    fun process(barcode: Barcode)
}