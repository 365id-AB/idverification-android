package com.id365.idverification.internal.viewmodel

import android.content.Intent
import androidx.compose.runtime.MutableState
import java.io.Closeable

/**
 * Describes the ViewModel used by the NfcView.
 */
internal interface INfcViewModel: IInformationOverlayViewModel, Closeable {

    /**
     * If the adapter is active or not.
     */
    val adapterActive: MutableState<Boolean>

    /**
     * Check if Nfc is even supported on this hardware
     */
    val nfcSupported: Boolean

    /**
     * Check if Nfc is enabled on this device
     */
    val nfcEnabled: MutableState<Boolean>

    /**
     * Receives intents from an Activity
     */
    suspend fun handleIntent(intent: Intent)

    val progressMessage: MutableState<String>
    val progressBarFill: MutableState<Float>
}