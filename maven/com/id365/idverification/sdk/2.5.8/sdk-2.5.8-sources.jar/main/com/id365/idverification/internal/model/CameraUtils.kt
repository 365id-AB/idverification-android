package com.id365.idverification.internal.model

import android.app.ActivityManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageFormat
import android.graphics.Point
import android.graphics.Rect
import android.graphics.RectF
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.TotalCaptureResult
import android.hardware.camera2.params.MeteringRectangle
import android.hardware.camera2.params.StreamConfigurationMap
import android.os.Build
import android.util.Size
import android.view.WindowManager
import android.view.WindowMetrics
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.core.AspectRatio
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import com.id365.idverification.internal.utils.CommonUtils.DebugTAG
import com.id365.idverification.internal.logging.AppLog
import com.id365.idverification.internal.model.CameraConstants.characteristics
import com.id365.idverification.internal.model.CameraConstants.deviceSize
import com.id365.idverification.internal.model.CameraConstants.maxSize
import kotlin.math.abs

internal object CameraUtils {

    /**
     * Get best fitting aspect ratio
     * @param ar: Aspect ratio as a float
     * @return Int representing AR from [AspectRatio]
     */
    internal fun getBestAspectRatio(ar: Float): Int {
        val ar169 = 16 / 9F
        AppLog.d(DebugTAG, "Is $ar wider than 9:16? (typ. tablets)")
        return if (ar < ar169) {
            AppLog.d(DebugTAG, "Selecting 4:3")
            AspectRatio.RATIO_4_3
        } else {
            AppLog.d(DebugTAG, "Selecting 16:9")
            AspectRatio.RATIO_16_9
        }
    }

    /**
     * Return the physical aspect ratio of the display
     * @param ctx: An android context
     * @return: The aspect ratio expressed as width / height
     */
    internal fun getPhysicalAspectRatio(ctx: Context): Float {
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            ctx.display?.mode
        } else {
            val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            @Suppress("DEPRECATION")
            wm.defaultDisplay.mode
        }
        mode?.let {
            return it.physicalHeight.toFloat() / it.physicalWidth
        }
        return 1920f / 1080
    }

    /**
     * Calculate crop image based on a known viewfinder position and rootview size
     *
     * @param cameraImage: Size of a camera image to be analyzed
     * @param rootView: The resolution of the view assigned to the SDK by the device and app
     * @param viewFinder: The rectangle that tells where in rootView we're drawing the viewFinder graphic
     *
     * @return: A rectangle describing what part of [cameraImage] is occupied by [viewFinder]
     */
    internal fun calculateCropImage(cameraImage: Size, rootView: Size, viewFinder: Rect = Rect(
        0, rootView.height/6, rootView.width, rootView.width * CameraConstants.ID3_RELATIONSHIP.toInt()
    )): Rect {
        val rotatedImage = Size(cameraImage.width, cameraImage.height)
        val scaleFactorX = rotatedImage.width.toDouble() / rootView.width
        val scaleFactorY = rotatedImage.height.toDouble() / rootView.height
        val scaleFactor = if (scaleFactorX < scaleFactorY) scaleFactorX else scaleFactorY

        val preview = Rect(0, 0, rootView.width, rootView.height).scale(scaleFactor)
        val image = Rect(0, 0, rotatedImage.width, rotatedImage.height)
        val margin = (image.width() - preview.width()) / 2

        val viewFinderScaled = viewFinder.scale(scaleFactor).offsetBy(margin, 0)

        val left = viewFinderScaled.left - PADDING
        val top = viewFinderScaled.top - PADDING
        val right = viewFinderScaled.right + PADDING
        val bottom = viewFinderScaled.bottom + PADDING
        val padded = Rect(
            if (left < 0) 0 else left,
            if (top < 0) 0 else top,
            if (right > image.right) image.right else right,
            if (bottom > image.bottom) image.bottom else bottom
        )

        return padded
    }

    internal fun Rect.rotate(): Rect {
        return Rect(
            top,
            left,
            bottom,
            right,
        )
    }

    private fun Rect.offsetBy(x: Int, y: Int): Rect = Rect(left + x, top + y, right + x, bottom + y)


    private fun Rect.scale(factor: Double): Rect {
        return Rect(
            (left * factor).toInt(),
            (top * factor).toInt(),
            (right * factor).toInt(),
            (bottom * factor).toInt(),
        )
    }

    private fun Size.scale(factor: Double): Size = Size((width * factor).toInt(), (height * factor).toInt())

    internal fun Rect.size(): Size = Size(width(), height())

    /**
     * Is this Rect completetely bounded by other?
     */
    internal fun Rect.inside(other: Rect?): Boolean {
        other?.let {
            return left > other.left && top > other.top && right < other.right && bottom < other.bottom
        }
        return false
    }

    internal fun Rect.scaleToFit(original: Size?, target: Size?): Rect {
        if (original == null || target == null)
            return this
        val scaleFactorX = target.width.toDouble() / original.width
        val scaleFactorY = target.height.toDouble() / original.height
        val scaleFactor = if (scaleFactorX > scaleFactorY) scaleFactorX else scaleFactorY

        val scaled = original.scale(scaleFactor)

        val margin = (abs(scaled.width - target.width) * scaleFactor / 2).toInt()

        val fitted = scale(scaleFactor)

        val offsetted = fitted.offsetBy(0, -margin * 2)

        return offsetted
    }

    /**
     * On newer versions of android, gets the real resolution of the active window which may or may not occupy the full screen
     * On older versions, gets the full, real resolution of the device
     */
    internal fun getDeviceResolution(context: Context): Size {
        val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val metrics: WindowMetrics = windowManager.currentWindowMetrics
            deviceSize = Size(metrics.bounds.width(), metrics.bounds.height())
            Size(metrics.bounds.width(), metrics.bounds.height())
        } else {
            val size = Point()
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getRealSize(size)
            deviceSize = Size(size.x, size.y)
            Size(size.x, size.y)
        }
    }

    /**
     * Get and store camera characteristics struct for future use
     */
    internal fun getCameraCharacteristics(context: Context): CameraCharacteristics {
        characteristics?.let {
            return it
        }
        val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager

        val cameraId = cameraManager.cameraIdList.first {
            cameraManager.getCameraCharacteristics(it)
                .get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        }

        characteristics = cameraManager.getCameraCharacteristics(cameraId)
        return characteristics!!
    }

    /**
     * Calculates max supported resolution for the default lens of the backfacing camera on this device
     *
     * @param context: A valid context, such as the activity
     *
     * @return  a Size representing the full resolution image this device can support. Defaults to 12MP
     */
    internal fun getCameraMaxSupportedResolution(context: Context): Size {
        val fallback = Size(1920, 1440)
        val wanted = Size(3280, 2464)
        val resolution = try {
            val characteristics = getCameraCharacteristics(context)
            val configs: StreamConfigurationMap? =
                characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)

            val size = configs?.let { config ->
                val sizes = config.getOutputSizes(ImageFormat.YUV_420_888).toList().sortedByDescending {
                    it?.area()
                }
                AppLog.v(DebugTAG, "Camera resolutions available:")
                sizes.forEach {
                    AppLog.v(DebugTAG, "   $it")
                }

                val mem = getDeviceMemory(context)
                if (mem >= RECOMMENDED_MEMORY_AMOUNT) {
                    sizes.selectBestMatch(wanted)
                } else {
                    sizes.selectBestMatch(fallback)
                }
            }
            size ?: fallback
        } catch (e: IllegalArgumentException) {
            AppLog.e(
                DebugTAG,
                "Encountered issue when polling camera for supported resolutions: $e"
            )
            AppLog.w(
                DebugTAG,
                "Attempting to move past this issue using fallback resolution: $fallback"
            )
            fallback
        } catch(e: Exception) {
            AppLog.w(DebugTAG, "Exception occured when polling camera resolutions: $e")
            fallback
        }
        AppLog.v(DebugTAG, "Selecting $resolution as the intended camera resolution")
        maxSize = resolution
        return resolution
    }

    private fun getDeviceMemory(context: Context): Long {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memInfo)
        return memInfo.totalMem / (1024 * 1024) // Convert to MB
    }

    /**
     * Select from array the Size best matching requested, prioritizing exact match first, or matching width otherwise.
     */
    private fun List<Size>.selectBestMatch(requested: Size): Size {
        if (requested in this)
            return requested
        var candidate = Size(Int.MAX_VALUE, Int.MAX_VALUE)
        for (it in this) {
            if (it.width == requested.width &&
                it.height == requested.height
            ) {
                candidate = it
                break
            }
            if (it.width == requested.width) {
                candidate = it
            }
        }

        if (candidate.width == Int.MAX_VALUE) {
            candidate = get(0)
            forEach {
                if (it.compare(requested) < candidate.compare(requested)) {
                    AppLog.v(DebugTAG, "updating candidate to $it")
                    candidate = it
                }
            }
        }
        return candidate
    }

    private fun List<Size>.filter(aspectRatio: Double): List<Size> {
        return filter {
            val ar = it.aspectRatio()
            val diff = abs(aspectRatio - ar)
            diff < .1
        }
    }

    private fun Size.area(): Int = width * height

    private fun Size.aspectRatio(): Double = width.toDouble() / height

    private fun Size.compare(other: Size): Int = abs(area() - other.area())


    /**
     * Adds a callback to each image sent for analysis that informs us if the image is known to be
     * in focus or out-of-focus.
     *
     * @callback: Triggered when focus state changes (in-focus or out-of-focus)
     */
    @androidx.camera.camera2.interop.ExperimentalCamera2Interop
    fun ImageAnalysis.Builder.setFocusCallback(
        callback: (focused: Boolean) -> Unit,
    ): ImageAnalysis.Builder {
        val extender = Camera2Interop.Extender(this)
        extender.setSessionCaptureCallback(object : CameraCaptureSession.CaptureCallback() {
            var focused: Boolean = false

            override fun onCaptureCompleted(
                session: CameraCaptureSession,
                request: CaptureRequest,
                result: TotalCaptureResult
            ) {
                super.onCaptureCompleted(session, request, result)
                val newFocusState: Boolean = when (result[CaptureResult.CONTROL_AF_STATE]) {
                    CaptureResult.CONTROL_AF_STATE_FOCUSED_LOCKED,
                    CaptureResult.CONTROL_AF_STATE_PASSIVE_FOCUSED -> {
                        true
                    }
                    CaptureResult.CONTROL_AF_STATE_NOT_FOCUSED_LOCKED,
                    CaptureResult.CONTROL_AF_STATE_PASSIVE_UNFOCUSED -> {
                        false
                    }
                    else -> {
                        null
                    }
                } ?: return
                if (focused != newFocusState) {
                    focused = newFocusState
                    callback(newFocusState)
                }
            }
        })
        return this
    }

    /**
     * Sets the auto focus point of the camera to be the area covered by the viewfinder, a bit above
     * the center of the camera image.
     *
     * @param cropRect: Rectangle representing the portion of the image we want in focus
     *
     * @return The PreviewBuilder where this is called
     */
    @androidx.camera.camera2.interop.ExperimentalCamera2Interop
    fun Preview.Builder.setFocusRegion(
        cropRect: RectF
    ): Preview.Builder {
        val extender = Camera2Interop.Extender(this)
        extender.setCaptureRequestOption(
            CaptureRequest.CONTROL_AF_MODE,
            CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_PICTURE
        )
        val aas = characteristics!!.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE) as Size
        val isMeteringAreaAFSupported =
            characteristics?.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AF) ?: 0
        if (isMeteringAreaAFSupported > 0) {
            val cropRectSensorCoordinates = Rect(
                ((cropRect.left + 1 / 6) * aas.width).toInt(),
                ((cropRect.top + 1 / 4) * aas.height).toInt(),
                ((cropRect.right - 1 / 6) * aas.width).toInt(),
                ((cropRect.bottom - 1 / 4) * aas.height).toInt(),
            )
            extender.setCaptureRequestOption(
                CaptureRequest.CONTROL_AF_REGIONS, arrayOf(
                    MeteringRectangle(
                        cropRectSensorCoordinates,
                        MeteringRectangle.METERING_WEIGHT_MAX
                    )
                )
            )
        }
        return this
    }

    /**
     * For rotating the width/height of a given size
     */
    fun Size.rotate(): Size {
        return Size(height, width)
    }

    internal fun Bitmap.crop(rect: Rect): Bitmap =
        Bitmap.createBitmap(this, rect.left, rect.top, rect.width(), rect.height())

    private const val PADDING = 0
    private const val RECOMMENDED_MEMORY_AMOUNT = 3072
}