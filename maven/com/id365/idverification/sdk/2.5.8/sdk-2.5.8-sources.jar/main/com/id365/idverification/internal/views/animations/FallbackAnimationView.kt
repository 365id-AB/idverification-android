package com.id365.idverification.internal.views.animations

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.tooling.preview.PreviewParameter
import androidx.compose.ui.tooling.preview.PreviewParameterProvider
import androidx.compose.ui.unit.dp
import com.id365.idverification.IdVerification
import com.id365.idverification.internal.core.SdkContext

internal class IdVerificationAnimationProvider : PreviewParameterProvider<@Composable () -> Unit> {
    override val values = sequenceOf(
        SdkContext.customTheme.animations.prepareId3,
        SdkContext.customTheme.animations.prepareId1Frontside,
        SdkContext.customTheme.animations.prepareId1Backside,
        SdkContext.customTheme.animations.prepareDocument,
        SdkContext.customTheme.animations.prepareOddSizedDocument,
        SdkContext.customTheme.animations.prepareNfc,
        SdkContext.customTheme.animations.prepareId1Nfc,
        SdkContext.customTheme.animations.prepareId3Nfc,
        SdkContext.customTheme.animations.prepareDocumentNfc,
        SdkContext.customTheme.animations.prepareFacematch,
        SdkContext.customTheme.animations.instructionId1Frontside,
        SdkContext.customTheme.animations.instructionDocument,
        SdkContext.customTheme.animations.instructionId3,
        SdkContext.customTheme.animations.instructionId1Backside,
        SdkContext.customTheme.animations.instructionNfc,
        SdkContext.customTheme.animations.instructionId1Nfc,
        SdkContext.customTheme.animations.instructionId3Nfc,
        SdkContext.customTheme.animations.instructionDocumentNfc,
        SdkContext.customTheme.animations.instructionOddSizedDocument,
        SdkContext.customTheme.animations.loadingFacematch,
        SdkContext.customTheme.animations.loadingGeneric,
        SdkContext.customTheme.animations.loadingNfc,
        SdkContext.customTheme.animations.loadingImageCapture,
    )
}

@Preview
@Composable
private fun  DefaultAnimationViewPreview(
    @PreviewParameter(IdVerificationAnimationProvider::class) anim: @Composable () -> Unit
) {
    val theme = IdVerification.IdVerificationTheme(
        colorScheme = darkColorScheme()
    )
    MaterialTheme(colorScheme=theme.colorScheme) {
        Box(modifier= Modifier
            .fillMaxSize()
            .background(theme.colorScheme.background))
        {
            Text(text = "${anim.javaClass.simpleName} Preview", color = theme.colorScheme.primary, modifier= Modifier
                .align(Alignment.TopCenter)
                .padding(100.dp))
            Box(modifier= Modifier
                .aspectRatio(1.0f)
                .align(Alignment.Center)) {
                anim()
            }
        }
    }
}