package com.id365.idverification.internal.views

import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import com.id365.idverification.internal.core.SdkContext
import com.id365.idverification.internal.logging.AppLog
import com.id365.idverification.internal.utils.getActivity
import com.id365.idverification.internal.ui.theme.Id365ScannerSdkTheme
import com.id365.idverification.internal.viewmodel.IIProovViewModel
import com.id365.idverification.internal.views.informationview.InformationView
import org.koin.core.error.NoBeanDefFoundException
import org.koin.core.parameter.parametersOf

/**
 * Shows the IProov view.
 */
@Composable
internal fun IProovView(
    activity: Activity? = LocalContext.current.getActivity(),
    colors: ColorScheme = MaterialTheme.colorScheme,
    model: IIProovViewModel? = try {
        SdkContext.koin.get(parameters = {
            parametersOf(
                activity!!,
                colors
            )
        })
    } catch(e: NoBeanDefFoundException) {
        // Expected exception when closing the SDK
        null
    } catch(e: Exception) {
        AppLog.e("IProovView", "Unexpected exception when showing iProov view", e)
        null
    }
) {
    model?.let {
        when(model.showInformation.value) {
            true -> InformationView(callback = { model.buttonCb() })
            false -> when (model.showLoading.value) {
                true -> WaitingView(loadingViewType = LoadingViewType.SpinnerWithFace)
                false -> {
                    WaitingView(loadingViewType = LoadingViewType.Spinner)
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
private fun  IProovViewPreview() {
    Id365ScannerSdkTheme {
        IProovView(
            model = object : IIProovViewModel {
                override fun startIProov(token: String) {
                    TODO("Not yet implemented")
                }

                override val buttonCb: () -> Unit
                    get() {
                        TODO("Not yet implemented")
                    }

                override val animationShouldPlay: MutableState<Boolean>
                    get() = mutableStateOf(true)

                override val showLoading: MutableState<Boolean>
                    get() = mutableStateOf(false)
                override val showInformation
                    get() = mutableStateOf(true)

                override fun close() {
                    TODO("Not yet implemented")
                }
            }
        )
    }
}
