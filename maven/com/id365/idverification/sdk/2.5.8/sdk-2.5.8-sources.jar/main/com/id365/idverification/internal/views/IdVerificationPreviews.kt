package com.id365.idverification.internal.views

import android.content.Intent
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.Box
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.tooling.preview.PreviewParameter
import androidx.compose.ui.tooling.preview.PreviewParameterProvider
import com.id365.idverification.IdVerification
import com.id365.idverification.internal.communication.SessionToken
import com.id365.idverification.internal.communication.Task
import com.id365.idverification.internal.core.LandingPageTransition
import com.id365.idverification.internal.core.SdkContext
import com.id365.idverification.internal.integrations.iproov.FacematchState
import com.id365.idverification.internal.ui.theme.Id365ScannerSdkTheme
import com.id365.idverification.internal.viewmodel.IIProovViewModel
import com.id365.idverification.internal.viewmodel.IIdVerificationViewModel
import com.id365.idverification.internal.viewmodel.IMicroBlinkViewModel
import com.id365.idverification.internal.viewmodel.INfcViewModel
import com.id365.idverification.internal.viewmodel.IInformationOverlayViewModel
import com.id365.idverification.internal.viewmodel.IInformationViewModel
import org.koin.dsl.koinApplication
import org.koin.dsl.module


private class IdVerificationTaskProvider : PreviewParameterProvider<Task.Level> {
    override val values = Task.Level.values().asSequence()

    val showWhite = mutableStateOf(false)
    val state = mutableStateOf(Task.Level.UNDEFINED)
    init {
        SdkContext.cameraReady.value = LandingPageTransition.READY
        SdkContext.sessionReady.value = true
        SdkContext.sdk = koinApplication {
            modules(module{
                single<IInformationViewModel>{ object: IInformationViewModel {
                    override val showInformationView = showWhite
                    override val taskData = mutableStateOf(Task())
                    override val completedTasks = mutableIntStateOf(1)
                    override val estimatedTotalTasks = mutableIntStateOf(3)

                    override var confirmButtonCallback: () -> Unit = {}
                    override val cancelButtonCallback = { showInformationView.value = !showInformationView.value }
                    override val documentSizeType = IdVerification.DocumentSizeType.DOCUMENT
                    override var iproovState: FacematchState
                        get() = FacematchState.UNSET
                        set(value) {}
                }}
                single<IIdVerificationViewModel>{ object: IIdVerificationViewModel {
                    override val showInformationView = showWhite
                    override val task = state
                    override val callback = {}
                    override fun getSessionToken() = SessionToken()
                    override fun close() {}
                }}
                factory<INfcViewModel>{ object: INfcViewModel {
                    override val adapterActive = mutableStateOf(true)
                    override val nfcSupported = true
                    override val nfcEnabled = mutableStateOf(true)
                    override suspend fun handleIntent(intent: Intent) {}
                    override val progressMessage = mutableStateOf("Extracting your soul")
                    override val progressBarFill = mutableFloatStateOf(.25F)
                    override val taskData = mutableStateOf(Task(nextTask = "NFC"))
                    override val infoText = mutableStateOf("I'm doing NFC!")
                    override val playAnimation = mutableStateOf(true)
                    override val buttonCb: () -> Unit = { playAnimation.value = !playAnimation.value }
                    override val buttonLabel = "Skip"
                    override val buttonEnabled = mutableStateOf(true)
                    override fun close() {}
                }}
                single<IInformationOverlayViewModel>{ object: IInformationOverlayViewModel {
                    //override val task = state
                    override val taskData = mutableStateOf(Task())
                    override val infoText = mutableStateOf("Informational text telling you what to do")
                    override val playAnimation = mutableStateOf(true)
                    override val buttonCb: () -> Unit = { playAnimation.value = !playAnimation.value }
                    override val buttonLabel = "Play/Pause animation"
                    override val buttonEnabled = mutableStateOf(true)
                }}
                single<IMicroBlinkViewModel>{ object: IMicroBlinkViewModel {
                    override fun startMicroBlinkSdk(previewView: PreviewView) {}
                    override fun getDocumentSizeType() = IdVerification.DocumentSizeType.ID1
                    override val didCaptureImage = mutableStateOf(false)
                    override val warningStatusMessage = mutableStateOf<String?>("You are holding it wrong")
                    override val warningStatus = mutableStateOf(true)
                    override val taskData = mutableStateOf(Task(nextTask = "FRONT_SIDE"))
                    override val infoText = mutableStateOf("Put the document inside the thingy")
                    override val playAnimation = mutableStateOf(true)
                    override val buttonCb: () -> Unit = {}
                    override val buttonLabel = "Button"
                    override val buttonEnabled = mutableStateOf(true)
                    override fun close() {}
                }}
                single<IIProovViewModel>{ object: IIProovViewModel {
                    override fun startIProov(token: String){}
                    override val buttonCb: () -> Unit =  {
                        TODO("Not yet implemented")
                    }

                    override val animationShouldPlay = mutableStateOf(true)
                    override val showLoading = mutableStateOf(false)
                    override val showInformation = mutableStateOf(false)

                    override fun close() {}
                }}
            })
        }
    }
}

@Preview(
    showBackground = true,
    showSystemUi = true,
)
@Composable
private fun  IdVerificationViewPreview(
    @PreviewParameter(IdVerificationTaskProvider::class) task: Task.Level
) {
    val model : IIdVerificationViewModel by SdkContext.sdk.koin.inject()
    LaunchedEffect(key1 = task){
        model.task.value = task
        when(task) {
            Task.Level.FRONT_SIDE,
            Task.Level.BACK_SIDE,
            Task.Level.NFC,
            Task.Level.IPROOV -> model.showInformationView.value = true
            else -> model.showInformationView.value = false
        }
    }
    Id365ScannerSdkTheme(darkTheme = false) {
        Box {
            PrivateIdVerificationView(model=model)
            val state by SdkContext.cameraReady.observeAsState()
            Text(text = "$task Preview", modifier= Modifier
                .align(Alignment.TopCenter))
            Button(
                colors = ButtonDefaults.buttonColors(),
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier.align(Alignment.BottomStart),
                onClick = {
                    SdkContext.cameraReady.value = when (state) {
                        LandingPageTransition.START -> LandingPageTransition.LOGO
                        LandingPageTransition.LOGO -> LandingPageTransition.READY
                        LandingPageTransition.READY,
                        null -> LandingPageTransition.START
                    }
                },
            ) {
                Text("$state")
            }
        }
    }
}