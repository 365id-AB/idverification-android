package com.id365.idverification.internal.model

import android.hardware.camera2.CameraCharacteristics
import android.util.Size

object CameraConstants {
    const val ID3_RELATIONSHIP: Float = 125.0F / 88.0F
    const val ID3_CORNER_RADIUS = 25.0F
    const val ID3_MARGIN = 10.0F
    const val TOP_OFFSET_FACTOR: Float = 1.0F / 6.0F

    const val OVERLAY_OPACITY = 0.5F

    // CameraContainer GUI settings
    const val CAMERA_MARGINS: Float = 20f
    const val ID3_CAMERA_FOCUS_AREA_RATIO: Float = 125.0f / 88f // ID3
    const val ID1_CAMERA_FOCUS_AREA_RATIO: Float = 85.6f / 53.98f //ID1
    const val DOCUMENT_CAMERA_FOCUS_AREA_RATIO: Float = ID3_CAMERA_FOCUS_AREA_RATIO //DOCUMENT

    var characteristics: CameraCharacteristics? = null
    var maxSize: Size = Size(0, 0)
    var deviceSize: Size = Size(0, 0)
}