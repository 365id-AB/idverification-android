package com.id365.idverification.internal.views

import android.app.Activity
import android.os.Build
import android.view.View
import android.view.WindowInsetsController
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.annotation.RequiresApi
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.SpringSpec
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsTopHeight
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.LifecycleOwner
import com.google.accompanist.systemuicontroller.SystemUiController
import com.google.accompanist.systemuicontroller.rememberSystemUiController
import com.id365.idverification.IdVerification
import com.id365.idverification.internal.communication.Task
import com.id365.idverification.internal.core.SdkContext
import com.id365.idverification.internal.ui.theme.Shapes
import com.id365.idverification.internal.ui.theme.Typography
import com.id365.idverification.internal.utils.LockScreenOrientation
import com.id365.idverification.internal.utils.getActivity
import com.id365.idverification.internal.viewmodel.IIdVerificationViewModel
import com.id365.idverification.internal.views.informationview.InformationView
import com.id365.idverification.internal.views.microblink.MicroBlinkView
import com.id365.idverification.internal.views.oddsizeimagecaptureview.OddSizeImageCaptureView
import org.koin.core.error.ClosedScopeException
import org.koin.core.error.NoBeanDefFoundException
import org.koin.core.parameter.parametersOf


@Composable
internal fun InternalIdVerificationView() {
    val systemUiController: SystemUiController = rememberSystemUiController()
    val onBackground = MaterialTheme.colorScheme.onBackground
    systemUiController.setStatusBarColor(
        color = MaterialTheme.colorScheme.background,
        darkIcons = isSystemInDarkTheme(),
        transformColorForLightContent = { onBackground }
    )
    val context = LocalContext.current
    DisposableEffect(Unit) {
        val window = context.getActivity()?.window
        // Prevent the screen from turning off while the SDK is visible.
        window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose {
            // ...But make sure the screen can turn off on its' own after we're done.
            window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }
    val sdk = SdkContext.mutableSdk.observeAsState().value
    val lfo: LifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    val viewModel: IIdVerificationViewModel? = try {
        sdk?.koin?.get(parameters = { parametersOf(lfo) })
    } catch (e: ClosedScopeException) {
        null
    } catch (e: NoBeanDefFoundException) {
        null
    } catch (e: Exception) {
        null
    }

    MaterialTheme(
        colorScheme = SdkContext.customTheme.colorScheme,
        typography = Typography,
        shapes = Shapes
    ) {
        LockScreenOrientation()
        PrivateIdVerificationView(model = viewModel)
    }
}


/**
 * To prevent leaking IIdVerificationViewModel to the public facing API
 */
@Composable
internal fun PrivateIdVerificationView(
    model: IIdVerificationViewModel?,
) {
    model?.let { viewModel ->
        val currentTask by viewModel.task

        Column {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.surface)
            ) {
                if (viewModel.showInformationView.value) {
                    InformationView()
                }
                else {
                    LandingView(modifier = Modifier.fillMaxSize()) {
                        Crossfade(
                            targetState = currentTask,
                            animationSpec = SpringSpec(stiffness = Spring.StiffnessVeryLow),
                            label = "Crossfade Task.Level"
                        ) { task ->
                            when (task) {
                                Task.Level.UNDEFINED,
                                Task.Level.NO_ACTIVE_PACKAGE,
                                Task.Level.INVALID_VERSION,
                                Task.Level.WAIT -> WaitingView()
                                Task.Level.WAIT_DOCUMENT -> WaitingView(LoadingViewType.SpinnerWithCard)

                                Task.Level.WAIT_NFC -> WaitingView(LoadingViewType.NFC)
                                Task.Level.WAIT_IPROOV -> WaitingView(LoadingViewType.SpinnerWithFace)

                                Task.Level.FRONT_SIDE,
                                Task.Level.BACK_SIDE -> when(SdkContext.documentSizeType) {
                                    IdVerification.DocumentSizeType.DOCUMENT,
                                    IdVerification.DocumentSizeType.ID1,
                                    IdVerification.DocumentSizeType.ID3 -> MicroBlinkView()
                                    IdVerification.DocumentSizeType.ODD -> OddSizeImageCaptureView()
                                }

                                Task.Level.NFC -> NfcView()
                                Task.Level.FINISHED_SUCCESSFULLY -> SuccessView()
                                Task.Level.FINISHED_BUT_FAILED -> FailedView()
                                Task.Level.IPROOV -> IProovView()
                                Task.Level.ODD_SIZE_IMAGE_CAPTURE -> OddSizeImageCaptureView()
                            }
                        }
                    }
                }
            }
        }
        // When user presses the physical back button on phones that have it,
        // or do the "back" gesture we inject this callback
        BackHandler {
            viewModel.callback.invoke()
        }
    }
}
