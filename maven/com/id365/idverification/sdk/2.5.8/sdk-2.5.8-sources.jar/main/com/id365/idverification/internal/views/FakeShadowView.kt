package com.id365.idverification.internal.views

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Card
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp


/**
 * Render a fake shadow beneath `content`.
 * @param elevation: The size of the shadows to render. Greater value means longer shadows
 * @param colors: The colors that represent the shadows. By default, goes from black to transparent.
 * @param padding: The amount of padding around `content`
 * @param content: The composable to draw inside the shadows.
 */
@Composable
internal fun FakeShadowView(
    modifier: Modifier = Modifier,
    elevation: Dp = 40.dp,
    colors: List<Color> = listOf(Color.Black.copy(alpha = 0.2f), Color.Transparent),
    padding: PaddingValues = PaddingValues(all = 10.dp),
    content: @Composable () -> Unit,
) {
    Box(modifier = modifier.drawBehind {
        val r = size.width
        val b = size.height
        val radii = elevation.value

        // corners
        drawRect(
            brush = Brush.radialGradient(
                colors = colors,
                radius = radii,
                center = Offset(radii, radii)
            ),
            size = Size(radii, radii)
        )
        drawRect(
            brush = Brush.radialGradient(
                colors = colors,
                radius = radii,
                center = Offset(r - radii, b - radii)
            ),
            topLeft = Offset(r - radii, b - radii),
            size = Size(radii, radii)
        )
        drawRect(
            brush = Brush.radialGradient(
                colors = colors,
                radius = radii,
                center = Offset(r - radii, radii)
            ),
            topLeft = Offset(r - radii, 0f),
            size = Size(radii, radii)
        )
        drawRect(
            brush = Brush.radialGradient(
                colors = colors,
                radius = radii,
                center = Offset(radii, b - radii)
            ),
            topLeft = Offset(0f, b - radii),
            size = Size(radii, radii)
        )

        // edges
        drawRect(
            brush = Brush.verticalGradient(
                colors = colors,
                startY = b - radii,
                endY = b,
            ),
            topLeft = Offset(radii, b - radii),
            size = Size(r - 2*radii, radii)
        )
        drawRect(
            brush = Brush.verticalGradient(
                colors = colors,
                startY = radii,
                endY = 0f,
            ),
            topLeft = Offset(radii, 0f),
            size = Size(r - 2*radii, radii)
        )
        drawRect(
            brush = Brush.horizontalGradient(
                colors = colors,
                startX = radii,
                endX = 0f,
            ),
            topLeft = Offset(0f, radii),
            size = Size(radii, b - 2*radii)
        )
        drawRect(
            brush = Brush.horizontalGradient(
                colors = colors,
                startX = r - radii,
                endX = r,
            ),
            topLeft = Offset(r - radii, radii),
            size = Size(radii, b - 2*radii)
        )
    }) {
        Box(modifier = modifier.padding(padding)) {
            content.invoke()
        }
    }
}

@Preview
@Composable
private fun FakeShadowViewPreview() {
    Box(modifier = Modifier
        .fillMaxSize()
        .background(color = Color.White)) {
        FakeShadowView(modifier = Modifier.align(Alignment.Center)) {
            Card(modifier = Modifier
                .align(Alignment.Center)
                .width(200.dp)
                .height(140.dp)){
                Box(modifier = Modifier.align(Alignment.CenterHorizontally).padding(vertical = 50.dp)) {
                    Text(text = "Hello", modifier = Modifier.align(Alignment.Center),
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}
