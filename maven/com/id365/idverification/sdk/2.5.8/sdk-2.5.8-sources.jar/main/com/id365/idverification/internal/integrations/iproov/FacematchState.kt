package com.id365.idverification.internal.integrations.iproov

enum class FacematchState {
    UNSET,
    FAILED
}