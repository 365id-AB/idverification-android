package com.id365.idverification.internal.nfc.tags

import android.nfc.tech.NfcA
import android.util.Log
import com.id365.idverification.internal.utils.CommonUtils.DebugTAG

/**
 * Implements Android API "TagA" using our Interface
 *
 * @param tag: The Android Nfc object describing this tag
 */
internal class NfcTagA(private val tag: NfcA): NfcTag(tag) {

    override fun getChip(): String {
        return standard
    }

    override fun setTimeout(timeout: Int) {
        try {
            tag.timeout = timeout
        } catch(e: SecurityException) {
            Log.e(DebugTAG, "Couldn't set timeout to $timeout")
        }
    }

    override fun transceive(data: ByteArray): ByteArray {
        return tag.transceive(data)
    }

    override fun getMaxTransceiveLength(): Int = tag.maxTransceiveLength

    override fun isExtendedLengthApduSupported(): ExtendedApduSupport = ExtendedApduSupport.UNKNOWN

    companion object{
        const val standard: String = "ISO 14443-3A"
        val tech: String = NfcA::class.java.name
    }
}