package com.id365.idverification.internal.views

import android.content.Context
import android.content.res.Configuration
import androidx.camera.core.AspectRatio
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.*
import com.id365.idverification.internal.core.LandingPageTransition
import com.id365.idverification.internal.core.SdkContext
import com.id365.idverification.internal.core.SdkContext.sdk
import com.id365.idverification.internal.model.CameraUtils.getBestAspectRatio
import com.id365.idverification.internal.model.CameraUtils.getPhysicalAspectRatio
import com.id365.idverification.internal.ui.theme.Id365ScannerSdkTheme
import com.id365.idverification.internal.utils.WithPermission
import com.id365.idverification.internal.utils.observe
import com.id365.idverification.internal.viewmodel.ICameraViewModel
import com.id365.idverification.internal.viewmodel.mockedCameraViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.koin.core.parameter.parametersOf
import kotlin.time.Duration.Companion.seconds

@Composable
internal fun CameraView(
    modifier: Modifier = Modifier,
    ctx: Context = LocalContext.current,
    lfo: LifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current,
    model: ICameraViewModel? = sdk.koin.get(parameters = { parametersOf(ctx, lfo, 16/9F) }),
) {
    // This is used to handle cleanup of camera related stuff when SDK is closed from flutter while
    // a camera view is showing
    DisposableEffect(key1 = true) {
        onDispose {
            model?.close()
        }
    }
    val previewImage = model?.getPreviewImage()
    if (previewImage != null) {
        WaitingCardView()
        // Make sure camera is set to init on next run
        model.cameraViewState.value = ICameraViewModel.CameraViewState.INIT
        return
    }

    val viewState = observe(model?.cameraViewState, ICameraViewModel.CameraViewState.INIT)
    WithPermission(onDenied = @Composable { request ->
        // No permission: Transition camera view state to "permission"
        LaunchedEffect(key1 = viewState) {
            model?.cameraViewState?.value = ICameraViewModel.CameraViewState.PERMISSION
            SdkContext.cameraReady.postValue(LandingPageTransition.READY)
        }
        RequestCameraPermissionView(request)
    }) {

        // Permission granted; Switch to AUTO if we were in PERMISSION state
        LaunchedEffect(key1 = viewState) {
            when (viewState) {
                ICameraViewModel.CameraViewState.PERMISSION,
                ICameraViewModel.CameraViewState.INIT -> {
                    model?.cameraViewState?.value = ICameraViewModel.CameraViewState.AUTO
                }

                else -> {
                    // No action necessary
                }
            }
        }

        val streaming = model?.previewStreamState?.observeAsState()
        // Once camera stream starts, begin an 30 second timer before we enter "manual" mode
        LaunchedEffect(streaming?.value == PreviewView.StreamState.STREAMING) {
            if (streaming?.value == PreviewView.StreamState.STREAMING) {
                delay(30.seconds)
                if (true == model.isCameraRunning.value) {
                    model.cameraViewState.postValue(ICameraViewModel.CameraViewState.MANUAL)
                }
            }
        }

        Box(modifier = modifier.fillMaxSize()) {
            PrivateCameraView(model, modifier = modifier.align(Alignment.Center))
        }
        if (model?.cameraViewState?.value == ICameraViewModel.CameraViewState.AUTO) {
            WaitingView()
        }
    }
}

/**
 * CameraView displays a live camera feed in a composable view and sends as many pictures
 * as is available for analysis to BaseAnalyzer.
 * @param model: The CameraModel containing the PreviewView to render
 */
@Composable
private fun PrivateCameraView(
    model: ICameraViewModel?,
    modifier: Modifier = Modifier,
) {
    val ctx = LocalContext.current
    val config = LocalConfiguration.current
    val ar = when (getBestAspectRatio(getPhysicalAspectRatio(ctx))) {
        AspectRatio.RATIO_16_9 -> 16 / 9F
        AspectRatio.RATIO_4_3 -> 4 / 3F
        else -> 16 / 9F
    }
    val portrait = config.orientation == Configuration.ORIENTATION_PORTRAIT

    Box(modifier = modifier) {

        model?.let { model ->
            AndroidView(
                modifier = Modifier
                    .wrapContentHeight(Alignment.CenterVertically, unbounded = false)
                    .wrapContentWidth(Alignment.CenterHorizontally, unbounded = true)
                    .aspectRatio(
                        ratio = if (portrait) {
                            1 / ar
                        } else {
                            ar
                        }
                    )
                    .align(Alignment.Center),
                factory = {
                    model.previewView
                },
            )
            val state by model.previewStreamState.observeAsState()
            when (state) {
                null -> {}
                PreviewView.StreamState.IDLE -> {}
                PreviewView.StreamState.STREAMING -> {
                    LaunchedEffect(true) {
                        SdkContext.cameraReady.postValue(LandingPageTransition.READY)
                    }
                }
            }
        }
    }
}


/**
 * Continuously calls [requester] on first composition, then every 5 seconds
 */
@Composable
internal fun RequestCameraPermissionView(requester: () -> Unit) {
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    LaunchedEffect(key1 = true) {
        requester.invoke()
    }
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> {
                    CoroutineScope(Dispatchers.IO).launch {
                        delay(5.seconds)
                        requester.invoke()
                    }
                }

                else -> {
                    // do nothing
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }
}

@Preview
@Composable
private fun  CameraViewPreview() {
    Id365ScannerSdkTheme {
        val context = LocalContext.current
        PrivateCameraView(model = mockedCameraViewModel(context))
    }
}

@Preview
@Composable
private fun  CameraViewMissingPermissionsPreview() {
    Id365ScannerSdkTheme {
        val ctx = LocalContext.current
        CameraView(model = mockedCameraViewModel(ctx))
    }
}