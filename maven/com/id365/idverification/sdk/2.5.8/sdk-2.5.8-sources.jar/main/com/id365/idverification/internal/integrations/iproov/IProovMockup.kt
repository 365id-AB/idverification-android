package com.id365.idverification.internal.integrations.iproov

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import com.id365.idverification.R
import com.id365.idverification.internal.ui.theme.Id365ScannerSdkTheme
import com.id365.idverification.internal.viewmodel.IProovViewModel
import com.iproov.sdk.api.IProov


/**
 * Provides a mocked version of the IProov view. Gives us a way to preview
 * how the IProov "liveness" view will look like when we apply different color options in
 * IProovViewModel.getIProovOptions().
 */
@Preview
@Composable
internal fun IProovMockup() {
    Id365ScannerSdkTheme {
        val options = IProovViewModel.getIProovOptions(MaterialTheme.colorScheme)
        Box {
            Box(modifier = Modifier
                .height(100.dp)
                .fillMaxWidth()
                .zIndex(1F)
                .align(Alignment.TopCenter)
            ) {
                Text(
                    text = options.title,
                    color = Color(options.titleTextColor),
                    modifier = Modifier.align(Alignment.Center)
                )
                Image(
                    imageVector = ImageVector.vectorResource(id = R.drawable.ic_logo_color),
                    contentDescription = "",
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .padding(end = 10.dp)
                        .width(50.dp)
                )
            }
            Box(modifier = Modifier
                .fillMaxSize()
                .zIndex(0F)
                .background(color = Color(options.surroundColor).copy(alpha = .7F))
            ) {
                DrawOvalShape(options)
                Image(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 50.dp)
                        .offset(y = 50.dp),
                    imageVector = ImageVector.vectorResource(id = R.drawable.faceid),
                    contentDescription = ""
                )
                DrawPrompt(
                    options = options,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .offset(y = (-200).dp)
                )
            }
            Box(modifier = Modifier
                .height(100.dp)
                .fillMaxWidth()
                .zIndex(1F)
                .align(Alignment.BottomCenter)
            )
            Image(
                modifier = Modifier.fillMaxWidth(0.1F).offset(x = 20.dp, y = 38.dp),
                colorFilter = ColorFilter.tint(Color(options.closeButton.colorTint)),
                painter = painterResource(id = (options.closeButton.icon as IProov.Options.Icon.ResourceIcon).imageID), contentDescription = ""
            )
        }
    }
}

@Composable
internal fun DrawPrompt(options: IProov.Options, modifier: Modifier = Modifier) {
    Box(modifier = modifier
        .background(color = Color(options.promptBackgroundColor), shape = RoundedCornerShape(60.dp))
    ) {
        Text(
            text = "Fill the oval with your face",
            style = TextStyle(
                color = Color(options.promptTextColor),
            ),
            modifier = Modifier.padding(all = 10.dp)
        )
    }
}

@Composable
internal fun DrawOvalShape(options: IProov.Options) {
    val color = options.livenessAssurance.ovalStrokeColor
    val background = options.surroundColor
    Canvas(modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 40.dp, vertical = 210.dp)
    ) {
        drawOval(
            color = Color(background),
            topLeft = Offset(0f, 0f),
            size = size,
        )
        drawOval(
            color = Color(color),
            style = Stroke(width = 15f, cap = StrokeCap.Round),
            topLeft = Offset(0f, 0f),
            size = size,
        )
    }
}
