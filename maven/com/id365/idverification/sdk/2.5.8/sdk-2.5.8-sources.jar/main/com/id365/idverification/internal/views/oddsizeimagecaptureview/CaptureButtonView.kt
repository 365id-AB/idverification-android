package com.id365.idverification.internal.views.oddsizeimagecaptureview

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
internal fun ShutterButton(
    toggleCaptureButton: () -> Unit,
    modifier: Modifier = Modifier,
    onCaptureImage: () -> Unit,
) {
    val mainColor: Color = MaterialTheme.colorScheme.inverseOnSurface
    val secondaryColor = MaterialTheme.colorScheme.inverseSurface.copy(0.8F)
    Box(
        modifier = modifier
            .size(72.dp)
            .clip(CircleShape)
            .clickable(onClick = {
                onCaptureImage()
                toggleCaptureButton()
            })
            .background(mainColor)
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp)
        ) {
            drawCircle(
                color = secondaryColor,
                radius = size.minDimension / 2
            )

            drawCircle(
                color = mainColor,
                radius = size.minDimension / 2 - 8.dp.toPx()
            )
        }
    }
}