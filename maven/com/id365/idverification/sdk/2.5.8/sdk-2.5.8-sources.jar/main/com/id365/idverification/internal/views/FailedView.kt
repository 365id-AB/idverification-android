package com.id365.idverification.internal.views

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

/**
 * Shows when an SDK transaction failed. Will not be visible for long,
 * as the callback to the calling app should dismiss the SDK.
 */
@Composable
internal fun FailedView() {
    Box(modifier = Modifier.fillMaxSize())
}