package com.id365.idverification.internal.views.informationview

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.id365.idverification.internal.communication.UserMessage
import com.id365.idverification.internal.ui.theme.Id365ScannerSdkTheme

@Composable
internal fun InformationTextView(
    userMessage: UserMessage,
    modifier: Modifier = Modifier,
    alignment: Alignment.Horizontal = Alignment.Start
) {
    Column(
        modifier = modifier.fillMaxWidth().testTag("InformationTextView"),
        horizontalAlignment = alignment
    ) {
        // Title
        Text(modifier = Modifier
            .padding(bottom=10.dp),
            text = userMessage.title,
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onSurface
        )
        val textAlign: TextAlign = when(alignment) {
            Alignment.Start -> TextAlign.Start
            Alignment.CenterHorizontally -> TextAlign.Center
            Alignment.End -> TextAlign.End
            else -> TextAlign.Start
        }
        if (userMessage.level == UserMessage.Level.WARNING) {
            WarningTextView(userMessage.subtitle, textAlign)
        } else {
            // Text
            Text(
                modifier = Modifier.align(alignment).padding(bottom = 10.dp),
                text = userMessage.subtitle,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = textAlign
            )
        }

    }
}


@Preview
@Composable
private fun InformationTextViewPreview() {
    val ctx = LocalContext.current
    Id365ScannerSdkTheme {
        Box(
            modifier=Modifier
                .fillMaxSize()
                .background(color=MaterialTheme.colorScheme.background),
            contentAlignment = Alignment.Center
        ) {
            InformationTextView(
                userMessage = UserMessage(
                    title = "Scan frontside",
                    subtitle = "Face match failed\nPlease try again",
                    level = UserMessage.Level.WARNING,
                )
            )
        }
    }
}

@Preview
@Composable
private fun InformationTextViewWithSubtitlePreview() {
    val ctx = LocalContext.current
    Id365ScannerSdkTheme {
        Box(
            modifier=Modifier
                .fillMaxSize()
                .background(color=MaterialTheme.colorScheme.background),
            contentAlignment = Alignment.Center
        ) {
            InformationTextView(
                userMessage = UserMessage(
                    title = "Scan frontside",
                    subtitle = "Some line of text",
                    level = UserMessage.Level.INFORMATION,
                )
            )
        }
    }
}