
import com.id365.idverification.internal.views.microblink.ReticleView

import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.AnimatedVisibilityScope
import androidx.compose.animation.Crossfade
import androidx.compose.animation.EnterExitState
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.TweenSpec
import androidx.compose.animation.core.animateDp
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.id365.idverification.IdVerification
import com.id365.idverification.internal.communication.Task
import com.id365.idverification.internal.communication.UserMessage
import com.id365.idverification.internal.core.SdkContext.sdk
import com.id365.idverification.internal.model.CameraConstants.CAMERA_MARGINS
import com.id365.idverification.internal.model.CameraConstants.DOCUMENT_CAMERA_FOCUS_AREA_RATIO
import com.id365.idverification.internal.model.CameraConstants.ID1_CAMERA_FOCUS_AREA_RATIO
import com.id365.idverification.internal.model.CameraConstants.ID3_CAMERA_FOCUS_AREA_RATIO
import com.id365.idverification.internal.ui.theme.AppColors
import com.id365.idverification.internal.ui.theme.Id365ScannerSdkTheme
import com.id365.idverification.internal.viewmodel.IMicroBlinkViewModel
import com.id365.idverification.internal.views.InformationOverlayView
import com.id365.idverification.internal.views.RoundedRectangleView
import com.id365.idverification.internal.views.ViewFinderMask
import com.id365.idverification.internal.views.WarningBoxView


@OptIn(ExperimentalAnimationApi::class)
@Composable
internal fun CameraOverlayView(
    modifier: Modifier = Modifier,
    model: IMicroBlinkViewModel = sdk.koin.get()
) {
    val overlayColor: Color = MaterialTheme.colorScheme.inverseSurface.copy(alpha = 0.65F)
    val didCaptureImage = remember { mutableStateOf(false) }
    LaunchedEffect(key1 = model.didCaptureImage.value) {
        if (model.didCaptureImage.value) {
            didCaptureImage.value = true
        }
    }
    Column(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(0.6f)
        ) {
            ViewFinderMask(
                modifier = modifier,
                color = overlayColor
            ) {
                val ar = getAspectRatio(model.getDocumentSizeType())
                val marginX = CAMERA_MARGINS.dp
                val marginY = CAMERA_MARGINS.dp / ar

                Column(
                    modifier = Modifier
                        .fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {

                    // WARNING MESSAGE (wrap content)
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .background(overlayColor),
                        contentAlignment = Alignment.BottomCenter
                    ) {
                        WarningMessage(
                            model = model
                        )
                    }

                    // RETICLE (takes only its aspectRatio-required space)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(ar),
                        contentAlignment = Alignment.BottomCenter
                    ) {
                        RoundedRectangleView(
                            modifier = Modifier.fillMaxSize(),
                            padding = PaddingValues(horizontal = marginX, vertical = marginY),
                            color = overlayColor
                        )

                        FadeAndScaleOut(
                            modifier = Modifier.fillMaxSize(),
                            visible = !didCaptureImage.value
                        ) {
                            Box(
                                modifier = Modifier.padding(
                                    horizontal = marginX,
                                    vertical = marginY
                                )
                            ) {
                                val borderWidth by transition.animateDp(label = "animateReticleBorder") {
                                    when (it) {
                                        EnterExitState.PreEnter -> 8.dp
                                        EnterExitState.Visible -> 8.dp
                                        EnterExitState.PostExit -> 16.dp
                                    }
                                }
                                ReticleView(
                                    borderColor = getCameraEdgeBorderColor(didCaptureImage.value),
                                    strokeWidth = borderWidth
                                )
                            }
                        }
                    }

                    // SPACE BELOW RETICLE (fills remaining space)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .background(overlayColor)
                    )
                }
            }
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(0.4f)
                .background(overlayColor)
        ) {
            ViewFinderMask(
                modifier = modifier,
                color = overlayColor
            ) {
                InformationOverlayView(
                    modifier = modifier
                        .fillMaxWidth()
                        .fillMaxHeight()
                        .align(Alignment.BottomCenter),
                    model = model
                )
            }
        }
    }
}

@Composable
private fun getCameraEdgeBorderColor(captured: Boolean): Color =
    when (captured) {
        true -> AppColors.green
        else -> MaterialTheme.colorScheme.inverseOnSurface
    }
private fun getAspectRatio(documentSizeType: IdVerification.DocumentSizeType): Float = when (documentSizeType) {
    IdVerification.DocumentSizeType.ID1 -> ID1_CAMERA_FOCUS_AREA_RATIO
    IdVerification.DocumentSizeType.DOCUMENT -> DOCUMENT_CAMERA_FOCUS_AREA_RATIO
    else -> ID3_CAMERA_FOCUS_AREA_RATIO
}

@Composable
internal fun WarningMessage(
    modifier: Modifier = Modifier,
    model: IMicroBlinkViewModel
) {
    Box(
        modifier = modifier
            .wrapContentHeight()
            .fillMaxWidth(),
    ) {
        val warningStatusMessage by model.warningStatusMessage
        AnimatedVisibility(
            visible = model.warningStatus.value,
            enter = fadeIn(
                animationSpec = TweenSpec(
                    durationMillis = 10,
                    easing = LinearOutSlowInEasing
                )
            ),
            exit = fadeOut(
                animationSpec = TweenSpec(
                    durationMillis = 3000,
                    delay = 1000,
                    easing = LinearOutSlowInEasing
                )
            )
        ) {
            warningStatusMessage?.let {
                Crossfade(
                    targetState = it,
                    animationSpec = TweenSpec(
                        delay = 1000,
                        easing = LinearOutSlowInEasing
                    ),
                    label = "warningStatusLabel"
                ) { msg ->
                    WarningBoxView(
                        message = msg,
                        textColor = MaterialTheme.colorScheme.onSurface,
                        boxBackgroundColor = MaterialTheme.colorScheme.surface,
                    )
                }
            }
        }
    }
}

@Composable
internal fun FadeAndScaleOut(
    modifier: Modifier = Modifier,
    visible: Boolean,
    content: @Composable AnimatedVisibilityScope.() -> Unit
) {
    AnimatedVisibility(
        visible = visible,
        modifier = modifier,
        exit = scaleOut(targetScale = 1.10f) + fadeOut(),
        enter = fadeIn(),
        content = content
    )
}

@Preview(widthDp = 900, heightDp = 1600)
@Preview(name = "4/3", widthDp = 768, heightDp = 1024)
@Preview
@Composable
private fun MicroblinkOverlayViewPreview() {
    var show by remember { mutableStateOf(true) }
    val model by remember {
        mutableStateOf(object : IMicroBlinkViewModel{
            override fun startMicroBlinkSdk(previewView: PreviewView) {}
            override fun getDocumentSizeType() = IdVerification.DocumentSizeType.ID3
            override val didCaptureImage = mutableStateOf(false)
            override val warningStatusMessage = mutableStateOf<String?>("You are holding it wrong")
            override val warningStatus = mutableStateOf(true)
            override val taskData: MutableState<Task>
                get() = mutableStateOf(Task(nextTask = Task.Level.FRONT_SIDE, message = UserMessage("ejh", "hej"), taskPayload = "asdasd"))
            override val infoText = mutableStateOf("Take photo")
            override val playAnimation = mutableStateOf(true)
            override val buttonCb: () -> Unit = {
                warningStatusMessage.value = when(warningStatusMessage.value) {
                    "You are holding it wrong" -> "The sun is blinding me"
                    "The sun is blinding me" -> "The gnomes are at it again"
                    else -> "You are holding it wrong"
                }
            }
            override val buttonLabel = "Button"
            override val buttonEnabled = mutableStateOf(true)
            override fun close() {}
        })
    }
    Id365ScannerSdkTheme {
        if (show) {
            Box(modifier=Modifier.fillMaxSize()) {
                CameraOverlayView(
                    modifier = Modifier.fillMaxSize(),
                    model = model
                )
            }
        }
    }
}
