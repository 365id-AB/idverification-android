package com.id365.idverification.internal.integrations.iproov

/**
 * SDK internal representation of an EnrolUserResponse
 */
internal data class EnrolUserResponse(
    val success: Boolean,
    val iProovToken: String = "",
)