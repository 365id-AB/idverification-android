package com.id365.idverification

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import com.id365.idverification.internal.logging.AppLog
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.annotation.Keep
import com.id365.idverification.IdVerification.IdVerificationView
import com.id365.idverification.internal.utils.CommonUtils.DebugTAG
import com.id365.idverification.internal.ui.theme.Id365ScannerSdkTheme
import com.id365.idverification.internal.views.ErrorView
import com.id365.idverification.IdVerification.sendIntent
import com.id365.idverification.IdVerification.start
import com.id365.idverification.IdVerification.stop
import com.id365.idverification.errors.IdVerificationClientException
import com.id365.idverification.errors.IdVerificationException
import com.id365.idverification.errors.IdVerificationInvalidTokenException
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * One of the entry points for the SDK. When starting the SDK as an activity.
 * Should be called with an Intent containing appToken and one of locationName or locationId
 */
@Keep
internal class IdVerificationActivity : ComponentActivity(), IdVerificationEventHandler {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        AppLog.d(DebugTAG, "Creating Scanner SDK activity")
        if (allPermissionsGranted()) {
            setViewContent()
        } else {
            val request = registerForActivityResult(
                ActivityResultContracts.RequestMultiplePermissions()
            ) {
                val deniedPermissions = it.filter { perm -> !perm.value }
                if (deniedPermissions.isNotEmpty()) {
                    deniedPermissions.keys.forEach { perm ->
                        AppLog.e(DebugTAG, "Missing permission: $perm")
                    }
                    setMissingPermissionsViewContent(deniedPermissions)
                } else {
                    setViewContent()
                }
            }
            request.launch(REQUIRED_PERMISSIONS)
        }
    }

    /**
     * Send registered intents to Sdk
     */
    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        AppLog.d(DebugTAG, "Received intent: $intent")
        intent?.let {
            sendIntent(intent)
        }
    }

    private fun setViewContent() {
        try {
            val appToken: String = intent.getStringExtra("token")!!
            val locationName: String = intent.getStringExtra("locationName") ?: ""
            val locationId = intent.getIntExtra("locationId", 0)

            val map: HashMap<String, String> = hashMapOf(
                Pair("Token", appToken),
                Pair("LocationName", locationName),
                Pair("LocationId", "$locationId"),
            )
            val request = IdVerificationRequest.fromJson(Json.encodeToString(map))

            IdVerification.setCustomTheme()
            start(application, request, documentSizeType = IdVerification.DocumentSizeType.DOCUMENT, eventHandler = this)

            setContent {
                Id365ScannerSdkTheme(darkTheme = false) {
                    IdVerificationView()
                }
            }
        } catch (e: NullPointerException) {
            AppLog.e(DebugTAG, "No token provided!")
            intent.putExtra(IdVerificationResultContract.errorIntent, IdVerificationResult(
                transactionId = "",
                error = IdVerificationInvalidTokenException("Attempted to start the SDK without a valid session token")
            ).asJson())
            setResult(RESULT_CANCELED, intent)
            stop()
            finish()
        } catch(e: Exception) {
            AppLog.e(DebugTAG, "Unhandled exception: $e", e)
            intent.putExtra(IdVerificationResultContract.errorIntent, IdVerificationResult(
                transactionId = "",
                error = IdVerificationClientException(exception=e)
            ).asJson())
            setResult(RESULT_CANCELED, intent)
            stop()
            finish()
        }
    }

    private fun setMissingPermissionsViewContent(missing: Map<String, Boolean>) {
        val message = missing.map { perm -> "${perm.key} -> ${perm.value}" }
        val fullErrorMessage = "Missing Permissions:\n\n$message"
        setContent {
            Id365ScannerSdkTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    ErrorView(fullErrorMessage)
                }
            }
        }
    }

    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(
            baseContext, it
        ) == PackageManager.PERMISSION_GRANTED
    }

    companion object {
        internal val REQUIRED_PERMISSIONS = arrayOf(
            Manifest.permission.CAMERA,
            Manifest.permission.NFC
        )
    }

    override fun onStarted() {}

    override fun onClosed() {}

    override fun onUserDismissed() {
        val intent = Intent()
        intent.putExtra(IdVerificationResultContract.transactionIdIntentString, "{}")
        setResult(RESULT_CANCELED, intent)
        stop()
        finish()
    }

    override fun onException(exception: IdVerificationException) {
        val intent = Intent()
        intent.putExtra(IdVerificationResultContract.transactionIdIntentString, "{}")
        intent.putExtra(IdVerificationResultContract.errorIntent, Json.encodeToString(exception))

        setResult(2, intent)
        stop()
        finish()
    }

    override fun onCompleted(result: IdVerificationResult) {
        val intent = Intent()
        intent.putExtra(IdVerificationResultContract.transactionIdIntentString, result.asJson())

        setResult(RESULT_OK, intent)
        stop()
        finish()
    }

    override fun onDocumentFeedback(documentType: DocumentType, countryCode: String) {
        Log.d("IdVerificationActivity", "onDocumentFeedback - Type: ${documentType.name} - Country: $countryCode")
    }

    override fun onNfcFeedback(nfcFeedback: NfcFeedback, expiryDate: String) {
        Log.d("IdVerificationActivity", "onNfcFeedback ${nfcFeedback.name} - expiry date: $expiryDate")
    }

    override fun onNfcFeedbackWithDataTypes(
        nfcFeedback: NfcFeedback,
        expiryDate: String,
        dataTypes: Int
    ) {
        Log.d("IdVerificationActivity", "onNfcFeedbackWithDataTypes - nfc feedback: ${nfcFeedback.name} - expiry date: $expiryDate - dataTypes: $dataTypes")
    }

    override fun onFaceMatchFeedbackWithSource(
        faceMatchFeedback: FacematchFeedback,
        faceMatchSource: FacematchSource
    ) {
        Log.d("IdVerificationActivity", "onFaceMatchFeedbackWithSource - feedback: ${faceMatchFeedback.name} - source: ${faceMatchSource}")
    }

    override fun onFaceMatchFeedback(faceMatchFeedback: FacematchFeedback) {
        Log.d("IdVerificationActivity", "onFaceMatchFeedback - feedback: ${faceMatchFeedback.name}")
    }

    override fun onTransactionCreated(transactionId: String) {
        Log.d("IdVerificationActivity", "onTransactionCreated $transactionId")
    }
}

