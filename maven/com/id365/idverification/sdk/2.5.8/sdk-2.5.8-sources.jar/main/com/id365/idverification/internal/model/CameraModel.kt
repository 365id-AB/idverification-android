package com.id365.idverification.internal.model

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import android.graphics.RectF
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.util.Size
import android.view.View
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.runtime.mutableStateOf
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.id365.idverification.internal.analysis.QrCodeAnalyzer
import com.id365.idverification.internal.core.IdScannerKoinComponent
import com.id365.idverification.internal.logging.AppLog
import com.id365.idverification.internal.model.CameraUtils.calculateCropImage
import com.id365.idverification.internal.model.CameraUtils.getBestAspectRatio
import com.id365.idverification.internal.model.CameraUtils.rotate
import com.id365.idverification.internal.model.CameraUtils.setFocusRegion
import com.id365.idverification.internal.utils.CommonUtils.DebugTAG
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.koin.core.component.inject


/**
 * Here we configure the backing model describing all the guts behind a camera view
 * @param [context]: The context from which we get the camera provider and tie the preview to
 * @param [lifecycleOwner]: The camera lifecycle is tied to this Owner.
 */
internal class CameraModel(
    val context: Context,
    override val lifecycleOwner: LifecycleOwner,
    ar: Float,
) : ICameraModel, IdScannerKoinComponent() {

    private val transactionModel: ITransactionModel by inject()

    override var rootView: Size = Size(1, 1)

    private val _preview = PreviewView(context).apply {
        implementationMode = PreviewView.ImplementationMode.COMPATIBLE
    }
    private val deviceResolution: Size = CameraUtils.getDeviceResolution(context)
    private val highResAnalyzer =
        QrCodeAnalyzer(model = this, deviceResolution = deviceResolution)

    /** ICameraModel implementations */
    override val previewView: View
        get() = _preview

    override val previewStreamState: LiveData<PreviewView.StreamState>
        get() = _preview.previewStreamState

    override val cameraCaptureSize: Size =
        CameraUtils.getCameraMaxSupportedResolution(context = context)

    override val luminanceIsAcceptable = mutableStateOf(true)

    override fun setLuminanceIsAcceptable(acceptable: Boolean) {
        luminanceIsAcceptable.value = acceptable
    }

    override val isCameraRunning = MutableLiveData(false)

    override var regionOfInterest: Rect = calculateCropImage(
        cameraImage = cameraCaptureSize,
        rootView = deviceResolution
    )

    private val normalizedRoi: RectF
        get() {
            return RectF(
                regionOfInterest.left.toFloat() / cameraCaptureSize.width,
                regionOfInterest.top.toFloat() / cameraCaptureSize.height,
                regionOfInterest.right.toFloat() / cameraCaptureSize.width,
                regionOfInterest.bottom.toFloat() / cameraCaptureSize.height,
            )
        }

    var pictureTaken = false

    /** To configure the camera */
    private val future = ProcessCameraProvider.getInstance(context)

    override fun detectionCallback(
        bitmap: Bitmap,
        debugBitmap: Bitmap?,
        manual: Boolean,
        roi: Rect,
    ) {
        // Do nothing. This file might be removed in a future refactoring, but we keep it for now
    }

    /**
     * Configuring the Preview Usecase is as simple as configuring where to put the previewed images
     */
    @ExperimentalCamera2Interop
    val previewUsecase: Preview by lazy {
        val builder = Preview.Builder()
        val camera2Interop = Camera2Interop.Extender(builder)
        val characteristics = CameraUtils.getCameraCharacteristics(context)
        if (characteristics.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)
                ?.contains(CameraCharacteristics.CONTROL_VIDEO_STABILIZATION_MODE_ON) == true
        ) {
            camera2Interop.setCaptureRequestOption(
                CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE,
                CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON
            )
        }

        if (characteristics.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)
                ?.contains(CameraCharacteristics.LENS_OPTICAL_STABILIZATION_MODE_ON) == true
        ) {
            camera2Interop.setCaptureRequestOption(
                CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
                CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON
            )
        }

        builder.setTargetAspectRatio(getBestAspectRatio(ar))
            .setFocusRegion(normalizedRoi)
            .build().apply {
                setSurfaceProvider(_preview.surfaceProvider)
            }
    }

    /**
     * Setup and configure the image analysis use case. We prefer a high resolution for analysis
     */

    @ExperimentalCamera2Interop
    val imageAnalysis: ImageAnalysis by lazy {
        ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888)
            .setTargetResolution(cameraCaptureSize.rotate())
            .build()
            .apply {
                val executor = ContextCompat.getMainExecutor(context)
                setAnalyzer(executor, highResAnalyzer)
            }
    }

    /**
     *  Selects the default back-facing camera for our use cases.
     */
    val cameraSelector = CameraSelector.Builder()
        .requireLensFacing(CameraSelector.LENS_FACING_BACK)
        .build()

    /**
     * Here we start the camera
     */
    @ExperimentalCamera2Interop
    override fun start() {
        pictureTaken = false
        future.addListener({
            val provider = future.get()

            val previewWasBound = provider.isBound(previewUsecase)
            val analysisWasBound = provider.isBound(imageAnalysis)
            if (previewWasBound && analysisWasBound) {
                return@addListener
            } else {
                AppLog.d(
                    CameraModel.DebugTAG,
                    "rebinding usecase because preview: $previewWasBound, analysis: $analysisWasBound"
                )
            }

            provider.unbindAll()
            CoroutineScope(Dispatchers.Main).launch {
                try {
                    AppLog.d(CameraModel.DebugTAG, "bindToLifecycle")
                    provider.bindToLifecycle(
                        lifecycleOwner,
                        cameraSelector,
                        previewUsecase,
                        imageAnalysis
                    )
                    isCameraRunning.postValue(true)
                } catch (e: Exception) {
                    transactionModel.stop(e)
                }
            }
        }, ContextCompat.getMainExecutor(context))
    }

    override fun stop() {
        future.addListener({
            val provider = future.get()
            if (provider.isBound(previewUsecase)) {
                provider.unbindAll()
            }
        }, ContextCompat.getMainExecutor(context))
    }

    override fun close() {
        stop()
    }

    companion object {
        /** In milliseconds, how long should the vibration last */
        const val VIBRATOR_DURATION: Long = 100
    }
}
