package com.id365.idverification.internal.views.oddsizeimagecaptureview

import androidx.compose.foundation.layout.size
import androidx.compose.material3.IconButton
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.id365.idverification.R
import kotlinx.coroutines.delay

@Composable
internal fun CloseButtonView(
    modifier: Modifier = Modifier,
    iconId: Int = R.drawable.xmark,
    onClick: () -> Unit,
) {
    var buttonEnabled by rememberSaveable { mutableStateOf(false) }
    var buttonTint by remember { mutableStateOf(Color.Gray) }

    LaunchedEffect(Unit) {
        delay(1500)
        buttonEnabled= true
        buttonTint = Color.Red
    }
    IconButton(
        onClick = onClick,
        modifier = modifier,
        enabled = buttonEnabled
    ) {
        Icon(
            painter = painterResource(id = iconId),
            contentDescription = "Close button",
            modifier = Modifier.size(44.dp),
            tint = buttonTint
        )
    }
}