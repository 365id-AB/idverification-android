package com.id365.idverification

import androidx.annotation.Keep
import com.id365.idverification.errors.IdVerificationException

/**
 * This interface should be implemented by users of the SDK. The methods within will be called by
 * the SDK during key events over the lifetime of a transaction.
 */
@Keep
interface IdVerificationEventHandler {

    /**
     * Called when the SDK has finished initializing and is ready to be displayed on the device.
     */
    fun onStarted()

    /**
     * Called when the SDK has finished cleaning up all used resources after a transaction.
     */
    fun onClosed()

    /**
     * Called when the user exits the SDK using the back button.
     */
    fun onUserDismissed()

    /**
     * Called when there is an error communicating with 365id cloud services.
     *
     * @param exception Generated message describing the issue
     */
    fun onException(exception: IdVerificationException)

    /**
     * Called when a transaction finished successfully
     *
     * @param result Contains a transaction Id that can be used when polling 365id's IdQuery service
     *               for information and verdict for this transaction.
     */
    fun onCompleted(result: IdVerificationResult)

    /**
     * Called when the document identification process has completed
     *
     * @param documentType Type of document
     * @param countryCode 3 letter identification code for the issuing country
     */
    fun onDocumentFeedback(documentType: DocumentType, countryCode: String)

    /**
     * Called when the Nfc process has completed
     *
     * @param nfcFeedback Feedback from the Nfc process
     * @param expiryDate Expiry date of the document (YYYYMMDD).
     */
    fun onNfcFeedback(nfcFeedback: NfcFeedback, expiryDate: String)

    /**
     * Called when the Nfc process has completed
     *
     * @param nfcFeedback Feedback from the Nfc process.
     * @param expiryDate Expiry date of the document (YYYYMMDD).
     * @param dataTypes The types of data read from the NFC chip on the document represented by a bitfield.
     */
    fun onNfcFeedbackWithDataTypes(nfcFeedback: NfcFeedback, expiryDate: String, dataTypes: Int) {}

    /**
     * Called when the face match process has completed
     *
     * @param faceMatchFeedback Feedback from the face match process
     */
    fun onFaceMatchFeedback(faceMatchFeedback: FacematchFeedback)

    /**
     * Called when the face match process has completed
     *
     * @param faceMatchFeedback Feedback from the face match process
     * @param faceMatchSource The image source used in the match process
     */
    fun onFaceMatchFeedbackWithSource(faceMatchFeedback: FacematchFeedback, faceMatchSource: FacematchSource) {}

    /**
     * Called when a transaction is created
     *
     * @param transactionId Transaction Id
     */
    fun onTransactionCreated(transactionId: String)
}
