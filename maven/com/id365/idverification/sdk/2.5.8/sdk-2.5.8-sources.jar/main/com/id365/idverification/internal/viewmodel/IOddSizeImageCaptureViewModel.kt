package com.id365.idverification.internal.viewmodel

import android.content.Context
import android.graphics.Bitmap
import androidx.compose.ui.geometry.Rect
import android.net.Uri
import android.view.View
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.runtime.MutableState
import androidx.compose.ui.unit.Dp
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import java.io.Closeable

internal interface IOddSizeImageCaptureViewModel : Closeable {

    /**
     * Starts the camera previewView.
     */
    fun startCamera(previewView: PreviewView)

    /**
     * Function that captures an image as a bitmap.
     */
    fun captureImage(callback: (Bitmap) -> Unit)

    /**
     * Rotates the captured bitmap.
     */
    fun rotateBitmap(bitmap: Bitmap, degrees: Float): Bitmap

    /**
     * Called when the user accepts the captured image(Checkbox button). This function will crop the image to fit the reticle.
     */
    fun acceptImage(bitmap: Bitmap)
    fun setCaptureArea(rect: Rect)
    fun setStatusBarHeight(height: Int)
    fun stopCamera()
    fun buttonCb()
}