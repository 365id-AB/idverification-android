package com.id365.idverification.internal.communication

import com.id365.idverification.internal.logging.AppLog
import androidx.annotation.Keep
import com.id365.idverification.internal.utils.CommonUtils.DebugTAG
import com.id365.idverification.errors.IdVerificationSessionTokenExpiredException
import com.id365.idverification.internal.core.IdScannerKoinComponent
import com.id365.idverification.internal.model.ITransactionModel
import kotlinx.serialization.Serializable
import org.koin.core.component.inject
import java.util.*

/**
 * Internal representation of a session token
 */
@Keep
@Serializable
internal data class SessionToken(
    val token: String
) : IdScannerKoinComponent() {
    private val header: Header
    private val claims: Claims
    private val footer: Footer
    private val minimumSecondsOfValidToken: Long = 60
    private val transactionModel: ITransactionModel by inject()

    init {
        val (header, claims, footer) = token.split(".")
        this.header = Header(header)
        this.footer = Footer(footer)
        this.claims = try {
            Claims.fromJson(claims)
        } catch(e: Exception) {
            Claims()
        }
    }

    constructor(
        header: Header,
        claims: Claims,
        footer: Footer,
    ) : this("$header.$claims.$footer")

    constructor() : this("${Header()}.${Claims()}.${Footer()}")

    /**
     * Property accessors
     */
    val allowDebugging: Boolean
        get() = claims.AllowDebugging == "true"

    /**
     * Transaction ID
     */
    val transactionId: String
        get() = "$sourceId-$archiveId"

    /**
     * Source ID
     */
    val sourceId: String
        get() = claims.SourceId.uppercase()

    /**
     * Archive ID
     */
    val archiveId: String
        get() = claims.ArchiveId.uppercase()

    /**
     * Vendor ID
     */
    val vendorId: String
        get() = claims.vendorId

    /**
     * Localization
     */
    val lang: String
        get() = claims.lang

    /**
     * If this session is allowed to do NFC
     */
    val checkNfc: Boolean
        get() = claims.CheckNfc == "1"

    /**
     * If this session is allowed to do face matching using IProov
     */
    val checkIProov: Boolean
        get() = claims.CheckIProov == "1"

    /**
     * IProov parameter for assurance type
     */
    val iProovAssuranceType: String
        get() = claims.iProovAssuranceType

    /**
     * IProov parameter for required matching level
     */
    val iProovFaceMatchingLevel: String
        get() = claims.iProovFaceMatchingLevel

    /**
     * IProov parameter for required anti spoofing level
     */
    val iProovAntiSpoofingLevel: String
        get() = claims.iProovAntiSpoofingLevel

    val expired: Boolean
        get() {
            // TODO: Interpret JWT expiry and compare to current time
            return false
        }

    /**
     * MicroBlink licenseKey needed to activate their framework.
     */
    val microBlinkLicenseKey: String
        get() = claims.MicroBlinkLicenseKey

    /** Get number of seconds left of the session token until it expires. */
    private fun getSecondsLeftOfToken(): Long {
        val oneSecondMillis = 1000L
        val tokenExpireDate = Date(claims.exp * oneSecondMillis)
        val dateNow = Date()
        if (tokenExpireDate.compareTo(dateNow) == -1) {
            AppLog.d(DebugTAG, "Session token has already expired.")
            return 0
        }
        val secondsLeftOfToken = tokenExpireDate.time / oneSecondMillis - dateNow.time / oneSecondMillis
        AppLog.d(DebugTAG, "Session token has $secondsLeftOfToken seconds left until it expires.")
        return secondsLeftOfToken
    }

    /** Validate the session token. If its not valid we will exit the SDK. */
    fun validateExpireDateOfToken() {
        if (getSecondsLeftOfToken() > minimumSecondsOfValidToken) return
        AppLog.d(DebugTAG, "Session token $minimumSecondsOfValidToken minimumSecondsOfValidToken passed.")
        transactionModel.handleError(IdVerificationSessionTokenExpiredException())
    }

    @Keep
    @Serializable
    internal data class Header(
        val h0: String = "header"
    ) {
        override fun toString(): String {
            return h0
        }
    }

    @Keep
    @Serializable
    internal data class Footer(
        val f0: String = "footer"
    ) {
        override fun toString(): String {
            return f0
        }
    }
}
