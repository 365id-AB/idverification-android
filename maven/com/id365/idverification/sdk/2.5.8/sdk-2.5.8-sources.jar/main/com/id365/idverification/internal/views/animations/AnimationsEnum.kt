package com.id365.idverification.internal.views.animations

internal enum class AnimationsEnum{
    // Animations shown before the step is to be performed
    PrepareId3,
    PrepareId1Frontside,
    PrepareId1Backside,
    PrepareDocument,
    prepareOddSizedDocument,
    PrepareNfc,
    PrepareFacematch,

    // Animations shown while the view is active
    InstructionId3,
    InstructionId1Frontside,
    InstructionId1Backside,
    instructionOddSizedDocument,
    InstructionDocument,
    InstructionNfc,

    // Loading animations shown after a step has finished processing
    LoadingImageCapture,
    LoadingNfc,
    LoadingFacematch,
    LoadingGeneric,
}
