package com.id365.idverification.internal.dida

/**
 * Represents the response message as received from DIDA. See:
 * https://gitlab.365id.com/365id/dida/-/blob/main/_365id.Dida.Contracts/DidaAssessmentResponse.cs
 */
internal class DidaResponse(
    val assessmentStatus: DidaStatus,
    val compatibleProviders: List<DidaProviderSignature>
) {
    override fun toString(): String {
        return "$assessmentStatus ${
            compatibleProviders.joinToString(", ") {
                "${it.ProviderId}: ${it.ProviderName}"
            }
        }"
    }
}
