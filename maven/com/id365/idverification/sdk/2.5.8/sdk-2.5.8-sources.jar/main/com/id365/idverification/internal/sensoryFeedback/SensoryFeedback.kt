package com.id365.idverification.internal.sensoryFeedback

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaActionSound
import android.media.MediaPlayer
import android.net.Uri
import android.os.*
import com.id365.idverification.internal.logging.AppLog
import com.id365.idverification.internal.utils.CommonUtils.DebugTAG
import androidx.core.net.toUri


internal class SensoryFeedback(): ISensoryFeedback {

    var mPlayer: MediaPlayer? = null

    /**
     *This function plays the custom shutter sound using the STREAM_SYSTEM volume setting.
     */
    override fun playShutterSound(context: Context) {

        try {
            if (mPlayer == null) {
                val fileName = "android.resource://" + context.packageName + "/raw/shutter_sound"
                mPlayer = MediaPlayer()
                mPlayer!!.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setLegacyStreamType(AudioManager.STREAM_SYSTEM)
                        .build()
                )
                //player.reset() //uncomment this line if you use local variable of MediaPlayer
                mPlayer!!.setDataSource(context, fileName.toUri())
                mPlayer!!.prepare()
                mPlayer!!.start()
            } else {
                mPlayer!!.start()
            }
        } catch (e:java.lang.Exception) {
            AppLog.e(DebugTAG, "Error while playing custom shutter sound", e)

            // I case of some error when playing the custom shutter sound, the default Android shutter sound will be played.
            MediaActionSound().play(MediaActionSound.SHUTTER_CLICK)
        }
    }

    /**
     * Tell the device to vibrate
     */
    @Suppress("DEPRECATION")
    override fun vibrate(context: Context) {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager =
                context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            val vibrator = vibratorManager.defaultVibrator

            vibrator.vibrate(
                VibrationEffect.createOneShot(
                    VIBRATOR_DURATION,
                    VibrationEffect.DEFAULT_AMPLITUDE
                )
            )
        } else {
            val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            vibrator.vibrate(VIBRATOR_DURATION)
        }
    }

    companion object {
        /** In milliseconds, how long should the vibration last */
        const val VIBRATOR_DURATION: Long = 100
    }
}