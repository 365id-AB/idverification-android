package com.id365.idverification.internal.viewmodel

import android.content.Context
import android.util.Log
import androidx.compose.runtime.MutableState
import com.id365.idverification.contracts.grpc.coordinator.CoordinatorOuterClass
import com.id365.idverification.internal.communication.AbortReason
import com.id365.idverification.internal.communication.Task
import com.id365.idverification.internal.communication.UserMessage
import com.id365.idverification.internal.core.IdScannerKoinComponent
import com.id365.idverification.internal.core.SdkContext
import com.id365.idverification.internal.integrations.iproov.FacematchState
import com.id365.idverification.internal.model.ITransactionModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.koin.core.component.inject


internal class InformationViewModel(
    val context: Context
) : IInformationViewModel, IdScannerKoinComponent() {
    private val transactionModel: ITransactionModel by inject()
    override val taskData = transactionModel.viewTaskData
    override val completedTasks = transactionModel.completedTasks
    override val estimatedTotalTasks = transactionModel.estimatedTotalTasks
    override val showInformationView: MutableState<Boolean> = transactionModel.showInfo
    override val documentSizeType = SdkContext.documentSizeType
    override var iproovState = FacematchState.UNSET

    override var confirmButtonCallback: () -> Unit
         = { showInformationView.value = !showInformationView.value }

    /** Run the transaction callback with an empty response when user quits early */
    override val cancelButtonCallback: () -> Unit = {
        SdkContext.abortJob = transactionModel.abortTransactionRequest(AbortReason.UserCancelled)
        SdkContext.eventHandler.onUserDismissed()
    }

    override val userMessage: UserMessage = taskData.value.message
}