package com.id365.idverification.internal.views

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.id365.idverification.R
import com.id365.idverification.internal.communication.Task
import com.id365.idverification.internal.communication.UserMessage
import com.id365.idverification.internal.core.LandingPageTransition
import com.id365.idverification.internal.core.SdkContext
import com.id365.idverification.internal.core.SdkContext.sdk
import com.id365.idverification.internal.ui.theme.Id365ScannerSdkTheme
import com.id365.idverification.internal.utils.getActivity
import com.id365.idverification.internal.viewmodel.INfcViewModel
import com.id365.idverification.internal.views.informationview.InformationTextView
import org.koin.core.parameter.parametersOf

/**
 * This view shows the Nfc view with an animation.
 * NfcView will only show if NFC is supported in hardware.
 * Lottie animation will play so long as adapterActive is false.
 */
@Composable
internal fun NfcView(
    activity: Activity? = LocalContext.current.getActivity(),
    lfo: LifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current,
    model: INfcViewModel? = sdk.koin.get(parameters = { parametersOf(activity!!, lfo) })
) {

    val backgroundColor: Color = MaterialTheme.colorScheme.surface

    DisposableEffect(Unit){
        onDispose {
            model?.close()
        }
    }

    if (model?.nfcSupported == true) {
        SdkContext.cameraReady.postValue(LandingPageTransition.READY)
        Column(
            modifier = Modifier.background(backgroundColor),
            verticalArrangement = Arrangement.Bottom
        ) {
            CustomProgressContainerView(
                model=model,
                modifier= Modifier
                    .fillMaxSize()
                    .weight(1f)
            )
            InformationOverlayView(
                modifier = Modifier
                    .fillMaxHeight(0.45F)
                    .weight(1f),
                model=model,
                buttonParams = getButtonParamsList(model)
            )
        }

        if (!model.nfcEnabled.value) {
            val ctx = LocalContext.current
            Box(modifier = Modifier
                .fillMaxSize()
                .padding(10.dp)) {
                Card(
                    modifier = Modifier.align(Alignment.Center)
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        InformationTextView(
                            alignment = Alignment.CenterHorizontally,
                            userMessage = UserMessage(
                                title = ctx.getString(R.string._365id_read_nfc_disabled_title),
                                subtitle = ctx.getString(R.string._365id_read_nfc_disabled_message),
                                level = UserMessage.Level.INFORMATION
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun getButtonParamsList(
    model: INfcViewModel
): List<ButtonParams> {
    val enabled by model.nfcEnabled
    val context = LocalContext.current
    return when(enabled) {
        false -> listOf(
            ButtonParams(
                text = stringResource(id = R.string._365id_button_enable_settings),
                buttonColor = MaterialTheme.colorScheme.primary,
                textColor = MaterialTheme.colorScheme.onPrimary,
                onClick = { openSettings(context) },
                testTag = "OpenSettingsButton"
            ),
            ButtonParams(
                text = stringResource(id = R.string._365id_button_skip),
                buttonColor = MaterialTheme.colorScheme.secondaryContainer,
                textColor = MaterialTheme.colorScheme.onSecondaryContainer,
                onClick = { model.buttonCb() },
                testTag = "WhiteInformationOverlayButton"
            )
        )
        else -> emptyList()
    }
}

@Composable
private fun CustomProgressContainerView(
    model: INfcViewModel,
    modifier: Modifier = Modifier,
) {
    val ctx = LocalContext.current
    Column(modifier = modifier,
        verticalArrangement = Arrangement.Center
    ) {
        Column(
            modifier = Modifier
                .padding(start = 40.dp, end = 40.dp)
                .fillMaxWidth()
        ) {
            val progressMessage by model.progressMessage
            val message = ctx.getString(R.string._365id_read_nfc_caption_scanning)
            val progressBarFill by model.progressBarFill

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp),
                contentAlignment = Alignment.BottomCenter
            ) {
                if (message == progressMessage) {
                    AnimateText(progressMessage)
                }
                else {
                    Text(
                        text = progressMessage.replace("\n", " "),
                        style = MaterialTheme.typography.titleLarge,
                        modifier = Modifier
                            .padding(bottom = 10.dp)
                            .fillMaxWidth(),
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center,
                        maxLines = 4
                    )
                }
            }

            val progressBarHeight = 20.dp
            LinearProgressIndicator(
                progress = { progressBarFill },
                modifier = Modifier
                    .height(progressBarHeight)
                    .fillMaxWidth(),
                color = MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.primaryContainer,
                strokeCap = StrokeCap.Round,
                gapSize = -progressBarHeight,
                drawStopIndicator = {}
            )
        }
    }
}

@Composable
fun AnimateText(progressMessage: String) {
    // State to control the animation
    var isGrowing by remember { mutableStateOf(true) }

    // Define the animated font size
    val animatedFontSize by animateFloatAsState(
        targetValue = if (isGrowing) 27f else 20f,  // Set target font sizes
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        )
    )

    LaunchedEffect(animatedFontSize) {
        if (animatedFontSize == 27f) {
            isGrowing = false
        } else if (animatedFontSize == 20f) {
            isGrowing = true
        }
    }

    // Apply the animated font size to the Text composable
    Text(
        text = progressMessage,
        style = MaterialTheme.typography.titleLarge.copy(fontSize = animatedFontSize.sp),
        modifier = Modifier
            .padding(bottom = 10.dp)
            .fillMaxWidth(),
        color = MaterialTheme.colorScheme.onSurface,
        textAlign = TextAlign.Center,
        maxLines = 2
    )
}

/**
 * When user presses the button, open the device settings directly to NFC
 * @param: context: The context is needed to start a new activity
 */
private fun openSettings(context: Context) {
    val intent = Intent(Settings.ACTION_NFC_SETTINGS)
    ContextCompat.startActivity(context, intent, null)
}


@Preview(
    showBackground = false,
)
@Composable
private fun  NfcViewPreview() {
    val model by remember { mutableStateOf(object : INfcViewModel {
        override val adapterActive = mutableStateOf(false)
        override val nfcSupported = true
        override val nfcEnabled = mutableStateOf(false)
        override suspend fun handleIntent(intent: Intent) {}
        override val buttonCb: () -> Unit = { buttonEnabled.value = true; playAnimation.value = false }
        override val progressMessage = mutableStateOf("Your document contains a chip.\nPlace the phone on top of the document.")
        override val progressBarFill = mutableFloatStateOf(0.25f)
        override val taskData = mutableStateOf(Task())
        override val infoText = mutableStateOf("Lets read NFC")
        override val buttonLabel = "Skip"
        override val buttonEnabled = mutableStateOf(true)
        override val playAnimation = mutableStateOf(true)
        override fun close() {}
    })}
    Id365ScannerSdkTheme(darkTheme = false) {
        Column(modifier= Modifier
            .fillMaxSize()
            .background(color = Color.White)) {
            NfcView(model = model)
            Slider(
                value = model.progressBarFill.floatValue,
                onValueChange = { model.progressBarFill.floatValue = it }
            )
        }
    }
}
