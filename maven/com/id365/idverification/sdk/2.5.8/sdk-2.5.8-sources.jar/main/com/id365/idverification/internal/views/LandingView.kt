package com.id365.idverification.internal.views

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.SpringSpec
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.id365.idverification.internal.core.LandingPageTransition
import com.id365.idverification.internal.core.SdkContext
import com.id365.idverification.internal.ui.theme.Id365ScannerSdkTheme

/**
 * This hides the SDK until "cameraReady" switches state
 *
 * @param content: The composable to draw in the background
 */
@Composable
internal fun LandingView(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit = {},
) {
    content.invoke()
    val transition by SdkContext.cameraReady.observeAsState()
    val sessionReady by SdkContext.sessionReady.observeAsState()

    Crossfade(targetState = sessionReady, label = "Crossfade LandingView 1") {
        when (it) {
            null,
            false -> Box(
                modifier = modifier
                    .background(
                        color = MaterialTheme.colorScheme.surface
                    )
            ) {}

            true -> {}
        }
    }

    Crossfade(
        targetState = transition,
        animationSpec = SpringSpec(stiffness = Spring.StiffnessVeryLow), label = "Crossfade LandingView 2"
    ) { state ->
        when (state) {
            LandingPageTransition.LOGO -> Box(
                modifier = modifier
                    .background(
                        color = MaterialTheme.colorScheme.surface
                    )
            ) {
                WaitingView(loadingViewType = LoadingViewType.Spinner)
            }
            else -> {}
        }
    }
}

@Preview
@Composable
private fun  LandingViewPreview() {
    Id365ScannerSdkTheme(darkTheme = false) {
        Box(modifier = Modifier.fillMaxSize()) {
            LandingView(modifier = Modifier.fillMaxSize())
            val state by SdkContext.cameraReady.observeAsState()
            val session by SdkContext.sessionReady.observeAsState()
            Row(modifier = Modifier.align(Alignment.BottomCenter)) {
                Button(
                    onClick = {
                        SdkContext.cameraReady.value = when (state) {
                            LandingPageTransition.START -> LandingPageTransition.LOGO
                            LandingPageTransition.LOGO -> LandingPageTransition.READY
                            LandingPageTransition.READY,
                            null -> LandingPageTransition.START
                        }
                    },
                ) {
                    Text("$state")
                }
                Button(
                    onClick = {
                        SdkContext.sessionReady.value = when (session) {
                            null -> false
                            false -> true
                            true -> null
                        }
                    },
                ) {
                    Text("Session: $session")
                }
            }
        }
    }
}