package com.id365.idverification.internal.views

import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import com.id365.idverification.internal.model.CameraConstants
import com.id365.idverification.internal.ui.theme.Id365ScannerSdkTheme
import com.id365.idverification.internal.views.microblink.ReticleView

@Composable
internal fun ViewFinderMask(
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.background,
    weight: Float = 0.5F,
    content: @Composable BoxScope.() -> Unit
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("viewFinder"),
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier=Modifier
                .fillMaxWidth()
                .fillMaxHeight()
                .weight(0.01f + weight)
                .zIndex(-1f)
                .background(color = color)
        )
        Box(
            modifier = Modifier
        ){
            content.invoke(this)
        }
        Box(
            modifier=Modifier
                .fillMaxWidth()
                .fillMaxHeight()
                .weight(if (1f - weight == 0f) 0.01f else 1f - weight)
                .zIndex(-1f)
                .background(color = color)
        )
    }
}

@Preview
@Composable
private fun  ViewFinderViewPreview() {
    Id365ScannerSdkTheme {
        Surface(modifier = Modifier.fillMaxSize(), color = Color.White) {
            ViewFinderMask(
                color = Color(0xff069944),
                weight = 0.3f
            ) {
                Box(
                    modifier = Modifier.fillMaxWidth().aspectRatio(125F/88F).align(Alignment.Center)
                ) {
                    RoundedRectangleView(
                        modifier = Modifier.fillMaxSize(),
                        padding = PaddingValues(all=10.dp),
                        color = Color(0xff069944)
                    )
                    ReticleView(borderColor = Color(0xff996633), modifier=Modifier.fillMaxSize().padding(all=10.dp))
                }
            }
        }
    }
}

