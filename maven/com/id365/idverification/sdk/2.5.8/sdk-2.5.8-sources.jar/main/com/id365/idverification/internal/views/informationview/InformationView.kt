package com.id365.idverification.internal.views.informationview

import android.annotation.SuppressLint
import android.content.Context
import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.safeContentPadding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.tooling.preview.PreviewParameter
import androidx.compose.ui.tooling.preview.PreviewParameterProvider
import androidx.compose.ui.unit.dp
import com.id365.idverification.IdVerification
import com.id365.idverification.R
import com.id365.idverification.internal.communication.Task
import com.id365.idverification.internal.communication.UserMessage
import com.id365.idverification.internal.core.SdkContext.sdk
import com.id365.idverification.internal.integrations.iproov.FacematchState
import com.id365.idverification.internal.ui.theme.Id365ScannerSdkTheme
import com.id365.idverification.internal.viewmodel.IInformationViewModel
import com.id365.idverification.internal.viewmodel.InformationViewTextFields
import com.id365.idverification.internal.views.PrepareAnimationView
import com.id365.idverification.internal.views.TransactionProgressIndicator
import org.koin.core.error.ClosedScopeException
import org.koin.core.error.NoBeanDefFoundException

@Composable
internal fun InformationView(
    viewModel: IInformationViewModel? = try {
        sdk.koin.get()
    } catch (e: ClosedScopeException) {
        null
    } catch (e: NoBeanDefFoundException) {
        null
    } catch (e: Exception) {
        null
    },
    callback: (() -> Unit)? = null
) {
    if (callback != null)
        viewModel?.confirmButtonCallback = { callback() }
    PrivateInformationView(model = viewModel)
}

@Composable
private fun PrivateInformationView(model: IInformationViewModel?) {
    model?.let { viewModel ->
        val currentTask by viewModel.taskData
        val texts = getTexts(viewModel)
        val documentSize = viewModel.documentSizeType
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.surface)
                .windowInsetsPadding(WindowInsets(left = 24.dp, right = 24.dp))
                .safeContentPadding(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Spacer(modifier = Modifier.height(100.dp))

            val completed by viewModel.completedTasks
            val estimated by viewModel.estimatedTotalTasks

            if ( documentSize != IdVerification.DocumentSizeType.ODD) {
                TransactionProgressIndicator(
                    currentStep = completed,
                    totalSteps = estimated
                )
            }

            Spacer(modifier = Modifier.weight(1F))
            PrepareAnimationView(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(3 / 2F),
                task = currentTask.nextTask
            )

            Spacer(modifier = Modifier.weight(1F))

            InformationTextView(userMessage = texts.userMessage)

            Spacer(modifier = Modifier.weight(1F))
            ContinueButton(text = texts.buttonText, onClick = { viewModel.confirmButtonCallback.invoke() })
            Spacer(modifier = Modifier.height(20.dp))
            CancelButton(text = texts.cancelText, onClick = { viewModel.cancelButtonCallback.invoke() })
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun getTexts(
    model: IInformationViewModel,
    ctx: Context = LocalContext.current
): InformationViewTextFields {
    val buttonText = when(model.taskData.value.nextTask) {
        Task.Level.ODD_SIZE_IMAGE_CAPTURE -> ctx.getString(R.string._365id_white_information_odd_buttontext)
        else -> ctx.getString(R.string._365id_white_information_frontside_buttontext)
    }
    if(model.taskData.value.nextTask == Task.Level.IPROOV) {
        when(model.iproovState) {
            FacematchState.FAILED -> return InformationViewTextFields(
                UserMessage(
                    title = ctx.getString(R.string._365id_white_information_iproov_title_failed),
                    subtitle = ctx.getString(R.string._365id_white_information_iproov_subtitle_failed),
                    level = UserMessage.Level.WARNING
                ),
                ctx.getString(R.string._365id_white_information_iproov_buttontext),
                ctx.getString(R.string._365id_white_information_cancel),
            )
            else -> return InformationViewTextFields(
                userMessage = model.taskData.value.message,
                ctx.getString(R.string._365id_white_information_iproov_buttontext),
                ctx.getString(R.string._365id_white_information_cancel)
            )
        }
    } else {
        return InformationViewTextFields(
            userMessage = model.taskData.value.message,
            buttonText,
            ctx.getString(R.string._365id_white_information_cancel)
        )
    }
}

private class WhiteInformationTaskProvider : PreviewParameterProvider<IInformationViewModel> {
    override val values = sequenceOf(
        object : IInformationViewModel {
            override val showInformationView = mutableStateOf(true)
            override val taskData = mutableStateOf(Task())
            override val completedTasks = mutableIntStateOf(1)
            override val estimatedTotalTasks = mutableIntStateOf(3)
            override var confirmButtonCallback: () -> Unit = {}
            override val cancelButtonCallback = {}
            override var iproovState: FacematchState = FacematchState.UNSET
            override val documentSizeType = IdVerification.DocumentSizeType.DOCUMENT
            override val userMessage: UserMessage = UserMessage()
        },
        object : IInformationViewModel {
            override val showInformationView = mutableStateOf(true)
            override val taskData = mutableStateOf(Task())
            override val completedTasks = mutableIntStateOf(1)
            override val estimatedTotalTasks = mutableIntStateOf(3)
            override var confirmButtonCallback: () -> Unit = {}
            override val cancelButtonCallback = {}
            override var iproovState: FacematchState = FacematchState.UNSET
            override val documentSizeType = IdVerification.DocumentSizeType.DOCUMENT
            override val userMessage: UserMessage = UserMessage()
        },
        object : IInformationViewModel {
            override val showInformationView = mutableStateOf(true)
            override val taskData = mutableStateOf(Task())
            override val completedTasks = mutableIntStateOf(1)
            override val estimatedTotalTasks = mutableIntStateOf(3)
            override var confirmButtonCallback: () -> Unit = {}
            override val cancelButtonCallback = {}
            override var iproovState: FacematchState = FacematchState.UNSET
            override val documentSizeType = IdVerification.DocumentSizeType.DOCUMENT
            override val userMessage: UserMessage = UserMessage()
        },
        object : IInformationViewModel {
            override val showInformationView = mutableStateOf(true)
            override val taskData = mutableStateOf(Task())
            override val completedTasks = mutableIntStateOf(1)
            override val estimatedTotalTasks = mutableIntStateOf(3)
            override var confirmButtonCallback: () -> Unit = {}
            override val cancelButtonCallback = {}
            override var iproovState: FacematchState = FacematchState.FAILED
            override val documentSizeType = IdVerification.DocumentSizeType.DOCUMENT
            override val userMessage: UserMessage = UserMessage()
        },
        object : IInformationViewModel {
            override val showInformationView = mutableStateOf(true)
            override val taskData: MutableState<Task> = mutableStateOf(
                Task(
                    state = "",
                    token = "",
                    message = UserMessage(
                        title = "Scan the front side",
                        subtitle = "Scan your id document again\nWe were unable to aquire the correct information from the document photo.\n You need to scan the document again.",
                        level = UserMessage.Level.INFORMATION
                    )
                )
            )
            override val completedTasks = mutableIntStateOf(0)
            override val estimatedTotalTasks = mutableIntStateOf(3)
            override var confirmButtonCallback: () -> Unit = {}
            override val cancelButtonCallback = {}
            override var iproovState: FacematchState = FacematchState.FAILED
            override val documentSizeType = IdVerification.DocumentSizeType.DOCUMENT
            override val userMessage: UserMessage = UserMessage()
        }
    )
}

@Preview
@Composable
private fun InformationViewPreviewRetry() {
    Id365ScannerSdkTheme {
        Box(modifier=Modifier
            .fillMaxSize()
        ) {
            PrivateInformationView(model=WhiteInformationTaskProvider().values.last())
        }
    }
}

@Preview
@Composable
private fun InformationViewPreview2() {
    Id365ScannerSdkTheme {
        Box(modifier=Modifier
            .fillMaxSize()
        ) {
            PrivateInformationView(model=WhiteInformationTaskProvider().values.first())
        }
    }
}

@Preview
@Composable
private fun InformationViewPreview(
    @PreviewParameter(WhiteInformationTaskProvider::class) model: IInformationViewModel
) {
    Id365ScannerSdkTheme {
        Box(modifier=Modifier
            .fillMaxSize()) {
            PrivateInformationView(model)
        }
    }
}
