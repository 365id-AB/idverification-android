package com.id365.idverification.internal.core

internal enum class LandingPageTransition {
    START,
    LOGO,
    READY
}