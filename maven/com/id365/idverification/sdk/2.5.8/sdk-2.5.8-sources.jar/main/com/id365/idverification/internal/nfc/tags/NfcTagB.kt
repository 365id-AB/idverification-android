package com.id365.idverification.internal.nfc.tags

import android.nfc.tech.NfcB

/**
 * Implements Android API "TagB" using our Interface
 *
 * @param tag: The Android Nfc object describing this tag
 */
internal class NfcTagB(private val tag: NfcB): NfcTag(tag) {

    override fun getChip(): String {
        return standard
    }

    override fun setTimeout(timeout: Int) {
        // TODO: NfcTagB doesn't have a timeout object, so we do nothing here
    }

    override fun transceive(data: ByteArray): ByteArray {
        return tag.transceive(data)
    }

    override fun getMaxTransceiveLength(): Int = tag.maxTransceiveLength

    override fun isExtendedLengthApduSupported(): ExtendedApduSupport = ExtendedApduSupport.UNKNOWN

    companion object{
        const val standard: String = "ISO 14443-3B"
        val tech: String = NfcB::class.java.name
    }
}