package com.id365.idverification.internal.viewmodel

import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.MutableLiveData
import com.id365.idverification.internal.logging.AppLog
import com.id365.idverification.internal.utils.CommonUtils.DebugTAG
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Implementation of [IAlertBoxViewModel].
 * See [IAlertBoxViewModel] for full documentation
 */
internal class AlertBoxViewModel : IAlertBoxViewModel {

    override val visible = MutableLiveData(false)
    override val buttonVisible = MutableLiveData(false)

    private var _caption = mutableStateOf("")
    private var _details = mutableStateOf("")
    private var _progress = mutableStateOf<Float?>(null)
    private var _btnLabel = mutableStateOf("")
    private var _btnCbk = mutableStateOf({})
    override val luminanceIsAcceptable = mutableStateOf(false)

    override val caption: MutableState<String>
        get() = _caption

    override val details: MutableState<String>
        get() = _details
    override val progress: MutableState<Float?>
        get() = _progress

    override val buttonEnabled = mutableStateOf(false)

    override val buttonLabel: MutableState<String>
        get() = _btnLabel
    override val buttonCallback: MutableState<() -> Unit>
        get() = _btnCbk

    override fun setButton(label: String, callback: () -> Unit) {
        _btnCbk.value = callback
        _btnLabel.value = label
        buttonEnabled.value = true
        buttonVisible.postValue(true)
    }

    override fun hideButton() {
        buttonEnabled.value = false
        buttonVisible.postValue(false)
    }

    override fun setText(caption: String?, details: String?) {
        AppLog.d(DebugTAG, "Setting alertbox to $caption, $details")
        CoroutineScope(Dispatchers.Main).launch {
            _caption.value = caption ?: "CAPTION_PLACEHOLDER"
            _details.value = details ?: "DETAILS_PLACEHOLDER"
            visible.postValue(true)
        }
    }

    override fun setProgress(progress: Float?) {
        CoroutineScope(Dispatchers.Main).launch {
            _progress.value = progress
        }
    }

    override fun hide() {
        CoroutineScope(Dispatchers.Main).launch {
            hideButton()
            _caption.value = ""
            _details.value = ""
            _progress.value = null
            visible.postValue(false)
        }
    }
}