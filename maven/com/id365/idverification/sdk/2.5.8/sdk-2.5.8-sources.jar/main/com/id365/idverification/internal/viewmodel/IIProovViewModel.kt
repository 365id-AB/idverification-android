package com.id365.idverification.internal.viewmodel

import androidx.compose.runtime.MutableState
import java.io.Closeable

internal interface IIProovViewModel: Closeable{

    fun startIProov(token: String)

    val buttonCb: () -> Unit

    val animationShouldPlay: MutableState<Boolean>

    val showLoading: MutableState<Boolean>

    val showInformation: MutableState<Boolean>
}
