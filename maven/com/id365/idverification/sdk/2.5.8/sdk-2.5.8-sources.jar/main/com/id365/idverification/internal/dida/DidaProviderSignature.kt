package com.id365.idverification.internal.dida

/**
 * Represents the DIDA provider signatures that can be contained in a DIDA response. See:
 * https://gitlab.365id.com/365id/dida/-/blob/main/_365id.Dida.Contracts/DigitalIdProviderSignature.cs
 */
internal class DidaProviderSignature (
    val ProviderName: String,
    val ProviderId: String,
)