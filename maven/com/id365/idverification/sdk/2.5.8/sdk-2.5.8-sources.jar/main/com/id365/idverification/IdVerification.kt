package com.id365.idverification

import android.content.Context
import android.content.Intent
import android.nfc.NfcAdapter
import android.util.AttributeSet
import android.view.View
import androidx.annotation.Keep
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.ComposeView
import com.id365.idverification.internal.core.SdkContext
import com.id365.idverification.internal.ui.theme.lightColorPalette
import com.id365.idverification.internal.views.InternalIdVerificationView
import com.id365.idverification.internal.views.LoadingViewType
import com.id365.idverification.internal.views.animations.DefaultAnimations
import com.id365.idverification.internal.views.animations.LoadingAnimationView
import com.id365.idverification.internal.views.animations.DefaultAnimationView

/**
 * Contains the main interface to the SDK, including start, stop and configuration of the SDK.
 */
@Keep
object IdVerification {

    /**
     * If you wish to skip certain steps in the identification process,
     * you can specify a list composed of items from this list. This sample
     * would skip the face matching step.
     * @sample samples.skipModulesSample.sample
     * */
    @Keep
    enum class SkipModule {

        /** The NFC readout process, only applicable to documents containing embedded NFC chips. */
        NFC,

        /** The face matching process. */
        FACE_MATCH;
    }

    /** Types of "powered by Logo" to be shown at the bottom of the screen. */
    @Keep
    enum class PoweredByLogo {

        /** The standard logo with the purple colors. */
        STANDARD,

        /** Logo with white color. */
        WHITE,

        /** Logo with black color. */
        BLACK,

        /** No logo to be shown. */
        NONE;

        /** Get image from resource name */
        internal fun getImage(): Int? {
            return when (this) {
                STANDARD -> R.drawable.ic_powered_by_365id
                WHITE -> R.drawable.ic_powered_by_365id_white
                BLACK -> R.drawable.ic_powered_by_365id_black
                NONE -> null
            }
        }
    }

    /**
     * If your onboarding process already knows which type of document you want to process, you
     * can specify this parameter. The parameter will affect the size of the viewfinder, as well
     * as the accompanying texts.
     * The formats listed are according to the ISO/IEC 7810 standard.
     * @sample samples.DocumentSizeTypeSample.sample
     */
    @Keep
    enum class DocumentSizeType {
        ID1,
        ID3,
        DOCUMENT,
        ODD
    }

    /**
     * This is the main entry point for the 365ID Scanner SDK for Android. This should be called
     * before embedding or navigating to the IdVerificationView.
     *
     * @param ctx: An ApplicationContext. Should not be an ActivityContext.
     * @param request: An [IdVerificationRequest]. Should contain a valid token and a location (Name or ID).
     * @param skipModules: Modules that can be skipped during the identification process.
     * @param documentSizeType: The type of document that is supposed to be scanned (ID1, ID3 or DOCUMENT). Only impacts the viewfinder size.
     * @param eventHandler: Implementation of IdVerificationEventHandler that reports to implementor when certain events happen
     *
     * @return true if the SDK was initialized successfully, otherwise false.
     */
    @Keep
    fun start(
        ctx: Context,
        request: IdVerificationRequest,
        skipModules: List<SkipModule> = emptyList(),
        documentSizeType: DocumentSizeType = DocumentSizeType.DOCUMENT,
        eventHandler: IdVerificationEventHandler,
    ): Boolean {
        return SdkContext.start(
            ctx=ctx,
            request=request,
            documentSizeType=documentSizeType,
            eventHandler=eventHandler,
            skipModules=skipModules
        )
    }

    /**
     * This is the main entry point for the 365ID Scanner SDK for Android. This should be called
     * before embedding or navigating to the IdVerificationView.
     *
     * @param ctx: An ApplicationContext. Should not be an ActivityContext.
     * @param request: An [IdVerificationRequest]. Should contain a valid token and a location (Name or ID).
     * @param skipModules: Modules that can be skipped during the identification process.
     * @param eventHandler: Implementation of IdVerificationEventHandler that reports to implementor when certain events happen
     *
     * @return true if the SDK was initialized successfully, otherwise false.
     */
    @Keep
    fun start(
        ctx: Context,
        request: IdVerificationRequest,
        skipModules: List<SkipModule> = emptyList(),
        eventHandler: IdVerificationEventHandler,
    ): Boolean {
        return start(
            ctx=ctx,
            request=request,
            documentSizeType=DocumentSizeType.DOCUMENT,
            eventHandler=eventHandler,
            skipModules=skipModules
        )
    }

    /**
     * This is the main entry point for the 365ID Scanner SDK for Android. This should be called
     * before embedding or navigating to the IdVerificationView.
     *
     * @param ctx: An ApplicationContext. Should not be an ActivityContext.
     * @param request: An [IdVerificationRequest]. Should contain a valid token and a location (Name or ID).
     * @param eventHandler: Implementation of IdVerificationEventHandler that reports to implementor when certain events happen
     *
     * @return true if the SDK was initialized successfully, otherwise false.
     */
    @Keep
    fun start(
        ctx: Context,
        request: IdVerificationRequest,
        eventHandler: IdVerificationEventHandler,
    ): Boolean {
        return start(
            ctx=ctx,
            request=request,
            documentSizeType=DocumentSizeType.DOCUMENT,
            eventHandler=eventHandler,
            skipModules=emptyList()
        )
    }

    /**
     * Stops any currently running 365ID Scanner SDK. Should be called after a transaction, regardless of status.
     */
    @Keep
    fun stop() {
        SdkContext.stop()
    }

    /**
     * Send an [Intent] to the SDK. Used to handle Nfc tag detection events, and only while the Sdk is active. Reading of biometric
     * data from NFC-enabled documents will not be possible unless you pass these events to the 365id SDK.
     *
     * @param intent: The intent to be passed in.
     *
     * @return true if SDK successfully accepted the intent. False if intent was null, SDK wasn't running, or intent wasn't of type [NfcAdapter.ACTION_TAG_DISCOVERED]
     */
    @Keep
    fun sendIntent(intent: Intent?): Boolean =
        intent?.let { SdkContext.sendIntent(intent) } ?: false

    /**
     * Get the SDK View composable as an Android View for inter-compatibility with non-compose frameworks
     *
     * @param context: The activity this view should be tied to
     * @param attrs: Attributes to be passed to the View
     * @param defStyleAttr: Custom style resource ID to be applied to the SDK view (R.attr.someStyle)
     *
     * @return a View that can be embedded in an XML tree. Will inherit theme from AppCompat theme.
     */
    @Keep
    fun getView(
        context: Context,
        attrs: AttributeSet? = null,
        defStyleAttr: Int = 0
    ): View {
        return ComposeView(context, attrs, defStyleAttr).apply {
            setContent {
                SdkContext.customTheme.colorScheme
                MaterialTheme(
                    colorScheme = SdkContext.customTheme.colorScheme
                ) {
                    InternalIdVerificationView()
                }
            }
        }
    }

    /**
     *  Configures The SDK to use a specified color scheme. Note that the 365ID IdVerification SDK
     *  supports Material Design 3.
     *  @note If using Jetpack Compose, you can wrap [IdVerificationView] directly with a
     *  compatible [MaterialTheme] of your choice instead of using this function.
     *
     *  @param theme: An [IdVerificationTheme] wih all or some parameters configured
     */
    @Keep
    fun setCustomTheme(
        theme: IdVerificationTheme = IdVerificationTheme()
    ) {
        SdkContext.customTheme = theme
    }

    /**
     * Configures the SDK to use the default 365id color scheme.
     */
    @Keep
    fun setDefaultTheme(){
        setCustomTheme(theme = IdVerificationTheme())
    }

    /**
     *  Create a theme for applying to the SDK.
     *  The default parameters explain how the colors in a [ColorScheme] map to the IdVerification SDK.
     *
     *  @param colorScheme A MaterialDesign 3 colorScheme object. Refer to https://m3.material.io for available color names, or use the alternative constructors
     *  @param poweredByLogo Option for configuring the "Powered by 365id" logo
     *  @param animations Any and all custom animations to be displayed by the SDK during various steps
     */
    @Keep
    data class IdVerificationTheme(
        val colorScheme: ColorScheme = lightColorPalette,
        val poweredByLogo: PoweredByLogo? = PoweredByLogo.STANDARD,
        val animations: Animations = Animations(),
    ) {

        @Keep
        constructor(): this(
            colorScheme = lightColorPalette,
            poweredByLogo = PoweredByLogo.STANDARD,
            animations = Animations(),
        )

        @Keep
        constructor(
            primary: Int = lightColorPalette.primary.toArgb(),
            onPrimary: Int = lightColorPalette.onPrimary.toArgb(),
            primaryContainer: Int = lightColorPalette.primaryContainer.toArgb(),
            onPrimaryContainer: Int = lightColorPalette.onPrimaryContainer.toArgb(),
            inversePrimary: Int = lightColorPalette.inversePrimary.toArgb(),
            secondary: Int = lightColorPalette.secondary.toArgb(),
            onSecondary: Int = lightColorPalette.onSecondary.toArgb(),
            secondaryContainer: Int = lightColorPalette.secondaryContainer.toArgb(),
            onSecondaryContainer: Int = lightColorPalette.onSecondaryContainer.toArgb(),
            tertiary: Int = lightColorPalette.tertiary.toArgb(),
            onTertiary: Int = lightColorPalette.onTertiary.toArgb(),
            tertiaryContainer: Int = lightColorPalette.tertiaryContainer.toArgb(),
            onTertiaryContainer: Int = lightColorPalette.onTertiaryContainer.toArgb(),
            background: Int = lightColorPalette.background.toArgb(),
            onBackground: Int = lightColorPalette.onBackground.toArgb(),
            surface: Int = lightColorPalette.surface.toArgb(),
            onSurface: Int = lightColorPalette.onSurface.toArgb(),
            surfaceVariant: Int = lightColorPalette.surfaceVariant.toArgb(),
            surfaceTint: Int = lightColorPalette.surfaceTint.toArgb(),
            onSurfaceVariant: Int = lightColorPalette.onSurfaceVariant.toArgb(),
            inverseSurface: Int = lightColorPalette.inverseSurface.toArgb(),
            inverseOnSurface: Int = lightColorPalette.inverseOnSurface.toArgb(),
            error: Int = lightColorPalette.error.toArgb(),
            onError: Int = lightColorPalette.onError.toArgb(),
            errorContainer: Int = lightColorPalette.errorContainer.toArgb(),
            onErrorContainer: Int = lightColorPalette.onErrorContainer.toArgb(),
            outline: Int = lightColorPalette.outline.toArgb(),
            outlineVariant: Int = lightColorPalette.outlineVariant.toArgb(),
            scrim: Int = lightColorPalette.scrim.toArgb(),
            surfaceDim: Int = lightColorPalette.surfaceDim.toArgb(),
            surfaceBright: Int = lightColorPalette.surfaceBright.toArgb(),
            surfaceContainer: Int = lightColorPalette.surfaceContainer.toArgb(),
            surfaceContainerHigh: Int = lightColorPalette.surfaceContainerHigh.toArgb(),
            surfaceContainerHighest: Int = lightColorPalette.surfaceContainerHighest.toArgb(),
            surfaceContainerLow: Int = lightColorPalette.surfaceContainerLow.toArgb(),
            surfaceContainerLowest: Int = lightColorPalette.surfaceContainerLowest.toArgb(),

            poweredByLogo: PoweredByLogo? = PoweredByLogo.STANDARD,
            animations: Animations = Animations(),
        ) : this(
            colorScheme = ColorScheme(
                primary = Color(primary),
                onPrimary = Color(onPrimary),
                primaryContainer = Color(primaryContainer),
                onPrimaryContainer = Color(onPrimaryContainer),
                inversePrimary = Color(inversePrimary),
                secondary = Color(secondary),
                onSecondary = Color(onSecondary),
                secondaryContainer = Color(secondaryContainer),
                onSecondaryContainer = Color(onSecondaryContainer),
                tertiary = Color(tertiary),
                onTertiary = Color(onTertiary),
                tertiaryContainer = Color(tertiaryContainer),
                onTertiaryContainer = Color(onTertiaryContainer),
                background = Color(background),
                onBackground = Color(onBackground),
                surface = Color(surface),
                onSurface = Color(onSurface),
                surfaceVariant = Color(surfaceVariant),
                surfaceTint = Color(surfaceTint),
                onSurfaceVariant = Color(onSurfaceVariant),
                inverseSurface = Color(inverseSurface),
                inverseOnSurface = Color(inverseOnSurface),
                error = Color(error),
                onError = Color(onError),
                errorContainer = Color(errorContainer),
                onErrorContainer = Color(onErrorContainer),
                outline = Color(outline),
                outlineVariant = Color(outlineVariant),
                scrim = Color(scrim),
                surfaceDim = Color(surfaceDim),
                surfaceBright = Color(surfaceBright),
                surfaceContainer = Color(surfaceContainer),
                surfaceContainerHigh = Color(surfaceContainerHigh),
                surfaceContainerHighest = Color(surfaceContainerHighest),
                surfaceContainerLow = Color(surfaceContainerLow),
                surfaceContainerLowest = Color(surfaceContainerLowest),
            ),
            poweredByLogo = poweredByLogo,
            animations = animations,
        )

        @Keep
        constructor(
            primary: Color = lightColorPalette.primary,
            onPrimary: Color = lightColorPalette.onPrimary,
            primaryContainer: Color = lightColorPalette.primaryContainer,
            onPrimaryContainer: Color = lightColorPalette.onPrimaryContainer,
            inversePrimary: Color = lightColorPalette.inversePrimary,
            secondary: Color = lightColorPalette.secondary,
            onSecondary: Color = lightColorPalette.onSecondary,
            secondaryContainer: Color = lightColorPalette.secondaryContainer,
            onSecondaryContainer: Color = lightColorPalette.onSecondaryContainer,
            tertiary: Color = lightColorPalette.tertiary,
            onTertiary: Color = lightColorPalette.onTertiary,
            tertiaryContainer: Color = lightColorPalette.tertiaryContainer,
            onTertiaryContainer: Color = lightColorPalette.onTertiaryContainer,
            background: Color = lightColorPalette.background,
            onBackground: Color = lightColorPalette.onBackground,
            surface: Color = lightColorPalette.surface,
            onSurface: Color = lightColorPalette.onSurface,
            surfaceVariant: Color = lightColorPalette.surfaceVariant,
            surfaceTint: Color = lightColorPalette.surfaceTint,
            onSurfaceVariant: Color = lightColorPalette.onSurfaceVariant,
            inverseSurface: Color = lightColorPalette.inverseSurface,
            inverseOnSurface: Color = lightColorPalette.inverseOnSurface,
            error: Color = lightColorPalette.error,
            onError: Color = lightColorPalette.onError,
            errorContainer: Color = lightColorPalette.errorContainer,
            onErrorContainer: Color = lightColorPalette.onErrorContainer,
            outline: Color = lightColorPalette.outline,
            outlineVariant: Color = lightColorPalette.outlineVariant,
            scrim: Color = lightColorPalette.scrim,
            surfaceDim: Color = lightColorPalette.surfaceDim,
            surfaceBright: Color = lightColorPalette.surfaceBright,
            surfaceContainer: Color = lightColorPalette.surfaceContainer,
            surfaceContainerHigh: Color = lightColorPalette.surfaceContainerHigh,
            surfaceContainerHighest: Color = lightColorPalette.surfaceContainerHighest,
            surfaceContainerLow: Color = lightColorPalette.surfaceContainerLow,
            surfaceContainerLowest: Color = lightColorPalette.surfaceContainerLowest,

            poweredByLogo: PoweredByLogo? = PoweredByLogo.STANDARD,
            animations: Animations = Animations(),
        ) : this(
            colorScheme = ColorScheme(
                primary = primary,
                onPrimary = onPrimary,
                primaryContainer = primaryContainer,
                onPrimaryContainer = onPrimaryContainer,
                inversePrimary = inversePrimary,
                secondary = secondary,
                onSecondary = onSecondary,
                secondaryContainer = secondaryContainer,
                onSecondaryContainer = onSecondaryContainer,
                tertiary = tertiary,
                onTertiary = onTertiary,
                tertiaryContainer = tertiaryContainer,
                onTertiaryContainer = onTertiaryContainer,
                background = background,
                onBackground = onBackground,
                surface = surface,
                onSurface = onSurface,
                surfaceVariant = surfaceVariant,
                surfaceTint = surfaceTint,
                onSurfaceVariant = onSurfaceVariant,
                inverseSurface = inverseSurface,
                inverseOnSurface = inverseOnSurface,
                error = error,
                onError = onError,
                errorContainer = errorContainer,
                onErrorContainer = onErrorContainer,
                outline = outline,
                outlineVariant = outlineVariant,
                scrim = scrim,
                surfaceDim = surfaceDim,
                surfaceBright = surfaceBright,
                surfaceContainer = surfaceContainer,
                surfaceContainerHigh = surfaceContainerHigh,
                surfaceContainerHighest = surfaceContainerHighest,
                surfaceContainerLow = surfaceContainerLow,
                surfaceContainerLowest = surfaceContainerLowest,
            ),
            poweredByLogo = poweredByLogo,
            animations = animations,
        )
    }

    /**
     *  Customize the animations that are visible inside the SDK
     *
    * @param prepareId3 Shown when preparing to take photo of ID3-shaped documents
    * @param prepareId1Frontside Shown when preparing to take photo of frontside of ID1-shaped document
    * @param prepareId1Backside Shown when preparing to take photo of backside of ID1-shaped document
    * @param prepareDocument Shown when preparing to take photo without specifying the document shape
    * @param prepareOddSizedDocument Shown when preparing to take photo of odd sized document.
    * @param prepareNfc Shown when preparing for the NFC step.
    * @param prepareId1Nfc Shown when preparing for the NFC step for ID1-shaped documents.
    * @param prepareId3Nfc Shown when preparing for the NFC step for ID3-shaped documents.
    * @param prepareDocumentNfc Shown when preparing for the NFC step for generic documents.
    * @param prepareFacematch Shwon when prparing for the face matching step
    * @param instructionId3 Shown during the 'take photo of ID3-shaped document' step
    * @param instructionId1Frontside Shown during the 'take photo of frontside of ID1-shaped document' step
    * @param instructionId1Backside Shown during the 'take photo of backside of ID1-shaped document' step
    * @param instructionDocument Shown during the 'take photo of generic document' step
    * @param instructionNfc Shown during the NFC step.
    * @param instructionId1Nfc Shown during the NFC step for ID1-documents.
    * @param instructionId3Nfc Shown during the NFC step for ID3-documents.
    * @param instructionDocumentNfc Shown during the NFC step for generic documents.
    * @param instructionOddSizedDocument For future use.
    * @param loadingImageCapture Shown after taking photo of a document
    * @param loadingNfc Shown after completing the NFC step
    * @param loadingFacematch Shown after completing the face matching step
    * @param loadingGeneric Generic loading animation shown when 365id backend is busy processing a request
     */
    @Keep
    class Animations(
        val prepareId3: @Composable () -> Unit = { DefaultAnimationView(DefaultAnimations.PASSPORT) },
        val prepareId1Frontside: @Composable () -> Unit = { DefaultAnimationView(DefaultAnimations.FRONT) },
        val prepareId1Backside: @Composable () -> Unit = { DefaultAnimationView(DefaultAnimations.BACK) },
        val prepareDocument: @Composable () -> Unit = { DefaultAnimationView(DefaultAnimations.GENERIC) },
        val prepareOddSizedDocument: @Composable () -> Unit = { DefaultAnimationView(DefaultAnimations.ODD_SIZE) },

        val prepareId1Nfc: @Composable () -> Unit = { DefaultAnimationView(DefaultAnimations.NFC_ID1) },
        val prepareId3Nfc: @Composable () -> Unit = { DefaultAnimationView(DefaultAnimations.NFC_ID3) },
        val prepareDocumentNfc: @Composable () -> Unit = { DefaultAnimationView(DefaultAnimations.NFC_ID1) },

        @Deprecated(message = "This parameter is being phased out. You can still apply your own custom animation to prepareNfc, however this will override the animations for prepareId1Nfc, prepareId3Nfc and prepareDocumentNfc", level = DeprecationLevel.WARNING)
        val prepareNfc: @Composable () -> Unit = {
            if(SdkContext.documentSizeType == DocumentSizeType.ID3) {
                prepareId3Nfc()
            }
            else if(SdkContext.documentSizeType == DocumentSizeType.ID1) {
                prepareId1Nfc()
            }
            else if (SdkContext.documentSizeType == DocumentSizeType.DOCUMENT) {
                prepareDocumentNfc()
            }
        },

        val prepareFacematch: @Composable () -> Unit = { DefaultAnimationView(DefaultAnimations.FACE) },

        val instructionId3: @Composable () -> Unit = { DefaultAnimationView(DefaultAnimations.PASSPORT) },
        val instructionId1Frontside: @Composable () -> Unit = { DefaultAnimationView(DefaultAnimations.FRONT) },
        val instructionId1Backside: @Composable () -> Unit = { DefaultAnimationView(DefaultAnimations.BACK) },
        val instructionDocument: @Composable () -> Unit = { DefaultAnimationView(DefaultAnimations.GENERIC) },
        val instructionOddSizedDocument: @Composable () -> Unit = { DefaultAnimationView(DefaultAnimations.ODD_SIZE) },

        val instructionId1Nfc: @Composable () -> Unit =  { DefaultAnimationView(DefaultAnimations.NFC_ID1) },
        val instructionId3Nfc: @Composable () -> Unit =  { DefaultAnimationView(DefaultAnimations.NFC_ID3) },
        val instructionDocumentNfc: @Composable () -> Unit = { DefaultAnimationView(DefaultAnimations.NFC_ID1) },

        @Deprecated(message = "This parameter is being phased out. You can still apply your own custom animation to instructionNfc, however this will override the animations for instructionId1Nfc, instructionId3Nfc and instructionDocumentNfc", level = DeprecationLevel.WARNING)
        val instructionNfc: @Composable () -> Unit = {
            if(SdkContext.documentSizeType == DocumentSizeType.ID3) {
                instructionId3Nfc()
            }
            else if (SdkContext.documentSizeType == DocumentSizeType.ID1) {
                instructionId1Nfc()
            }
            else if (SdkContext.documentSizeType == DocumentSizeType.DOCUMENT) {
                instructionDocumentNfc()
            }
        },
        val loadingImageCapture: @Composable () -> Unit = { LoadingAnimationView(LoadingViewType.Spinner) },
        val loadingNfc: @Composable () -> Unit = { LoadingAnimationView(LoadingViewType.Spinner) },
        val loadingFacematch: @Composable () -> Unit = { LoadingAnimationView(LoadingViewType.Spinner) },
        val loadingGeneric: @Composable () -> Unit = { LoadingAnimationView(LoadingViewType.Spinner) },
    )

    /**
     * Show the 365iD Scanner SDK.
     * Note: Should wait for [IdVerificationEventHandler.onStarted] to trigger before showing this.
     */
    @Composable
    @Keep
    fun IdVerificationView() {
        InternalIdVerificationView()
    }
}
