package com.id365.idverification.internal.integrations.iproov

class IProovTokenResponse(
    // Status of the IProov Token request
    val success: Boolean = false,

    // The iProov token, if success was true
    val iProovToken: String = ""
)