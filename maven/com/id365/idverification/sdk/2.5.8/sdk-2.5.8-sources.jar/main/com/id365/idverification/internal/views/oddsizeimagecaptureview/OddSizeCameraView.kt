package com.id365.idverification.internal.views.oddsizeimagecaptureview

import android.view.ViewGroup
import androidx.camera.view.PreviewView
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.id365.idverification.internal.viewmodel.IOddSizeImageCaptureViewModel
import kotlinx.coroutines.launch

@Composable
internal fun OddSizeCameraView(model: IOddSizeImageCaptureViewModel) {
    val coroutineScope = rememberCoroutineScope()
    AndroidView(
        modifier = Modifier,
        factory = { context ->
            val previewView = PreviewView(context).apply {
                this.scaleType = scaleType
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            }
            coroutineScope.launch {
                model.startCamera(previewView)
            }
            previewView
        }
    )
}