package com.id365.idverification.internal.communication

/**
 * Helper class to help us track incoming events and
 * ensure we don't handle the same event multiple times
 */
internal class Event<out T>(private val content: T) {

    var hasBeenHandled = false
        private set

    /**
     * If this Event have not been handled,
     */
    fun getContentIfNotHandledOrReturnNull(): T? {
        return if (hasBeenHandled) {
            null
        } else {
            hasBeenHandled = true
            content
        }
    }

    fun peekContent(): T = content
}