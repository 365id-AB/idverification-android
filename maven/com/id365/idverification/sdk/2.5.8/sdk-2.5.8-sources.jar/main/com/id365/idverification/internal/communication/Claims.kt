package com.id365.idverification.internal.communication

import android.util.Base64
import androidx.annotation.Keep
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * A session token may contain one or more claims. These may be of interest in parts of the SDK,
 * so we use this class to store the claims the SDK knows of.
 */
@Keep
@Serializable
internal data class Claims(
    val SourceId: String = "",
    val ArchiveId: String = "",
    val vendorId: String = "",
    val AllowDebugging: String = "false",
    val lang: String = "en-US",
    val CheckNfc: String = "0",
    val CheckIProov: String = "0",
    val iProovAssuranceType: String = "",
    val iProovFaceMatchingLevel: String = "",
    val iProovAntiSpoofingLevel: String = "",
    val exp: Long = 0,
    val MicroBlinkLicenseKey: String = "",
) {
    override fun toString(): String {
        return Base64.encodeToString(Json.encodeToString(this).encodeToByteArray(), Base64.DEFAULT)
    }
    @Keep
    companion object {
        /**
         * Helper json parser for checkDebugFlag to ignore unknown fields
         */
        private val json: Json by lazy {
            Json { ignoreUnknownKeys = true }
        }

        /**
         * Decodes claims from a json
         */
        internal fun fromJson(claims: String): Claims {
            val decoded = Base64.decode(claims, Base64.DEFAULT).toString(Charsets.UTF_8)
            return json.decodeFromString(decoded)
        }
    }
}
