package com.id365.idverification.internal.model

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import android.util.Log
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import com.id365.idverification.DocumentType
import com.id365.idverification.FacematchFeedback
import com.id365.idverification.IdVerificationResult
import com.id365.idverification.NfcFeedback
import com.id365.idverification.errors.*
import com.id365.idverification.internal.communication.AbortReason
import com.id365.idverification.internal.utils.CommonUtils.DebugTAG
import com.id365.idverification.internal.communication.ICommunicator
import com.id365.idverification.internal.communication.SessionToken
import com.id365.idverification.internal.communication.Task
import com.id365.idverification.internal.core.IdScannerKoinComponent
import com.id365.idverification.internal.core.SdkContext
import com.id365.idverification.internal.logging.AppLog
import com.id365.idverification.internal.viewmodel.IAlertBoxViewModel
import io.grpc.Status
import io.grpc.StatusException
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import org.koin.core.component.get
import org.koin.core.component.inject
import org.koin.core.error.InstanceCreationException
import java.io.ByteArrayOutputStream
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.properties.Delegates

/**
 * The "heart" of the SDK. Handles the entire transaction from start to finish.
 *
 * @param context: The calling application context.
 */
internal class TransactionModel(
    override val context: Context,
    val coroutineDispatcher: CoroutineDispatcher = Dispatchers.IO
) : ITransactionModel, IdScannerKoinComponent() {

    override val communicator: ICommunicator by inject()

    /**
     * Whenever we request a new task, [task] is updated. When this happens, we trigger events like
     * switching to a new view or triggering a callback when the transaction ends.
     */
    var task: Task by Delegates.observable(Task(nextTask = Task.Level.UNDEFINED.toString())) { _, oldTask, newTask ->
        AppLog.i(DebugTAG, "Received new task ${newTask.nextTask.name}")

        handleDocumentFeedback(newTask)
        handleNfcFeedback(newTask)
        handleFacematchFeedback(newTask)

        /* Set value for the transaction progress ui element */
        completedTasks.intValue = newTask.taskCountCurrent
        estimatedTotalTasks.intValue = newTask.taskCountEstimate

        when (newTask.nextTask) {
            Task.Level.WAIT,
            Task.Level.WAIT_DOCUMENT,
            Task.Level.WAIT_NFC,
            Task.Level.WAIT_IPROOV -> {
                requestNextTask()
            }
            Task.Level.FINISHED_BUT_FAILED -> {
                handleFinishedButFailed(newTask)
            }
            Task.Level.FINISHED_SUCCESSFULLY -> {
                handleFinishedSuccessfully()
            }
            Task.Level.FRONT_SIDE,
            Task.Level.BACK_SIDE,
            Task.Level.NFC,
            Task.Level.IPROOV,
            Task.Level.ODD_SIZE_IMAGE_CAPTURE -> {
                showInfo.value = true
            }
            Task.Level.NO_ACTIVE_PACKAGE -> {
                handleError(NoActivePackagesException())
            }
            Task.Level.INVALID_VERSION -> {
                handleError(UnsupportedSdkVersionException())
            }
            else -> {
                // Navigation to view is handled by IdVerificationView
            }
        }

        if (newTask.nextTask != oldTask.nextTask) {
            hideAlertBox()
        }
        viewTaskData.value = newTask
    }

    private fun hideAlertBox() {
        try {
            get<IAlertBoxViewModel>().hide()
        } catch (_: Exception) {
            // Do nothing
        }
    }

    private fun handleFinishedSuccessfully() {
        if (semaphore.tryAcquire()) {
            try {
                SdkContext.transactionFinished = true
                SdkContext.eventHandler.onCompleted(IdVerificationResult(get<SessionToken>().transactionId))
            } catch (e: Exception) {
                AppLog.e(DebugTAG, "Failed to handle transaction completion: $e")
                SdkContext.onException(
                    IdVerificationUserException(
                        message = "Failed to handle transaction completion",
                        exception = e
                    )
                )
            } finally {
                semaphore.release()
            }
        }
    }

    private fun handleFinishedButFailed(newTask: Task) {
        SdkContext.transactionFinished = true
        SdkContext.eventHandler.onCompleted(
            IdVerificationResult(
                get<SessionToken>().transactionId,
                error = IdVerificationServerException(message = newTask.message.subtitle),
            )
        )
    }

    private fun handleFacematchFeedback(newTask: Task) {
        if (newTask.feedback.facematchFeedback.facematchStatus != FacematchFeedback.Undefined) {
            try {
                SdkContext.eventHandler.onFaceMatchFeedback(
                    newTask.feedback.facematchFeedback.facematchStatus
                )

                SdkContext.eventHandler.onFaceMatchFeedbackWithSource(
                    newTask.feedback.facematchFeedback.facematchStatus,
                    faceMatchSource = newTask.feedback.facematchFeedback.facematchSource
                )
            } catch (e: Exception) {
                AppLog.e(DebugTAG, "Failed to handle facematch feedback: $e")
                SdkContext.onException(
                    IdVerificationUserException(
                        message = "Failed to handle facematch feedback",
                        exception = e
                    )
                )
            }
        }
    }

    private fun handleNfcFeedback(newTask: Task) {
        if (newTask.feedback.nfcFeedback.nfcFeedback != NfcFeedback.Undefined) {
            try {
                SdkContext.eventHandler.onNfcFeedback(
                    nfcFeedback = newTask.feedback.nfcFeedback.nfcFeedback,
                    expiryDate = newTask.feedback.nfcFeedback.expiryDate
                )

                SdkContext.eventHandler.onNfcFeedbackWithDataTypes(
                    nfcFeedback = newTask.feedback.nfcFeedback.nfcFeedback,
                    expiryDate = newTask.feedback.nfcFeedback.expiryDate,
                    dataTypes = newTask.feedback.nfcFeedback.dataTypes
                )
            } catch (e: Exception) {
                AppLog.e(DebugTAG, "Failed to handle NFC feedback: $e")
                SdkContext.onException(
                    IdVerificationUserException(
                        message = "Failed to handle NFC feedback",
                        exception = e
                    )
                )
            }
        }
    }

    private fun handleDocumentFeedback(newTask: Task) {
        if (newTask.feedback.documentFeedback.documentType != DocumentType.Undefined) {
            try {
                SdkContext.eventHandler.onDocumentFeedback(
                    documentType = newTask.feedback.documentFeedback.documentType,
                    countryCode = newTask.feedback.documentFeedback.country
                )
                SdkContext.setDocumentSizeType(newTask.feedback.documentFeedback.documentType)
            } catch (e: Exception) {
                AppLog.e(DebugTAG, "Failed to handle document feedback: $e")
                SdkContext.onException(
                    IdVerificationUserException(
                        message = "Failed to handle document feedback",
                        exception = e
                    )
                )
            }
        }
    }

    private val authenticationJob = communicator.authenticate().also { job ->
        job.invokeOnCompletion {throwable ->
            if (throwable == null) {

                val transactionId = try {
                    get<SessionToken>().transactionId
                } catch (e: Exception) {
                    ""
                }
                try {
                    SdkContext.eventHandler.onTransactionCreated(transactionId)
                    AppLog.i(DebugTAG, "Transaction created: $transactionId")
                } catch (e: Exception) {
                    AppLog.e(DebugTAG, "Failed to handle transaction creation: $e")
                    SdkContext.onException(
                        IdVerificationUserException(
                            message = "Failed to handle transaction creation",
                            exception = e
                        )
                    )
                }
            }
        }
    }

    override val communicatorReady: Boolean
        get() = authenticationJob.isCompleted

    /** Accessed by the ViewModel to observe the state of [task] */
    override val viewTaskData = mutableStateOf(task)
    override var showInfo = mutableStateOf(false)

    override val completedTasks = mutableIntStateOf(0)
    override val estimatedTotalTasks = mutableIntStateOf(1)

    /**
     * Accessed by WaitViewModel, FrontViewModel and BackViewModel to show previews when
     * waiting for interactions with the backend
     */
    override val frontPreview: MutableState<Bitmap?> = mutableStateOf(null)
    override val backPreview: MutableState<Bitmap?> = mutableStateOf(null)

    var frontPicture: Bitmap? = null
    var debugPicture: Bitmap? = null
    var debugRoi: Rect? = null
    var manualTrigger: Boolean = false

    /** Class that contains a job if it finished successfully */
    class JobHolder(val job: Job, var finishedSuccessfully: Boolean = false)

    /** Contains all jobs if they finished successfully */
    private val jobHolders = mutableListOf<JobHolder>()

    /** Find a specific jobHolder from JobHolder array */
    private fun MutableList<JobHolder>.findJobHolder(fromJob: Job): JobHolder? =
        this.firstOrNull { it.job == fromJob }

    override fun stop(e: Exception?) {
        CoroutineScope(Dispatchers.Main).launch(start = CoroutineStart.LAZY) {
            jobHolders.map(JobHolder::job).joinAll()
        }
        e?.let {
            handleError(IdVerificationClientException(exception = it))
        }
    }

    /**
     * Cache a picture and preview inside this transaction
     */
    override fun takePicture(
        bitmap: Bitmap,
        debug: Bitmap?,
        debugRoi: Rect?,
        preview: Bitmap?,
        manual: Boolean,
        skipAnalysis: Boolean
    ): Boolean {

        if (task.nextTask == Task.Level.FRONT_SIDE)
            this.frontPreview.value = preview
        else if (task.nextTask == Task.Level.BACK_SIDE)
            this.backPreview.value = preview

        if (task.nextTask == Task.Level.FRONT_SIDE ||
            task.nextTask == Task.Level.BACK_SIDE ||
            task.nextTask == Task.Level.ODD_SIZE_IMAGE_CAPTURE
        ) {
            sendFrontSide(bitmap, debug, debugRoi, manual, skipAnalysis)
        } else {
            frontPicture = bitmap
            debugPicture = debug
            this.debugRoi = debugRoi
            this.manualTrigger = manual
        }
        return true
    }

    /**
     * Helper function so we can upload FRONT_SIDE image in both use cases:
     * a) When user takes a picture BEFORE the coordinator asks us to do so,
     * b) When user takes a picture AFTER the coordinator has instructed us to do so
     *
     * @param image: The image to be uploaded.
     * @param debug: The full image to (maybe) be uploaded
     * @param debugRoi: The ROI from which [image] is derived from [debug]
     * @param manual: The image to be uploaded.
     */
    private fun sendFrontSide(
        image: Bitmap,
        debug: Bitmap?,
        debugRoi: Rect? = null,
        manual: Boolean,
        skipAnalysis: Boolean
    ) {
        val stream = ByteArrayOutputStream()
        image.compress(Bitmap.CompressFormat.JPEG, 80, stream)
        val debugStream = ByteArrayOutputStream()
        try {
            if (get<SessionToken>().allowDebugging) {
                debug?.compress(Bitmap.CompressFormat.JPEG, 80, debugStream)
                uploadPicture(stream.toByteArray(), debugStream.toByteArray(), debugRoi, manual, skipAnalysis)
            } else {
                uploadPicture(stream.toByteArray(), manual = manual, skipAnalysis = skipAnalysis)
            }
        } catch (ice: InstanceCreationException) {
            Log.e(DebugTAG, "Tried to send frontside before we have a session token ready: $ice")
        } catch (e: Exception) {
            AppLog.e(DebugTAG, "Unhandled exception when sending image: $e")
        }
        get<IAlertBoxViewModel>().hide()
    }

    /**
     *  Requests the next task.
     */
    override fun requestNextTask(): Job = commsWrapper {
        authenticationJob.join()

        try {
            val nextTask = communicator.nextTaskRequest(state = task.state)
            SdkContext.sdk.let {
                task = nextTask
            }
        } catch (e: StatusException) {
            when (e.status.code.toStatus()) {
                Status.UNAVAILABLE -> {
                    AppLog.d(DebugTAG, "Probably, user pressed the cancel button")
                }
                else -> {
                    throw e // Re-throw for other handlers
                }
            }
        } catch (e: Exception) {
            AppLog.e(DebugTAG, "Error occurred while requesting next task: $e", e)
            handleError(
                IdVerificationServerException(
                    message = "Error communicating with 365id cloud services",
                    exception = e
                )
            )
        }
    }

    /**
     *  Calling abortTransactionRequest to let the backend know it's aborted and  why it's canceled
     */
    override fun abortTransactionRequest(reason: AbortReason): Job = commsWrapper {
        authenticationJob.join()
        communicator.abortTransactionRequest(reason)
    }

    override fun commsWrapper(networkCall: suspend () -> Unit): Job {
        val job = CoroutineScope(coroutineDispatcher).launch {
            try {
                networkCall.invoke()
                try {
                    jobHolders.findJobHolder(this.coroutineContext.job)?.finishedSuccessfully = true
                } catch (e: ConcurrentModificationException) {
                    AppLog.e(DebugTAG, "Attempted to modify job item from different threads: $e", e)
                }
            } catch (e: StatusException) {
                when (e.status) {
                    Status.UNAUTHENTICATED -> {
                        handleError(
                            IdVerificationInvalidTokenException(
                                message = "Token expired during transaction. Transaction is considered invalid.",
                                exception = e
                            )
                        )
                    }
                    else -> {
                        handleError(
                            IdVerificationServerException(
                                message = "Error communicating with 365id cloud services",
                                exception = e
                            )
                        )
                    }
                }
            } catch (e: Exception) {
                AppLog.e(DebugTAG, "Unhandled exception during communication: $e", e)
                handleError(
                    IdVerificationServerException(
                        message = "Error communicating with 365id cloud services",
                        exception = e
                    )
                )
            }
        }
        jobHolders.add(JobHolder(job))
        return job
    }

    override fun handleError(exc: IdVerificationException) {
        SdkContext.onException(exc)
    }

    /**
     * Prevents more than one callback to the calling application from being executed.
     */
    private val semaphore: Semaphore = Semaphore(1)

    private var uploadInProgress = AtomicBoolean(false)
    /**
     * For uploading images during the FRONT_SIDE portion of a transaction
     * @param: array: The JPEG-encoded image to be uploaded.
     */
    private fun uploadPicture(
        array: ByteArray,
        debug: ByteArray? = null,
        debugRoi: Rect? = null,
        manual: Boolean = false,
        skipAnalysis: Boolean
    ) {

        // Atomic check-and-set
        if (!uploadInProgress.compareAndSet(false, true)) {
            AppLog.d(DebugTAG, "Upload already in progress, ignoring duplicate call.")
            return
        }

        val job = commsWrapper {
            AppLog.d(DebugTAG, "Sending image for identification")
            communicator.sendImageForIdentification(array, debug, debugRoi, manual, skipAnalysis)
        }

        job.invokeOnCompletion { throwable ->
            // release guard.
            uploadInProgress.set(false)

            if (throwable != null) {
                AppLog.e(DebugTAG, "Error occurred while uploading image: $throwable", throwable)
                return@invokeOnCompletion
            }

            val jobHolder = jobHolders.findJobHolder(job) ?: return@invokeOnCompletion
            if (!jobHolder.finishedSuccessfully) {
                // StatusException has been thrown - So we ignore nextTask.
                return@invokeOnCompletion
            }
            requestNextTask()
        }
    }

    init {
        authenticationJob.invokeOnCompletion {
            if (it == null) {
                requestNextTask()
            }
        }
    }
}