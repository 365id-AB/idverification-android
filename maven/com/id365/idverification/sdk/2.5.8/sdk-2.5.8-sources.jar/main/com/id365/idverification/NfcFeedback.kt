package com.id365.idverification

import androidx.annotation.Keep

/**
 * Enumeration of Nfc feedback
 */
@Keep
enum class NfcFeedback {
    Undefined,
    /** User skipped nfc */
    Aborted,
    /** Reading of nfc chip was completed */
    Completed,
    /** Reading of nfc chip failed */
    Failed
}

/**
 * Represents the possible data types extracted from a NFC chip
 * This is a set of flags used with a bitfield to determine what data types was read from the NFC
 * chip.
 */
class NfcDataTypeFlags(val rawValue: Int) {

    companion object {

        const val MRZ = 1 shl 0
        const val PORTRAIT = 1 shl 1
        const val SIGNATURE = 1 shl 2
        const val NONE = 0
    }
}


