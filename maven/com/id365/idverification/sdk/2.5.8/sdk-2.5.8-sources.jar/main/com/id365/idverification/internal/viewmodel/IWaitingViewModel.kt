package com.id365.idverification.internal.viewmodel

import java.io.Closeable

internal interface IWaitingViewModel: Closeable {
    /**
     * If the user decides to dismiss the wait view early, this callback should be triggered.
     */
    val cancelButtonCallback: () -> Unit
}