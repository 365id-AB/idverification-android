package com.id365.idverification.internal.views.oddsizeimagecaptureview

import androidx.compose.foundation.layout.size
import androidx.compose.material3.IconButton
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.id365.idverification.R

@Composable
internal fun AcceptButton(
    modifier: Modifier = Modifier,
    iconId: Int = R.drawable.checkmark,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    IconButton(
        onClick = onClick,
        modifier = modifier,
        enabled = enabled
    ) {
        Icon(
            painter = painterResource(id = iconId),
            contentDescription = "Accept button",
            modifier = Modifier
                .size(44.dp),
            tint = if (enabled) {
                Color.Green
            } else {
                Color.DarkGray
            }
        )
    }
}