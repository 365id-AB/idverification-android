import kotlinx.serialization.Serializable

@Serializable
data class NfcTaskPayload(
    val retryAttempt: Int
)


