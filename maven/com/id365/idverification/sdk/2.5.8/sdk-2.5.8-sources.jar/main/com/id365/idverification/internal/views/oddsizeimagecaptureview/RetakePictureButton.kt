package com.id365.idverification.internal.views.oddsizeimagecaptureview

import androidx.compose.foundation.layout.size
import androidx.compose.material3.IconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.id365.idverification.R

@Composable
internal fun RetakePictureButton(
    modifier: Modifier = Modifier,
    iconId: Int = R.drawable.retake_picture,
    toggleCaptureButton: () -> Unit,
) {
    IconButton(
        onClick = toggleCaptureButton,
        modifier = modifier
    ) {
        Icon(
            painter = painterResource(id = iconId),
            contentDescription = "Retake button",
            modifier = Modifier.size(44.dp),
            tint = MaterialTheme.colorScheme.inverseOnSurface
        )
    }
}