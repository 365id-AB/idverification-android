package com.id365.idverification.internal.viewmodel

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.util.Log
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.core.UseCaseGroup
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.id365.idverification.IdVerification
import com.id365.idverification.R
import com.id365.idverification.contracts.grpc.coordinator.CoordinatorOuterClass
import com.id365.idverification.internal.communication.AbortReason
import com.id365.idverification.internal.communication.Task
import com.id365.idverification.internal.core.IdScannerKoinComponent
import com.id365.idverification.internal.core.LandingPageTransition
import com.id365.idverification.internal.core.SdkContext
import com.id365.idverification.internal.integrations.microblink.MicroBlinkCameraResolution
import com.id365.idverification.internal.integrations.microblink.MicroBlinkCaptureStreamAnalyzer
import com.id365.idverification.internal.integrations.microblink.MicroBlinkHandler
import com.id365.idverification.internal.logging.AppLog
import com.id365.idverification.internal.model.CameraUtils
import com.id365.idverification.internal.model.ITransactionModel
import com.id365.idverification.internal.utils.CommonUtils.DebugTAG
import com.microblink.capture.analysis.CaptureState
import com.microblink.capture.analysis.FrameAnalysisResult
import com.microblink.capture.analysis.FrameAnalysisStatus
import com.microblink.capture.directapi.AnalyzerRunner
import com.microblink.capture.result.AnalyzerResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.koin.core.component.inject
import java.util.Timer
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.concurrent.timer


internal class MicroBlinkViewModel(
    val context: Context,
    val lifeCycleOwner: LifecycleOwner
) : IMicroBlinkViewModel, IdScannerKoinComponent() {

    private val transactionModel: ITransactionModel by inject()
    private var microBlinkHandler: MicroBlinkHandler? = null
    private var cameraExecutor: ExecutorService? = null
    private var cameraProvider: ProcessCameraProvider? = null

    override val taskData = transactionModel.viewTaskData
    override val didCaptureImage = mutableStateOf(false)
    override val warningStatusMessage: MutableState<String?> = mutableStateOf(null)
    override val warningStatus = mutableStateOf(true)
    override val buttonLabel: String = context.getString(R.string._365id_white_information_cancel)
    override val infoText: MutableState<String> = when(taskData.value.nextTask) {
        Task.Level.FRONT_SIDE -> mutableStateOf(context.getString(R.string._365id_white_information_frontside_title))
        Task.Level.BACK_SIDE -> mutableStateOf(context.getString(R.string._365id_white_information_backside_title))
        else -> mutableStateOf("???")
    }
    override val buttonEnabled = mutableStateOf(true)
    override val playAnimation = mutableStateOf(true)

    private var previousFrame : FrameAnalysisStatus? = null

    init {
        microBlinkHandler = MicroBlinkHandler(context)
        cameraExecutor = Executors.newSingleThreadExecutor()
    }

    private val microBlinkCaptureStreamAnalyzer = MicroBlinkCaptureStreamAnalyzer(
        onFrameAnalysisDone = ::handleFrameAnalysisResult,
        onFrameAnalysisError = { _ ->
        }
    )

    override val buttonCb: () -> Unit = {
        SdkContext.abortJob = transactionModel.abortTransactionRequest(AbortReason.UserCancelled)
        SdkContext.eventHandler.onUserDismissed()
        stopCamera()
    }

    override fun getDocumentSizeType(): IdVerification.DocumentSizeType {
        return SdkContext.documentSizeType
    }
    private fun handleFrameAnalysisResult(frameAnalysisResult: FrameAnalysisResult) {
        if (frameAnalysisResult.captureState == CaptureState.DocumentCaptured) {
            if (didCaptureImage.value){
                Log.w("MicroBlinkViewModel", "Prevented a duplicate image from being uploaded")
                return
            }
            Log.d("MicroBlinkViewModel", "Processing result from MicroBlink")
            didCaptureImage.value = true
            microBlinkCaptureStreamAnalyzer.pauseAnalysis()
            val capturedDocument: AnalyzerResult = AnalyzerRunner.detachResult()
            microBlinkHandler?.handleAnalyzerResult(capturedDocument)
            stopMicroBlinkSdk()
            return
        }
        handleFrameAnalysisStatus(frameAnalysisResult.frameAnalysisStatus)
    }

    @ExperimentalCamera2Interop
    override fun startMicroBlinkSdk(previewView: PreviewView) {
        if (cameraExecutor == null) return
        AnalyzerRunner.reset()
        val analyserSettings = microBlinkHandler?.getAnalyserSettings()
        if (analyserSettings != null) {
            AnalyzerRunner.settings = analyserSettings
        }
        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()
            previewView.post {
                // Using cameraPreviewView.post to run this code after the cameraPreview view has
                // been successfully initialized in order to get the viewPort (otherwise
                // viewPort is null) and correct camera preview dimensions.
                // One known device on which this happens is Asus Zenfone 9.
                try {
                    val useCaseGroup = UseCaseGroup.Builder().apply {
                        previewView.viewPort?.let {
                            setViewPort(it)
                        } ?: {
                            AppLog.e(DebugTAG, "MicroBlink - ViewPort is not available!")
                        }
                        val isPreviewInPortrait = previewView.height >= previewView.width

                        // add preview use case
                        addUseCase(
                            Preview.Builder().apply {
                                // use resolution with the same aspect ratio as for the image analysis
                                // to ensure that crop rect is appropriate

                                val camera2Interop = Camera2Interop.Extender(this)
                                val characteristics = CameraUtils.getCameraCharacteristics(context)
                                if (characteristics.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)
                                        ?.contains(CameraCharacteristics.CONTROL_VIDEO_STABILIZATION_MODE_ON) == true
                                ) {
                                    camera2Interop.setCaptureRequestOption(
                                        CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE,
                                        CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON
                                    )
                                }

                                if (characteristics.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)
                                        ?.contains(CameraCharacteristics.LENS_OPTICAL_STABILIZATION_MODE_ON) == true
                                ) {
                                    camera2Interop.setCaptureRequestOption(
                                        CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
                                        CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON
                                    )
                                }

                                setTargetResolution(
                                    MicroBlinkCameraResolution.RESOLUTION_1080P.toTargetResolution(
                                        isPreviewInPortrait
                                    )
                                )
                            }.build().apply {
                                setSurfaceProvider(previewView.surfaceProvider)
                            }
                        )
                        // add image analysis use case
                        addUseCase(
                            ImageAnalysis.Builder().apply {
                                setTargetResolution(
                                    MicroBlinkCameraResolution.RESOLUTION_2160P.toTargetResolution(
                                        isPreviewInPortrait
                                    )
                                )
                            }.build().apply {
                                setAnalyzer(
                                    cameraExecutor!!,
                                    microBlinkCaptureStreamAnalyzer
                                )
                            }
                        )
                    }.build()

                    // unbind all previous use cases
                    cameraProvider.unbindAll()

                    cameraProvider.bindToLifecycle(
                        lifeCycleOwner,
                        CameraSelector.Builder().requireLensFacing(CameraSelector.LENS_FACING_BACK).build(),
                        useCaseGroup
                    )

                    // Replace LandingView with MicroBlinkView
                    SdkContext.cameraReady.postValue(LandingPageTransition.READY)
                    this.cameraProvider = cameraProvider
                    Log.d(DebugTAG, "MicroBlinkViewModel - Camera ready")

                } catch (exc: Exception) {
                    AppLog.e(DebugTAG, "MicroBlink - Camera use case binding failed", exc)
                }
            }
        }, ContextCompat.getMainExecutor(context))
    }

    private fun handleFrameAnalysisStatus(status: FrameAnalysisStatus) {
        if (status.isEqualTo(previousFrame)) {
            return
        }
        previousFrame = status

        if (hysteresis.isRunning()) {
            return
        }

        hysteresis = timer()

        // framingStatus
        when (status.framingStatus) {
            FrameAnalysisStatus.DocumentFramingStatus.NotAvailable -> {}
            FrameAnalysisStatus.DocumentFramingStatus.NoDocument -> {}
            FrameAnalysisStatus.DocumentFramingStatus.CameraTooFar -> {
                warningStatusMessage.value = context.getString(R.string._365id_mbic_move_closer)
                warningStatus.value = true
                return
            }
            FrameAnalysisStatus.DocumentFramingStatus.CameraTooClose -> {
                warningStatusMessage.value = context.getString(R.string._365id_mbic_move_farther)
                warningStatus.value = true
                return
            }
            FrameAnalysisStatus.DocumentFramingStatus.CameraAngleTooSteep -> {
                warningStatusMessage.value = context.getString(R.string._365id_mbic_camera_angle_too_steep)
                warningStatus.value = true
                return
            }
            FrameAnalysisStatus.DocumentFramingStatus.CameraOrientationUnsuitable -> {}
            FrameAnalysisStatus.DocumentFramingStatus.DocumentTooCloseToFrameEdge -> {
                warningStatusMessage.value = context.getString(R.string._365id_mbic_document_too_close_to_edge)
                warningStatus.value = true
                return
            }
            FrameAnalysisStatus.DocumentFramingStatus.Ok -> {}
        }

        // lightingStatus
        when (status.lightingStatus) {
            FrameAnalysisStatus.DocumentLightingStatus.NotAvailable -> {}
            FrameAnalysisStatus.DocumentLightingStatus.TooBright -> {
                warningStatusMessage.value = context.getString(R.string._365id_mbic_lightning_too_bright)
                warningStatus.value = true
                return
            }
            FrameAnalysisStatus.DocumentLightingStatus.TooDark -> {
                warningStatusMessage.value = context.getString(R.string._365id_mbic_lightning_too_dark)
                warningStatus.value = true
                return
            }
            FrameAnalysisStatus.DocumentLightingStatus.Normal -> {}
        }

        // blurStatus
        when (status.blurStatus) {
            FrameAnalysisStatus.DocumentBlurStatus.NotAvailable -> {}
            FrameAnalysisStatus.DocumentBlurStatus.BlurDetected -> {
                warningStatusMessage.value = context.getString(R.string._365id_mbic_blur_detected)
                warningStatus.value = true
                return
            }
            FrameAnalysisStatus.DocumentBlurStatus.BlurNotDetected -> {}
        }

        // glareStatus
        when (status.glareStatus) {
            FrameAnalysisStatus.DocumentGlareStatus.NotAvailable -> {}
            FrameAnalysisStatus.DocumentGlareStatus.GlareDetected -> {
                warningStatusMessage.value = context.getString(R.string._365id_mbic_glare_detected)
                warningStatus.value = true
                return
            }
            FrameAnalysisStatus.DocumentGlareStatus.GlareNotDetected -> {}
        }

        // occlusionStatus
        when (status.occlusionStatus) {
            FrameAnalysisStatus.DocumentOcclusionStatus.NotAvailable -> {}
            FrameAnalysisStatus.DocumentOcclusionStatus.Occluded -> {
                warningStatusMessage.value = context.getString(R.string._365id_mbic_occluded)
                warningStatus.value = true
                return
            }
            FrameAnalysisStatus.DocumentOcclusionStatus.NotOccluded -> {}
        }

        warningStatus.value = false
    }

    override fun close() {
        stopMicroBlinkSdk()
    }

    /**
     * To keep track of a timer, we need to specify when it's being started and stopped
     */
    private fun timer(): Timer {
        _isRunning = true
        return timer(
            initialDelay = 2000L,
            period = 2000L
        ) {
            cancel()
            _isRunning = false
        }
    }

    /**
     * The variable telling us if the hysteresis is active or not
     */
    private var _isRunning = false

    /**
     * Helper function
     */
    private fun Timer.isRunning(): Boolean = _isRunning

    /**
     * Tracks the current hysteresis state
     */
    private var hysteresis = timer()

    private fun FrameAnalysisStatus.isEqualTo(other: Any?): Boolean {
        if (other !is FrameAnalysisStatus) {
            return false
        }
        return sideAnalysisStatus == other.sideAnalysisStatus &&
                blurStatus == other.blurStatus &&
                occlusionStatus == other.occlusionStatus &&
                glareStatus == other.glareStatus &&
                lightingStatus == other.lightingStatus &&
                framingStatus == other.framingStatus
    }

    private fun stopCamera() {
        CoroutineScope(Dispatchers.Main).launch {
            cameraProvider?.unbindAll()
            cameraExecutor?.shutdown()
            cameraProvider = null
            cameraExecutor = null
            microBlinkHandler = null
        }
        Log.d(DebugTAG, "MicroBlinkViewModel - Camera closed")
    }

    private fun stopMicroBlinkSdk() {
        AnalyzerRunner.terminate()
        stopCamera()
    }

}