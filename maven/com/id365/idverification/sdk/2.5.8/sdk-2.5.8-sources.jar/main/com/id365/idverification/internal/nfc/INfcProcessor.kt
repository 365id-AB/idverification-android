package com.id365.idverification.internal.nfc

import android.content.Intent

/**
 * Interface describing an NfcProcessor class to viewmodels.
 */
interface INfcProcessor {
    /**
     * Callback provides status updates to a UI layer during NFC communcations
     */
    val callback: ((message: String, progressPercent: Double) -> Unit)

    var lifecycleCallback: (() -> Unit)?

    /**
     * Main entry point. When an Android Intent is generated for detecting NFC,
     * this processor will intercept and process the intent.
     */
    suspend fun resolveIntent(intent: Intent)

    /**
     * Called if user skips the NFC step
     */
    fun onUserSkipNfc()

    /**
     * Used when closing the NfcProcessor (typically when stopping the SDK)
     */
    fun close()
}