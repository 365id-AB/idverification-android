package com.id365.idverification.internal.logging

import android.content.Context
import android.os.Build
import io.opentelemetry.api.common.AttributeKey
import io.opentelemetry.exporter.otlp.http.logs.OtlpHttpLogRecordExporter
import java.util.Locale
import android.util.Log
import com.id365.idverification.BuildConfig
import com.id365.idverification.OtelConfig
import com.id365.idverification.internal.utils.VendorId
import io.opentelemetry.api.logs.Severity
import io.opentelemetry.sdk.logs.SdkLoggerProvider
import io.opentelemetry.sdk.logs.export.SimpleLogRecordProcessor
import java.time.Instant

/**
 * Logger using OpenTelemetry to export logs from the SDK.
 * Logs are sent via OTLP over HTTP to the configured endpoint.
 */
internal class OtelLogger(private val ctx: Context) : IOtelLogger {

    private val loggerProvider = SdkLoggerProvider.builder()
        .addLogRecordProcessor(SimpleLogRecordProcessor.create(
            OtlpHttpLogRecordExporter.builder()
                .setEndpoint(OtelConfig.OTEL_ENDPOINT)
                .addHeader("Authorization", "Api-Key " + OtelConfig.OTEL_API_KEY)
                .build()
        )).build()

    private val otelLogger = loggerProvider.get("OTelKotlinLog")

    /**
     * Logs a message using OpenTelemetry.
     *
     * @param tag A short tag identifying the log source.
     * @param message The log message body.
     * @param transactionId Id of the transaction that this log belongs to. Can be null.
     * @param severity Android log severity level (e.g., Log.DEBUG). Will be mapped to the corresponding OpenTelemetry severity.
     */
    override fun log(tag: String, message: String, transactionId: String?, severity: Int) {

        val severityMap = mapOf(
            Log.DEBUG to Severity.DEBUG,
            Log.INFO to Severity.INFO,
            Log.WARN to Severity.WARN,
            Log.ERROR to Severity.ERROR,
            Log.VERBOSE to Severity.TRACE
        )

        val minSeverity = Log.INFO
        if (severity < minSeverity) return

        severityMap[severity]?.let { sev ->
            otelLogger.logRecordBuilder().apply {
                setTimestamp(Instant.now())
                setSeverity(sev)
                setBody(message)
                setAttribute(AttributeKey.stringKey("Application"), "IdVerification365id")
                setAttribute(AttributeKey.stringKey("Tag"), tag)
                setAttribute(AttributeKey.stringKey("Platform"), "Android")
                setAttribute(AttributeKey.stringKey("Device"), "GlootieSDK")
                setAttribute(AttributeKey.stringKey("SdkVersion"), BuildConfig.AAR_VERSION)
                setAttribute(AttributeKey.stringKey("OSVersion"), Build.VERSION.RELEASE ?: "Unknown")
                setAttribute(AttributeKey.stringKey("DeviceModel"),Build.MODEL ?: "Unknown")
                setAttribute(AttributeKey.stringKey("Language"), Locale.getDefault().language)
                setAttribute(AttributeKey.stringKey("CountryCode"), Locale.getDefault().country)
                if (transactionId != null) {
                    setAttribute(AttributeKey.stringKey("TransactionId"), transactionId)
                }
                setAttribute(AttributeKey.stringKey("VendorId"), VendorId.getVendorId(context = ctx))

                emit()
            }
        }
    }
}