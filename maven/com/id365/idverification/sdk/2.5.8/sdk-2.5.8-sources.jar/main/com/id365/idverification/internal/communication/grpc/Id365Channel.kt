package com.id365.idverification.internal.communication.grpc

import android.util.Log
import com.id365.idverification.errors.IdVerificationServerException
import com.id365.idverification.internal.logging.AppLog
import com.id365.idverification.internal.utils.CommonUtils.DebugTAG
import io.grpc.ManagedChannel
import io.grpc.ManagedChannelBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.asExecutor
import java.net.URL
import java.util.concurrent.TimeUnit

internal object Id365Channel {

    fun channel(url: URL): ManagedChannel {
        try {
            val port = if (url.port == -1) GRPC_DEFAULT_PORT else url.port

            return ManagedChannelBuilder.forAddress(url.host, port)
                .enableRetry()
                .maxRetryAttempts(GRPC_DEFAULT_MAX_TRIES_PER_CALL)
                .keepAliveTime(9, TimeUnit.SECONDS)
                .keepAliveTimeout(5, TimeUnit.SECONDS)
                .idleTimeout(1, TimeUnit.MINUTES)
                .executor(Dispatchers.Default.asExecutor())
                .useTransportSecurity()
                .build()
        } catch (e: Exception) {
            AppLog.e(DebugTAG, "Failed to create channel: $e")
            throw IdVerificationServerException(exception=e)
        }
    }

    /**
     * Shutdown the channel, if it is active, and await for termination.
     *
     * @param channel: The channel to shutdown if it is active.
     * @param channelType: A string with the channel type to shutdown. Only needed for the logs.
     */
    fun awaitShutDown(channel: ManagedChannel, channelType: String) {
        if (!channel.isShutdown()) {
            AppLog.v(DebugTAG, "Closing active $channelType channel")
            channel.shutdownNow()
            try {
                val result = channel.awaitTermination(1L, TimeUnit.SECONDS)
                Log.w(
                    DebugTAG,
                    "Close: The result waiting for the $channelType channel termination is: $result"
                )
            } catch (ie: InterruptedException) {
                Log.w(
                    DebugTAG,
                    "Close: Interrupted exception while waiting for $channelType channel shutdown",
                    ie
                )
            } catch (re: RuntimeException) {
                Log.w(
                    DebugTAG,
                    "Close: Runtime exception while waiting for $channelType channel shutdown",
                    re
                )
            }
        }
    }

    private const val GRPC_DEFAULT_PORT = 5001
    const val GRPC_DEFAULT_MAX_TRIES_PER_CALL: Int = 3
}