package com.id365.idverification.internal.views.animations

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import com.id365.idverification.internal.views.IconView
import com.id365.idverification.internal.views.LoadingViewType


@Composable
internal fun LoadingAnimationView(loadingViewType: LoadingViewType) {
    Box(
        modifier = Modifier.fillMaxSize()
    ) {
        IconView(
            modifier= Modifier
                .align(Alignment.Center)
                .fillMaxSize(0.5F)
                .testTag("loadingAnimationView"),
            loadingViewType=loadingViewType
        )
        SpinnerView(modifier = Modifier.align(Alignment.Center).aspectRatio(1F))
    }
}
