package com.id365.idverification.internal.views

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.unit.dp
import com.id365.idverification.IdVerification
import com.id365.idverification.internal.communication.Task
import com.id365.idverification.internal.core.SdkContext
import com.id365.idverification.internal.views.animations.DefaultAnimationView
import com.id365.idverification.internal.views.animations.DefaultAnimations

@Composable
internal fun PrepareAnimationView(
    modifier: Modifier = Modifier,
    task: Task.Level
) {
    Box(
        modifier = modifier
            .clipToBounds(),
        contentAlignment = Alignment.Center
    ) {
        when (task) {
            Task.Level.FRONT_SIDE -> {
                when (SdkContext.documentSizeType) {
                    IdVerification.DocumentSizeType.ID1 -> SdkContext.customTheme.animations.prepareId1Frontside()
                    IdVerification.DocumentSizeType.ID3 -> SdkContext.customTheme.animations.prepareId3()
                    IdVerification.DocumentSizeType.ODD -> SdkContext.customTheme.animations.prepareOddSizedDocument()
                    else -> SdkContext.customTheme.animations.prepareDocument()
                }
            }

            Task.Level.BACK_SIDE -> SdkContext.customTheme.animations.prepareId1Backside()
            Task.Level.NFC -> SdkContext.customTheme.animations.prepareNfc()
            Task.Level.IPROOV -> SdkContext.customTheme.animations.prepareFacematch()
            Task.Level.ODD_SIZE_IMAGE_CAPTURE -> SdkContext.customTheme.animations.prepareOddSizedDocument()
            else -> {}
        }
    }
}