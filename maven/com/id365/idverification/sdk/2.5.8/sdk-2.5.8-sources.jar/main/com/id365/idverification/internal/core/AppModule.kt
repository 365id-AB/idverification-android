package com.id365.idverification.internal.core

import com.id365.idverification.R
import com.id365.idverification.internal.communication.*
import com.id365.idverification.internal.communication.grpc.GrpcCommunicator
import com.id365.idverification.internal.dida.DidaProcessor
import com.id365.idverification.internal.dida.DidaProcessorImplementation
import com.id365.idverification.internal.integrations.iproov.IProovProcessor
import com.id365.idverification.internal.logging.IOtelLogger
import com.id365.idverification.internal.logging.OtelLogger
import com.id365.idverification.internal.model.*
import com.id365.idverification.internal.nfc.*
import com.id365.idverification.internal.nfc.tags.*
import com.id365.idverification.internal.sensoryFeedback.SensoryFeedback
import com.id365.idverification.internal.viewmodel.*
import org.koin.android.ext.koin.androidContext
import org.koin.dsl.module
import org.koin.dsl.onClose
import java.net.URL

/**
 * Configure singleton models in the Koin context with best-matched input parameters.
 */
internal val appModule = module {
    single<ICommunicator> { params ->
        GrpcCommunicator(
            url = URL(androidContext().resources.getString(R.string._365id_frontend_url)),
            vendorId = params.get(),
            request = params.get(),
            context = androidContext()
        )
    } onClose {
        it?.close()
    }
    single<ITransactionModel> { _ ->
        TransactionModel(
            context = androidContext(),
        )
    } onClose {
        it?.stop()
    }
    single { params -> SessionToken(params.get()) }
    factory<ICameraModel> { params ->
        CameraModel(
            context = androidContext(),
            lifecycleOwner = params.get(),
            ar = params.get()
        )
    } onClose {
        it?.close()
    }
    factory<INfcProcessor> { params ->
        NfcProcessor(
            activity = params.get(),
            lfo = params.get(),
            callback = params.get(),
        )
    } onClose {
        it?.close()
    }
    factory<DidaProcessor> { DidaProcessorImplementation() }
    single { params ->
        IProovProcessor(
            ctx = androidContext(),
            transactionId = params.get(),
            callback = params.get(),
        )
    }
    single{ DeviceInformation(androidContext()) }
    single<IOtelLogger> { OtelLogger(androidContext()) }
}

/**
 * Configures ViewModels as factory instances, each with their expected input parameters
 */
internal val viewModules = module {
    factory<IMicroBlinkViewModel> {params ->
        MicroBlinkViewModel(
            context = params.get(),
            lifeCycleOwner = params.get()
        )
    } onClose {
        it?.close()
    }
    factory<IOddSizeImageCaptureViewModel> {params ->
        OddSizeImageCaptureViewModel(
            context = params.get(),
            lifecycleOwner = params.get(),
            sensoryFeedback = SensoryFeedback()
        )
    } onClose {
        it?.close()
    }
    factory<ICameraViewModel> {params ->
        CameraViewModel(
            ctx = params.get(),
            lfo = params.get(),
            ar = params.get()
        )
    } onClose {
        it?.close()
    }
    single<IIdVerificationViewModel> { params ->
        IdVerificationViewModel(
            lfo = params.get()
        )
    } onClose {
        it?.close()
    }
    factory<INfcViewModel> { params ->
        NfcViewModel(
            activity = params.get(),
            lfo = params.get(),
        )
    } onClose {
        it?.close()
    }
    factory<IWaitingViewModel> {params ->
        WaitingViewModel(
            context = params.get(),
        )
    } onClose {
        it?.close()
    }
    single<IIProovViewModel> { params ->
        IProovViewModel(params.get(), params.get())
    } onClose {
        it?.close()
    }
    single<IAlertBoxViewModel> { AlertBoxViewModel() }
    single<IPermissionsViewModel> { PermissionsViewModel(androidContext()) }
    single<IInformationViewModel> { InformationViewModel(androidContext()) }
}

/**
 * All the supported NFC tags
 */
internal val nfcTagModules = module {
    factory { params -> NfcTagB(tag = params.get()) }
    factory { params -> NfcTagA(tag = params.get()) }
    factory { params -> NfcTagIsoDep(tag = params.get()) }
}
