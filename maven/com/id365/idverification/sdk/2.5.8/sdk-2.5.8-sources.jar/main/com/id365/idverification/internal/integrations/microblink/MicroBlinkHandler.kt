package com.id365.idverification.internal.integrations.microblink

import android.content.Context
import android.graphics.Bitmap
import androidx.compose.ui.geometry.Size
import com.id365.idverification.json.FrontBackSideTaskPayload
import com.id365.idverification.json.PrecisionValue
import com.id365.idverification.errors.IdVerificationClientException
import com.id365.idverification.errors.IdVerificationServerException
import com.id365.idverification.internal.communication.ICommunicator
import com.id365.idverification.internal.communication.SessionToken
import com.id365.idverification.internal.core.IdScannerKoinComponent
import com.id365.idverification.internal.logging.AppLog
import com.id365.idverification.internal.model.ITransactionModel
import com.id365.idverification.internal.sensoryFeedback.SensoryFeedback
import com.id365.idverification.internal.utils.CommonUtils.DebugTAG
import com.microblink.capture.CaptureSDK
import com.microblink.capture.licence.exception.InvalidLicenceKeyException
import com.microblink.capture.result.AnalyzerResult
import com.microblink.capture.result.SideCaptureResult
import com.microblink.capture.settings.AnalyzerSettings
import com.microblink.capture.settings.BlurPolicy
import com.microblink.capture.settings.CaptureStrategy
import com.microblink.capture.settings.GlarePolicy
import com.microblink.capture.settings.LightingThresholds
import com.microblink.capture.settings.TiltPolicy
import org.koin.core.component.get
import org.koin.core.component.inject
import org.koin.core.error.DefinitionParameterException
import kotlinx.serialization.json.Json
import androidx.core.graphics.scale


// TODO - Fix all "throw" to exitSDK()
internal class MicroBlinkHandler(val context: Context): IdScannerKoinComponent() {

    private val transactionModel: ITransactionModel by inject()

    companion object {
        private var didSetLicenceKey: Boolean = false
        private val LANDSCAPE_SIZE_ID01 = Size(1712f, 1080f)
        private val LANDSCAPE_SIZE_ID03 = Size(2500f, 1760f)
        private val PORTRAIT_SIZE_ID01 = Size(1080f, 1712f)
        private val PORTRAIT_SIZE_ID03 = Size(1760f, 2500f)
    }

    init {
        setLicenceKey()
    }

    /** Called when the camera captured a result */
    internal fun handleAnalyzerResult(analyzerResult: AnalyzerResult?) {

        val firstCapture: SideCaptureResult = analyzerResult?.firstCapture ?: run {
            val errorMsg = "Could not get firstCapture from MicroBlink."
            AppLog.e(DebugTAG, errorMsg)
            throw Exception(errorMsg)
        }

        // Get images from Microblink
        val transformedImageTooSmall: Bitmap = firstCapture.transformedImageResult?.image?.convertToBitmap() ?: run {
            val errorMsg = "Could not get transformedImage from MicroBlink."
            AppLog.e(DebugTAG, errorMsg)
            throw Exception(errorMsg)
        }
        val capturedImage: Bitmap = firstCapture.imageResult.image.convertToBitmap() ?: run {
            val errorMsg = "Could not get capturedImage from MicroBlink."
            AppLog.e(DebugTAG, errorMsg)
            throw Exception(errorMsg)
        }

        val targetSize: Size = getDocumentTargetSize(transformedImageTooSmall)

        // BUG - This image is too small, we need to resize - (ex: Driver licence from 1347x850 to 1712x1080)
        val transformedImage: Bitmap = resizeImage(
            image = transformedImageTooSmall,
            targetSize = targetSize
        )

        AppLog.i(DebugTAG, "Microblink - Captured a valid image!")

        // Play shutter sound and vibrate the device
        val sensoryFeedback = SensoryFeedback()
        sensoryFeedback.playShutterSound(context)
        sensoryFeedback.vibrate(context)

        transactionModel.takePicture(
            bitmap=transformedImage,
            debug=capturedImage,
            preview=null
        )

    }

    /** Compress an image to jpg quality to 80% */
    /*private fun compressImage(image: Bitmap): ByteArray? {
        val stream = ByteArrayOutputStream()
        image.compress(Bitmap.CompressFormat.JPEG, 80, stream)
        return try {
            stream.toByteArray()
        } catch (e: Exception) {
            null
        }
    }*/

    /** Change size of an image */
    private fun resizeImage(image: Bitmap, targetSize: Size): Bitmap {
        val size = Size(image.width.toFloat(), image.height.toFloat())

        // Check if it already has the correct size
        if (size.width == targetSize.width && size.height == targetSize.height) {
            return image
        }

        val widthRatio = targetSize.width / size.width
        val heightRatio = targetSize.height / size.height

        // Figure out what our orientation is, and use that to form the rectangle
        val newSize: Size = if (widthRatio > heightRatio) {
            Size(size.width * heightRatio, size.height * heightRatio)
        } else {
            Size(size.width * widthRatio, size.height * widthRatio)
        }

        return image.scale(newSize.width.toInt(), newSize.height.toInt())
    }

    /** Check the ratio to decide if it is an ID1 or ID3. */
    private fun getDocumentTargetSize(image: Bitmap): Size {
        val ratio: Float = image.width.toFloat() / image.height.toFloat()
        if (ratio > 1.0) {
            // Landscape
            return if (ratio > 1.48) {
                // ID1
                LANDSCAPE_SIZE_ID01
            } else {
                // ID3
                LANDSCAPE_SIZE_ID03
            }
        } else {
            // Portrait
            return if (ratio > 0.67) {
                // ID3
                PORTRAIT_SIZE_ID03
            } else {
                // ID1
                PORTRAIT_SIZE_ID01
            }
        }
    }

    /** Set LicenceKey to Microblink SDK. */
    private fun setLicenceKey() {
        if (didSetLicenceKey) return
        val sessionToken = try {
            get<SessionToken>()
        } catch(exception: DefinitionParameterException) {
            val errorMsg = "Error could not get sessionToken in MicroBlink: ${exception.message}"
            transactionModel.handleError(IdVerificationServerException(errorMsg))
            throw Exception(errorMsg)
        }
        val microBlinkLicenseKey = sessionToken.microBlinkLicenseKey
        if (microBlinkLicenseKey.isEmpty()) {
            val errorMsg = "Missing licenseKey in MicroBlink."
            transactionModel.handleError(IdVerificationServerException(errorMsg))
            throw Exception(errorMsg)
        }
        try {
            CaptureSDK.setLicenseKey(
                base64LicenseKey = microBlinkLicenseKey,
                licensee = "com.id365.idverification",
                applicationContext = context
            )
        }
        catch (exception: InvalidLicenceKeyException) {
            val errorMsg = "Error could not set MicroBlink licenceKey: ${exception.message}"
            transactionModel.handleError(IdVerificationClientException(errorMsg))
            throw Exception(errorMsg)
        }
        didSetLicenceKey = true
        AppLog.d(DebugTAG, "Microblink - Did set licence key!")
    }

    /** Get custom AnalyserSettings of Microblink SDK. */
    internal fun getAnalyserSettings(): AnalyzerSettings {

        return AnalyzerSettings(
            captureSingleSide = true,
            returnTransformedDocumentImage = true,
            captureStrategy = CaptureStrategy.OptimizeForQuality,
            minimumDocumentDpi = 250,
            adjustMinimumDocumentDpi = true,
            documentFramingMargin = 0.01f,
            keepMarginOnTransformedDocumentImage = false,
            lightingThresholds = getLightingThresholds(),
            blurPolicy = BlurPolicy.Normal,
            glarePolicy = GlarePolicy.Normal,
            handOcclusionThreshold = 0.02f,
            tiltPolicy = TiltPolicy.Normal
        )
    }

    /** Get custom LightingThresholds of Microblink SDK. */
    private fun getLightingThresholds(): LightingThresholds {
        return LightingThresholds(
            tooDarkThreshold = 0.99f,
            tooBrightThreshold = 0.99f
        )
    }
}