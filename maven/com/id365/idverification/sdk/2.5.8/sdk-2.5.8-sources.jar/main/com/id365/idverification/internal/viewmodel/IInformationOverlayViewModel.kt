package com.id365.idverification.internal.viewmodel

import androidx.compose.runtime.MutableState
import com.id365.idverification.internal.communication.Task

internal interface IInformationOverlayViewModel {
    val taskData: MutableState<Task>
    val infoText: MutableState<String>
    val playAnimation: MutableState<Boolean>
    val buttonCb: () -> Unit
    val buttonLabel: String
    val buttonEnabled: MutableState<Boolean>
}