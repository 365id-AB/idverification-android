package com.id365.idverification.internal.dida

import android.util.Log
import com.google.mlkit.vision.barcode.common.Barcode
import com.id365.idverification.internal.analysis.QrCodeAnalyzer
import com.id365.idverification.internal.communication.ICommunicator
import com.id365.idverification.internal.communication.SessionToken
import com.id365.idverification.internal.core.IdScannerKoinComponent
import com.id365.idverification.internal.model.ITransactionModel
import com.id365.idverification.internal.utils.CommonUtils.DebugTAG
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import org.koin.core.component.get
import org.koin.core.component.inject
import org.koin.core.error.DefinitionParameterException

internal class DidaProcessorImplementation(
    private val dispatcher: CoroutineDispatcher = Dispatchers.Default
) : DidaProcessor, IdScannerKoinComponent() {

    val communicator: ICommunicator by inject()

    var active: Boolean = true

    private val handledBarcodes = mutableListOf<String>()

    private val semaphore = Semaphore(1)

    override fun process(barcode: Barcode) = semaphore.tryAcquireAndRun {
        if (!active)
            return@tryAcquireAndRun
        if (barcode.rawValue.isNullOrEmpty())
            return@tryAcquireAndRun
        if (handledBarcodes.contains(barcode.rawValue)) {
            return@tryAcquireAndRun
        }
        barcode.rawValue?.let {
            handledBarcodes.add(it)
            Log.d(DebugTAG, "Added $it to handled")
            Log.d(DebugTAG, "There are ${handledBarcodes.size} elements in the list")
        }
        handleBarcode(barcode)
        return@tryAcquireAndRun
    }

    suspend fun handleBarcode(barcode: Barcode, preferredProvider: String = "") {
        if (!active)
            return
        if (!isValid(barcode.rawValue))
            return

        val sessionToken = try {
            get<SessionToken>()
        } catch(dpe: DefinitionParameterException) {
            return
        }

        barcode.format
        // val encoded = Base64.encode(barcode.rawBytes, 0)
        val encoded = barcode.rawBytes!!
        val content = DocumentContent(
            contentSource = when (barcode.format) {
                Barcode.FORMAT_QR_CODE -> "QR"
                else -> "Barcode"
            },
            contentStandard = "]Q0", // AIM Identifier
            preferedDigitalIdProvider = preferredProvider,
            data = encoded
        )

        val request = DidaRequest(
            transactionId = sessionToken.transactionId,
            correlationId = sessionToken.transactionId,
            deviceId = sessionToken.sourceId,
            tokenId = sessionToken.token,
            content = content,
        )

        Log.d(DebugTAG, "${handledBarcodes.size} DIDA Request: $request")

        val response = communicator.didaIdentify(request)

        Log.d(DebugTAG, "$response")
        when(response.assessmentStatus) {
            DidaStatus.Processing -> {
                active = false
                get<ITransactionModel>().requestNextTask()
            }
            DidaStatus.MultipleCompatible -> handleBarcode(barcode, "BANKID")
            else -> {
                Log.w(DebugTAG, "Incompatible QR code")
            }
        }
    }


    private fun Semaphore.tryAcquireAndRun(block: suspend () -> Unit) {
        if (tryAcquire()) {
            CoroutineScope(dispatcher).launch {
                block.invoke()
                release()
            }
        }
    }


    private fun isValid(barcode: String?): Boolean {
        if (barcode == null) {
            Log.d(QrCodeAnalyzer.DebugTAG, "Invalid barcode")
            return false
        }
        val invalidBarcode = "^[0-9]+$".toRegex()
        if (invalidBarcode.find(barcode) != null) {
            Log.d(QrCodeAnalyzer.DebugTAG, "Barcode is all numbers")
            return false
        }
        return true
    }
}
