package com.id365.idverification.internal.views

import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeContentPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.id365.idverification.IdVerification
import com.id365.idverification.internal.communication.Task
import com.id365.idverification.internal.communication.UserMessage
import com.id365.idverification.internal.core.SdkContext
import com.id365.idverification.internal.core.SdkContext.sdk
import com.id365.idverification.internal.ui.theme.Id365ScannerSdkTheme
import com.id365.idverification.internal.viewmodel.IInformationOverlayViewModel
import com.id365.idverification.internal.viewmodel.IMicroBlinkViewModel

@Composable
internal fun InformationOverlayView(
    modifier: Modifier = Modifier,
    buttonParams: List<ButtonParams> = emptyList(),
    model: IInformationOverlayViewModel = sdk.koin.get(),
){
    Column(
        modifier = modifier
            .clip(shape = RoundedCornerShape(40.dp, 40.dp, 0.dp, 0.dp))
            .background(MaterialTheme.colorScheme.surface)
            .fillMaxWidth()

            .windowInsetsPadding(WindowInsets(left = 24.dp, right = 24.dp))
            .safeContentPadding(),
        verticalArrangement = Arrangement.SpaceEvenly,
        horizontalAlignment = Alignment.CenterHorizontally
    ){
        TitleAndInstructionLayer(model=model)
        Spacer(modifier=Modifier)
        ButtonLayer(model=model, buttonParams=buttonParams)
        Spacer(modifier=Modifier)
    }
}

@Composable
private fun TitleAndInstructionLayer(
    modifier: Modifier = Modifier,
    model: IInformationOverlayViewModel
) {
    val task by model.taskData

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp),
        contentAlignment = Alignment.TopCenter
    ) {
        // These only work INSIDE the BoxWithConstraints scope
        val totalAvailable = this.maxHeight
        val maxW = this.maxWidth

        // Reserve space for buttons etc.
        val reservedForButtons = totalAvailable * 0.35f
        val maxImageHeight = totalAvailable - reservedForButtons

        // Natural image height from 3:2 aspect ratio
        val naturalImageHeight = maxW * 2f / 3f

        // Image height that fits the available area
        val finalHeight = minOf(maxImageHeight, naturalImageHeight)

        Box(
            modifier = Modifier
                .width(maxW)
                .height(finalHeight)
                .clipToBounds(),
            contentAlignment = Alignment.Center
        ) {
            when (task.nextTask) {
                Task.Level.FRONT_SIDE -> {
                    when (SdkContext.documentSizeType) {
                        IdVerification.DocumentSizeType.ID1 -> SdkContext.customTheme.animations.instructionId1Frontside()
                        IdVerification.DocumentSizeType.ID3 -> SdkContext.customTheme.animations.instructionId3()
                        else -> SdkContext.customTheme.animations.instructionDocument()
                    }
                }
                Task.Level.BACK_SIDE -> SdkContext.customTheme.animations.instructionId1Backside()
                Task.Level.NFC -> SdkContext.customTheme.animations.instructionNfc()
                else -> {}
            }
        }
    }
}

@Composable
private fun ButtonLayer(
    model: IInformationOverlayViewModel = sdk.koin.get(),
    buttonParams: List<ButtonParams> = emptyList()
) {
    if(buttonParams.isNotEmpty()) {
        Column {
            buttonParams.forEach { param ->
                Button(
                    colors = ButtonDefaults.buttonColors(containerColor = param.buttonColor),
                    modifier = Modifier
                        .height(50.dp)
                        .fillMaxWidth()
                        .testTag(param.testTag),
                    onClick = { param.onClick() },
                    shape = RoundedCornerShape(8.dp),
                    enabled = model.buttonEnabled.value
                ) {
                    Text(text = param.text, color = param.textColor, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(8.dp))
            }
        }
    } else {
        Button(
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
            modifier = Modifier
                .height(50.dp)
                .fillMaxWidth()
                .testTag("WhiteInformationOverlayButton"),
            onClick = { model.buttonCb() },
            shape = RoundedCornerShape(8.dp),
            enabled = model.buttonEnabled.value
        ) {
            Text(text = model.buttonLabel, color = MaterialTheme.colorScheme.onSecondaryContainer, fontWeight = FontWeight.Bold)
        }
    }
}

data class ButtonParams(
    val text: String,
    val buttonColor: Color,
    val textColor: Color,
    val onClick: () -> Unit,
    val testTag: String
)

@Preview(widthDp = 900, heightDp = 1600)
@Preview(name = "4/3", widthDp = 768, heightDp = 1024)
@Preview
@Composable
fun PreviewInformationOverlayView()
{
    val model by remember { mutableStateOf(object : IMicroBlinkViewModel {
        override fun startMicroBlinkSdk(previewView: PreviewView) {}
        override fun getDocumentSizeType() = IdVerification.DocumentSizeType.DOCUMENT
        override val didCaptureImage = mutableStateOf(false)
        override val warningStatusMessage = mutableStateOf<String?>("You are holding it wrong")
        override val warningStatus = mutableStateOf(true)
        override val taskData: MutableState<Task>
            get() = mutableStateOf(Task(nextTask = Task.Level.FRONT_SIDE ,message = UserMessage("ejh", "hej"), taskPayload = "asdasd"))
        override val infoText = mutableStateOf("Frontside text")
        override val buttonCb: () -> Unit = {buttonEnabled.value = false}
        override val buttonLabel = "OK"
        override val buttonEnabled = mutableStateOf(true)
        override val playAnimation = mutableStateOf(true)
        override fun close() {}
    }) }

    Id365ScannerSdkTheme {
        Box(modifier= Modifier
            .fillMaxSize()
            .background(Brush.horizontalGradient(listOf(Color.Blue, Color.Green))))
        {
            InformationOverlayView(
                modifier = Modifier
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65F))
                    .align(Alignment.BottomCenter),
                model=model
            )
        }
    }
}
