package com.id365.idverification.internal.views

import android.content.Context
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeContentPadding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.LifecycleOwner
import com.id365.idverification.internal.core.SdkContext
import com.id365.idverification.internal.core.SdkContext.sdk
import com.id365.idverification.internal.logging.AppLog
import com.id365.idverification.internal.ui.theme.Id365ScannerSdkTheme
import com.id365.idverification.internal.viewmodel.IMicroBlinkViewModel
import com.id365.idverification.internal.viewmodel.IWaitingViewModel
import com.id365.idverification.internal.views.informationview.CancelButton
import org.koin.core.parameter.parametersOf

/**
 * When waiting for a new task, display model.preview if available.
 * Either way, displays the ViewFinderView and an animated spinner in
 * the middle of the ViewFinder.
 */
@Composable
internal fun WaitingView(
    loadingViewType: LoadingViewType = LoadingViewType.Spinner,
    context: Context = LocalContext.current,
    lifecycleOwner: LifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current,
    model: IWaitingViewModel? = try {
        sdk.koin.get(parameters = {
            parametersOf(
                context,
                lifecycleOwner
            )
        })
    } catch(e: Exception) {
        AppLog.e("WaitingView", "Unexpected exception when showing waiting view", e)
        null
    }
) {
    model?.let {
        Box(modifier = Modifier
            .fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            LoadingView(
                modifier = Modifier
                    .fillMaxWidth(0.5F)
                    .aspectRatio(1f),
                loadingViewType = loadingViewType
            )
            CancelButton(modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(vertical=20.dp)
                .windowInsetsPadding(WindowInsets(left = 24.dp, right = 24.dp))
                .safeContentPadding()
            ) {
                model.cancelButtonCallback.invoke()
            }
        }
    }
}

@Preview(device = "spec:width=411dp,height=891dp", showBackground = true)
@Composable
private fun  WaitingViewPreview() {
    Id365ScannerSdkTheme {
        Box(modifier=Modifier.fillMaxSize()) {
            WaitingView()
        }
    }
}