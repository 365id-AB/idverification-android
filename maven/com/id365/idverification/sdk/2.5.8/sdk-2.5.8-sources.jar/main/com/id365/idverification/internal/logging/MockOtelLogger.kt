package com.id365.idverification.internal.logging

/**
 * Mock implementation of IOtelLogger, for testing.
 */
class MockOtelLogger : IOtelLogger {
    override fun log(tag: String, message: String, transactionId: String?, severity: Int) {
        // Do nothing
    }
}