package com.id365.idverification.internal.views

import androidx.compose.runtime.Composable

/**
 * Shows when an SDK transaction completed successfully. Will not be visible for long,
 * as the callback to the calling app should dismiss the SDK first.
 */
@Composable
internal fun SuccessView() {
}
