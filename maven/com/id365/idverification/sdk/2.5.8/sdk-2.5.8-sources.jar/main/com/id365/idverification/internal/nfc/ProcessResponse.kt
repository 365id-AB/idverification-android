package com.id365.idverification.internal.nfc
import kotlinx.serialization.Serializable

/**
 * Describes a list of NFC commands to be run on the target tag.
 */
@Serializable
internal data class ProcessResponse(
    /**
     * NfcService state, passed along blindly by the client
     */
    val state: String = "",

    /**
     * Array of requests to be relayed to the NFC chip
     */
    val requests: List<ChipRequest> = emptyList(),

    /**
     * If true, the process is completed and no more requests should be made
     */
    val isCompleted: Boolean = false,

    /**
     * User friendly status messages, giving the client the option to
     * show status messages to the user
     */
    val status: String = "",

    /**
     * Process of NFC completion in percentage
     */
    val progressPercent: Double = 0.0
)
