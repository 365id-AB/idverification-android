package com.id365.idverification.internal.communication.grpc

import android.content.Context
import android.graphics.Rect
import android.util.Log
import com.google.protobuf.ByteString
import com.google.protobuf.kotlin.toByteString
import com.id365.idverification.IdVerificationRequest
import com.id365.idverification.internal.core.SdkContext
import com.id365.idverification.contracts.grpc.coordinator.*
import com.id365.idverification.contracts.grpc.coordinator.CoordinatorOuterClass.AbortTransactionReply
import com.id365.idverification.contracts.grpc.coordinator.CoordinatorOuterClass.Reason
import com.id365.idverification.contracts.grpc.devicetype.DeviceType
import com.id365.idverification.contracts.grpc.digitalidentification.DigitalIdentificationGrpcKt
import com.id365.idverification.contracts.grpc.digitalidentification.didaRequest
import com.id365.idverification.contracts.grpc.digitalidentification.documentContent
import com.id365.idverification.contracts.grpc.digitalidentification.guid
import com.id365.idverification.contracts.grpc.identification.*
import com.id365.idverification.contracts.grpc.nfc.NfcGrpcKt
import com.id365.idverification.contracts.grpc.session.*
import com.id365.idverification.contracts.grpc.iproov.*
import com.id365.idverification.errors.IdVerificationInvalidTokenException
import com.id365.idverification.errors.IdVerificationServerException
import com.id365.idverification.internal.communication.AbortReason
import com.id365.idverification.internal.core.IdScannerKoinComponent
import com.id365.idverification.internal.communication.DeviceInformation
import com.id365.idverification.internal.communication.ICommunicator
import com.id365.idverification.internal.communication.SessionToken
import com.id365.idverification.internal.communication.Task
import com.id365.idverification.internal.dida.DidaRequest
import com.id365.idverification.internal.dida.DidaResponse
import com.id365.idverification.internal.integrations.iproov.*
import com.id365.idverification.internal.nfc.*
import com.id365.idverification.internal.logging.AppLog
import com.id365.idverification.internal.model.ITransactionModel
import io.grpc.*
import io.grpc.Status
import kotlinx.coroutines.*
import org.koin.core.component.inject
import org.koin.core.error.ClosedScopeException
import org.koin.core.parameter.parametersOf
import java.io.Closeable
import java.net.URL
import java.util.Locale

/**
 * GrpcCommunicator implements the ICommunicator interface using gRPC
 *
 * @param url: The gRPC-backed endpoint this communicator will talk to
 * @param vendorId: The Device-unique identifier distinguishing this device from others
 * @param request: A _365iDRequest containing a token and location used for initial authentication
 */
internal class GrpcCommunicator(
    override val url: URL,
    override val vendorId: String,
    override val request: IdVerificationRequest,
    val context: Context,
) : ICommunicator, Closeable, IdScannerKoinComponent() {

//    Population the device info as early as possible to avoid problems
    private val device: DeviceInformation by inject()

    private var token = ""
    private lateinit var regionalUrl: URL

    private val transactionModel: ITransactionModel by inject()

    /**
     * Create a gRPC channel using TLS
     */
    private var sessionChannel: ManagedChannel = Id365Channel.channel(url)
    private lateinit var transactionChannel: ManagedChannel

    private var sessionDelegate = lazy { SessionGrpcKt.SessionCoroutineStub(sessionChannel) }
    private var coordinatorDelegate = lazy { CoordinatorGrpcKt.CoordinatorCoroutineStub(transactionChannel) }
    private var identificationDelegate = lazy { IdentificationGrpcKt.IdentificationCoroutineStub(transactionChannel) }
    private var nfcDelegate = lazy { NfcGrpcKt.NfcCoroutineStub(transactionChannel) }
    private var iProovDelegate = lazy { iProovGrpcKt.iProovCoroutineStub(transactionChannel) }
    private var didaDelegate = lazy { DigitalIdentificationGrpcKt.DigitalIdentificationCoroutineStub(transactionChannel) }

    override fun authenticate() = CoroutineScope(Dispatchers.IO).launch {
        tryGrpc(
            methodName = "authenticate",
            tries = 1,
            errorHandler = { e ->
                try {
                    val exc = if (e is StatusException && e.status.code == Status.UNAUTHENTICATED.code) {
                        IdVerificationInvalidTokenException(exception = e)
                    } else {
                        IdVerificationServerException(exception = e)
                    }
                    transactionModel.handleError(exc)
                } catch(cse: ClosedScopeException) {
                    Log.e(DebugTAG, "Attempted to access koin but the scope was already closed: $cse")
                } catch(e: Exception) {
                    Log.e(DebugTAG, "Something very bad happened: $e")
                }
                return@tryGrpc
            }
        ) {
            val vid = vendorId
            val authRequest = sessionTokenRequest {
                this.vendorId = vid
                this.locationId = request.locationId
                this.locationName = request.locationName
                this.deviceInformation = deviceInformation(device)
                this.deviceType = DeviceType.DeviceTypeEnum.GLOOTIESDK
                this.modulesToSkip.addAll(SdkContext.skipModules.getModulesToSkipForGrpc())
                this.documentSizeType = SdkContext.documentSizeType.toGrpcDocumentSizeTypeEnum()
                this.languageCode = Locale.getDefault().language
            }

            val sessionService by sessionDelegate
            val response = runBlocking {
                sessionService.sessionToken(
                    authRequest,
                    headers(request.token)
                )
            }

            token = response.token
            regionalUrl = URL("https://${response.regionInformation.endpoint}:443")
            AppLog.v(DebugTAG, "Regional URL: $regionalUrl")
            transactionChannel = Id365Channel.channel(regionalUrl)
            Log.d(DebugTAG, "The regionalUrl is: $regionalUrl")
            getKoin().get<SessionToken>(parameters = { parametersOf(token) })
            AppLog.v(DebugTAG, "Session ready")
            SdkContext.sessionReady.postValue(true)
            return@tryGrpc
        }
    }

    private fun createChannel() {
        runBlocking {
            Id365Channel.awaitShutDown(sessionChannel, "session")
            if (::transactionChannel.isInitialized)
                Id365Channel.awaitShutDown(transactionChannel, "transaction")
        }
        sessionChannel = Id365Channel.channel(url)
        transactionChannel = Id365Channel.channel(regionalUrl)
        sessionDelegate = lazy { SessionGrpcKt.SessionCoroutineStub(sessionChannel) }
        coordinatorDelegate = lazy { CoordinatorGrpcKt.CoordinatorCoroutineStub(transactionChannel) }
        identificationDelegate = lazy { IdentificationGrpcKt.IdentificationCoroutineStub(transactionChannel) }
        nfcDelegate = lazy { NfcGrpcKt.NfcCoroutineStub(transactionChannel) }
        iProovDelegate = lazy { iProovGrpcKt.iProovCoroutineStub(transactionChannel) }
        didaDelegate = lazy { DigitalIdentificationGrpcKt.DigitalIdentificationCoroutineStub(transactionChannel) }
    }

    /**
     * Close any channels still active. This doesn't affect anything visual, but is good practice to
     * reduce noise when logging
     */
    override fun close() {
        AppLog.i(DebugTAG, "Closing active channels")
        runBlocking {
                Id365Channel.awaitShutDown(sessionChannel, "session")
            if (::transactionChannel.isInitialized)
                Id365Channel.awaitShutDown(transactionChannel, "transaction")
        }
    }

    /**
     * When Java GC wants to cleanup, we close any active channels
     */
    protected fun finalize() {
        close()
    }

    /**
     * This defines the HTTP headers we add to our gRPC communications
     */
    private fun headers(token: String = ""): Metadata {
        return Metadata().also {
            it.put(
                Metadata.Key.of("Authorization", Metadata.ASCII_STRING_MARSHALLER),
                "Bearer $token"
            )
        }
    }

    /**
     * Implement requesting the next task using gRPC
     *
     * @param state: The previous state
     *
     * @return a Task as defined in CoordinatorTask.proto
     */
    override suspend fun nextTaskRequest(state: String): Task {
        val request = nextTaskRequest {
            this.state = state
        }
        return tryGrpc(
            methodName = "nextTaskRequest",
            errorHandler = {
                throw it
            }
        ) {
            val coordinatorService by coordinatorDelegate
            val response = coordinatorService.nextTask(
                request = request,
                headers = headers(token)
            )
            return@tryGrpc Task(response)
        }
    }
    /**
     * Implement requesting the abort transaction using gRPC
     *
     * @param Reason: Reason for aborting
     *
     * @return an empty answer as defined in CoordinatorTask.proto
     */
    override suspend fun abortTransactionRequest(reason: AbortReason): AbortTransactionReply {
        val request = abortTransactionRequest {
            this.reason = reason.toGrpc()
        }

        return tryGrpc(
            methodName = "AbortTransactionRequest",
            errorHandler = { e ->
                if (e is StatusException) {
                    AppLog.e("AbortTransactionRequest", "gRPC call failed", e)
                }
                throw IdVerificationServerException("Abort transaction failed", e)
            }
        ) {
            val coordinatorService by coordinatorDelegate
            val response = coordinatorService.abortTransaction(
                request = request,
                headers = headers(token)
            )
            if (response == AbortTransactionReply.getDefaultInstance()) {
                AppLog.i("AbortTransactionRequest", "AbortTransactionRequest succeeded with reason: $reason")
            } else {
                AppLog.i("AbortTransactionRequest", "AbortTransactionRequest failed")
            }
            response
        }
    }
    /**
     * Implement sending a picture for identification using gRPC
     *
     * @param image: The raw picture represented as a byte array
     *
     * @return the updated state
     */
    override suspend fun sendImageForIdentification(
        image: ByteArray,
        debug: ByteArray?,
        debugRoi: Rect?,
        manuallyTriggered: Boolean,
        skipAnalysis: Boolean
    ): Boolean {
        val request = identifyRequest {
            whiteImage = image.toByteString()
            debug?.let { debugOriginalImageFile = it.toByteString() }
            debugRoi?.let {
                debugROI = regionOfInterest {
                    left = it.left
                    top = it.top
                    width = it.width()
                    height = it.height()
                }
            }
            this.skipAnalysis = skipAnalysis
            this.manuallyTriggered = manuallyTriggered
        }
        return tryGrpc(
            methodName = "sendImageForIdentification",
            errorHandler = {
                return@tryGrpc false
            }
        ) {
            val identificationService by identificationDelegate
            identificationService.identify(
                request = request,
                headers = headers(token)
            )
            return@tryGrpc true
        }
    }

    /**
     * Implement sending and receiving Nfc processing data using gRPC
     *
     * @param processRequest: The request with state, standard and responses
     *
     * @return A response containing updated state, chip requests
     * to execute and whether the process has completed or not
     */
    override suspend fun processNfc(processRequest: ProcessRequest): ProcessResponse {
        val request = processRequest(processRequest)
        return tryGrpc(
            methodName = "processNfc",
            errorHandler = {
                return@tryGrpc ProcessResponse(
                    state = processRequest.state,
                    isCompleted = true,
                )
            }
        ) {
            AppLog.v(DebugTAG, "$processRequest")
            val nfcService by nfcDelegate
            val response =
                ProcessResponse(
                    nfcService.process(
                        request = request,
                        headers = headers(token)
                    )
                )
            AppLog.v(DebugTAG, "$response")
            return@tryGrpc response
        }
    }

    override suspend fun didaIdentify(request: DidaRequest): DidaResponse {
        val grpcRequest = didaRequest {
            transactionId = request.transactionId
            content = documentContent {
                contentSource = request.content.contentSource
                contentStandard = request.content.contentStandard
                data = ByteString.copyFrom(request.content.data)
            }
            correlationId = guid { value = request.correlationId }
            deviceId = request.deviceId
            deviceType = DeviceType.DeviceTypeEnum.GLOOTIESDK
            tokenId = request.tokenId
        }
        return tryGrpc(
            methodName = "didaIdentify",
            errorHandler = {
                throw it
            }
        ) {
            AppLog.v(DebugTAG, "$grpcRequest")
            val didaService by didaDelegate
            val response = didaResponse(didaService.identify(grpcRequest, headers(token)))
            AppLog.v(DebugTAG, "$response")
            return@tryGrpc response
        }
    }

    /**
     * Implement sending iProovEnrolUser request to IProovService
     *
     * @param request: A request to enrol user. Should contain the current transactionId
     *
     * @return A response containing the enrol status, and a token
     * to authenticate with IProov backend
     */
    override suspend fun iProovEnrolUser(request: EnrolUserRequest): EnrolUserResponse {
        val enrol = enrolUserRequest {
            transactionId = request.transactionId
        }
        return tryGrpc(
            methodName = "iProovEnrolUser",
            errorHandler = {
                return@tryGrpc EnrolUserResponse(success = false)
            }
        ) {
            val iProovService by iProovDelegate
            val response = EnrolUserResponse(
                iProovService.enrolUser(
                    request = enrol,
                    headers = headers(token)
                )
            )
            AppLog.v(DebugTAG, "$response")
            return@tryGrpc response
        }
    }

    override suspend fun iProovValidateEnrol(request: ValidateEnrolRequest): ValidateEnrolResponse {
        val validate = validateEnrolRequest(request)
        return tryGrpc(
            methodName = "iProovValidateEnrol",
            errorHandler = {
                return@tryGrpc ValidateEnrolResponse(success = false)
            }
        ) {
            val iProovService by iProovDelegate
            val response = ValidateEnrolResponse(
                success = iProovService.validateEnrol(
                    request = validate,
                    headers = headers(token)
                ).success
            )
            AppLog.v(DebugTAG, "$response")
            return@tryGrpc response
        }
    }

    override suspend fun iProovTokenRequest(request: IProovTokenRequest): IProovTokenResponse {
        val tokenRequest = tokenRequest {
            transactionId = request.transactionId
        }
        return tryGrpc(
            methodName = "iProovToken",
            errorHandler = {
                return@tryGrpc IProovTokenResponse()
            }
        ) {
            val iProovService by iProovDelegate
            val response = iProovTokenResponse(iProovService.retrieveToken(
                    request = tokenRequest,
                    headers = headers(token)
                ))

            AppLog.v(DebugTAG, "$response")
            return@tryGrpc response
        }
    }

    /**
     * To try an grpc-call x number of times.
     *
     * @param methodName: A string for the current method while debugging logs
     * @param tries: Number of tries to try the grpc-call
     * @param block: The block of code for the grpc-call to try
     */
    private suspend fun <T> tryGrpc(
        methodName: String,
        tries: Int = Id365Channel.GRPC_DEFAULT_MAX_TRIES_PER_CALL,
        errorHandler: suspend (exc: Exception) -> T,
        block: suspend () -> T
    ): T {
        AppLog.v(DebugTAG, methodName)
        for (tryCount in tries downTo 1) {
            try {
                return block.invoke()
            } catch (e: StatusException) {
                AppLog.e(DebugTAG, "gRPC error during $methodName: $e", e)
                when(e.status) {
                    Status.PERMISSION_DENIED,
                    Status.UNAUTHENTICATED -> {
                        return errorHandler.invoke(e)
                    }
                    Status.UNAVAILABLE,
                    Status.DATA_LOSS -> {
                        try {
                            AppLog.w(DebugTAG, "Channel is unavailable, recreating GRPC channel ($e)")
                            createChannel()
                        } catch(e: Exception) {
                            AppLog.e(DebugTAG, "Unable to recreate GRPC channel", e)
                            return errorHandler.invoke(e)
                        }
                    }
                }
                if (tryCount > 1) {
                    AppLog.e(DebugTAG, "Retrying, remaining attempts: $tryCount")
                    continue
                }
                return errorHandler.invoke(e)
            } catch (e: Exception) {
                AppLog.e(DebugTAG, "Exception ($methodName) happened during gRPC communication: $e")
                if (tryCount > 1) {
                    AppLog.e(DebugTAG, "Retrying, remaining attempts: $tryCount")
                    continue
                }
                return errorHandler.invoke(e)
            }
        }
        AppLog.e(DebugTAG, "gRPC has no more tries to $methodName.")
        return errorHandler.invoke(Exception("gRPC has no more tries to $methodName."))
    }

    companion object {
        private const val DebugTAG = "GrpcCommunicator"
    }
}
