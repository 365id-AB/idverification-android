package com.id365.idverification.internal.integrations.iproov

/**
 * SDK internal representation of an EnrolUserRequest
 */
internal data class EnrolUserRequest(
    val transactionId: String,
)
