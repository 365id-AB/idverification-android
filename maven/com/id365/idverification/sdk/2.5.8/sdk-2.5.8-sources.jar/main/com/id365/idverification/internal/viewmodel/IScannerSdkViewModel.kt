package com.id365.idverification.internal.viewmodel

import androidx.compose.runtime.MutableState
import com.id365.idverification.internal.communication.SessionToken
import com.id365.idverification.internal.communication.Task
import java.io.Closeable

/**
 * Interface describes the View Model for the main SDK view
 */
internal interface IIdVerificationViewModel: Closeable {

    /**
     * If a "White Information View" should be shown or not
     */
    val showInformationView: MutableState<Boolean>
    /**
     * This describes to the main View which subview(s) should be drawn and presented to the end-user
     */
    val task: MutableState<Task.Level>

    /**
     * If the user decides to dismiss the main view early, this callback should be triggered.
     */
    val callback: () -> Unit

    /**
     * Access the session token
     */
    fun getSessionToken(): SessionToken?
}