package com.id365.idverification.internal.viewmodel

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.compose.runtime.mutableStateOf
import androidx.core.content.ContextCompat
import androidx.core.net.toUri

/**
 * The permissions view model is used to track camera permission state across several views that
 * rely on knowing this state
 */
internal class PermissionsViewModel(ctx: Context) : IPermissionsViewModel {
    override val cameraPermission = mutableStateOf(
        ContextCompat.checkSelfPermission(
            ctx, Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED
    )

    /**
     * When user presses the button, open the device settings directly to NFC
     * @param: context: The context is needed to start a new activity
     */
    override fun openSettings(context: Context) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
        intent.data = ("package:" + context.packageName).toUri()
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ContextCompat.startActivity(context, intent, null)
    }
}