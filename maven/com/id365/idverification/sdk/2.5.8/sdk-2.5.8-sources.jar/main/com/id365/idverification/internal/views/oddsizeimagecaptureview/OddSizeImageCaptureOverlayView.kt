package com.id365.idverification.internal.views.oddsizeimagecaptureview

import FadeAndScaleOut
import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.util.Log
import androidx.compose.animation.EnterExitState
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.core.animateDp
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.google.accompanist.insets.LocalWindowInsets
import com.id365.idverification.internal.model.CameraConstants
import com.id365.idverification.internal.ui.theme.Id365ScannerSdkTheme
import com.id365.idverification.internal.viewmodel.IOddSizeImageCaptureViewModel
import com.id365.idverification.internal.viewmodel.OddSizeImageCaptureViewModel
import com.id365.idverification.internal.views.RoundedRectangleView
import com.id365.idverification.internal.views.ViewFinderMask
import com.id365.idverification.internal.views.microblink.ReticleView

@SuppressLint("SuspiciousIndentation")
@OptIn(ExperimentalAnimationApi::class)
@Composable
internal fun OddSizeImageCaptureOverlayView(
    modifier: Modifier = Modifier,
    model: IOddSizeImageCaptureViewModel,
    opacity: Float,
    captured: Boolean
) {
    val overlayColor: Color = MaterialTheme.colorScheme.inverseSurface.copy(alpha = opacity)
    ViewFinderMask(
        modifier = modifier,
        weight = 0.3F,
        color = overlayColor
    ) {
        val ar = CameraConstants.ID3_CAMERA_FOCUS_AREA_RATIO
        val marginX = CameraConstants.CAMERA_MARGINS.dp
        val marginY = CameraConstants.CAMERA_MARGINS.dp / ar
        val statusBarHeight = with(LocalDensity.current) {WindowInsets.statusBars.getTop(this)}
        Box(modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(ar),
            contentAlignment = Alignment.BottomEnd
        ) {
            RoundedRectangleView(
                modifier = Modifier
                    .fillMaxSize()
                    .align(Alignment.BottomCenter)
                    .onGloballyPositioned {
                        val rect = Rect(
                            topLeft = it.localToRoot(Offset.Zero),
                            bottomRight = it.localToRoot(
                                Offset(
                                    x = it.size.width.toFloat(),
                                    y = it.size.height.toFloat()
                                )
                            )
                        )
                        model.setCaptureArea(rect)
                        model.setStatusBarHeight(statusBarHeight)
                    },
                padding = PaddingValues(horizontal = marginX, vertical = marginY), //horizontal = marginX, vertical = marginY
                color = overlayColor,
            )
            if (!captured) {
                FadeAndScaleOut(
                    modifier = Modifier.fillMaxSize(),
                    visible = true //!didCaptureImage.value
                ) {
                    Box(
                        modifier = Modifier
                            .padding(horizontal = marginX, vertical = marginY)
                    ) {
                        val borderWidth by transition.animateDp(label = "animateDP") {
                            when (it) {
                                EnterExitState.PreEnter -> 8.dp
                                EnterExitState.Visible -> 8.dp
                                EnterExitState.PostExit -> 16.dp
                            }
                        }
                        ReticleView(
                            borderColor = MaterialTheme.colorScheme.surface,
                            strokeWidth = borderWidth
                        )
                    }
                }
            }

        }
    }
}