package com.id365.idverification.internal.views.informationview

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonColors
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.id365.idverification.R
import com.id365.idverification.internal.ui.theme.Id365ScannerSdkTheme

@Composable
internal fun ContinueButton(
    modifier: Modifier = Modifier,
    ctx: Context = LocalContext.current,
    text: String = ctx.getString(R.string._365id_white_information_frontside_title),
    colors: ButtonColors = ButtonDefaults.buttonColors(),
    onClick : () -> Unit = {}
) {
    Button(
        onClick = onClick,
        modifier = modifier
            .height(56.dp)
            .fillMaxWidth(),
        shape = MaterialTheme.shapes.medium,
        colors = colors
    ) {
        Text(text = text,
            style = MaterialTheme.typography.labelLarge
        )
    }
}

@Preview(
    device = "spec:width=1440px,height=3120px,dpi=560,isRound=true"
)
@Composable
private fun ContinueButtonPreview() {
    Id365ScannerSdkTheme {
        Box(modifier = Modifier
            .fillMaxSize()
            .background(color = MaterialTheme.colorScheme.background),
            contentAlignment = Alignment.Center
        ) {
            ContinueButton()
        }
    }
}