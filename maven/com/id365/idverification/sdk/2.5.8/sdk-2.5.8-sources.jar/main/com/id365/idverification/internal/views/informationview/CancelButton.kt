package com.id365.idverification.internal.views.informationview

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import com.id365.idverification.R
import com.id365.idverification.internal.ui.theme.Id365ScannerSdkTheme

@Composable
internal fun CancelButton(
    modifier: Modifier = Modifier,
    ctx: Context = LocalContext.current,
    text: String = ctx.getString(R.string._365id_white_information_cancel),
    onClick : () -> Unit = {}
) {
    ContinueButton(
        modifier = modifier,
        text = text,
        colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.secondaryContainer,
            contentColor = MaterialTheme.colorScheme.onSecondaryContainer
        ),
        onClick = onClick
    )
}

@Preview(
    device = "spec:width=1440px,height=3120px,dpi=560,isRound=true"
)
@Composable
private fun CancelButtonPreview() {
    Id365ScannerSdkTheme {
        Box(modifier = Modifier
            .fillMaxSize()
            .background(color = MaterialTheme.colorScheme.surface),
            contentAlignment = Alignment.Center
        ) {
            CancelButton()
        }
    }
}