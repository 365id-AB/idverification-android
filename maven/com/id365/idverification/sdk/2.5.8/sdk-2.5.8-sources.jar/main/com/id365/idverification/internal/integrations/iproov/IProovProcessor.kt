package com.id365.idverification.internal.integrations.iproov

import android.content.Context
import com.id365.idverification.internal.logging.AppLog
import androidx.compose.runtime.mutableStateOf
import com.id365.idverification.internal.utils.CommonUtils.DebugTAG
import com.id365.idverification.internal.core.IdScannerKoinComponent
import com.id365.idverification.internal.communication.ICommunicator
import com.id365.idverification.internal.communication.SessionToken
import com.id365.idverification.internal.model.ITransactionModel
import com.iproov.sdk.api.IProov
import com.iproov.sdk.api.exception.IProovException
import com.iproov.sdk.api.toLoggable
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.koin.core.component.get
import org.koin.core.component.inject

/**
 * This handles the integration with IProov
 */
internal class IProovProcessor(
    val ctx: Context,
    val transactionId: String,
    val callback: (String, FacematchState) -> Unit,
) : IdScannerKoinComponent() {

    val communicator: ICommunicator by inject()
    val transaction: ITransactionModel by inject()
    private var token: String = ""
    private var success: Boolean = false
    private var remainingAttempts = 3
    private var matchState = FacematchState.UNSET
    private var iProovSession: IProov.Session? = null

    val animate = mutableStateOf(true)
    val showLoading = mutableStateOf(false)

    /**
     * Registers a newly created iproov session with the IProovProcessor
     */
    public fun registerSession(newSession: IProov.Session) {
        iProovSession = newSession

        CoroutineScope(Dispatchers.Default).launch {
            // Will use is on all cases in when statement to make it clear we are checking type
            // and nothing else.
            iProovSession!!.state.collect { state ->
                when(state) {
                    is IProov.State.Starting -> onStarting()
                    is IProov.State.Connecting -> onConnecting()
                    is IProov.State.Connected -> onConnected()
                    is IProov.State.Processing -> onProcessing(state.progress, state.message)
                    is IProov.State.Success -> onSuccess(state.successResult)
                    is IProov.State.Failure -> onFailure(state.failureResult)
                    is IProov.State.Canceled -> onCanceled(state.canceler)
                    is IProov.State.Error -> onError(state.exception)
                }
            }
        }
        iProovSession!!.start()
    }

    /**
     * Sends request to get an IProov token from the IProovService
     */
    private suspend fun enrolUser(): Boolean {
        val request = EnrolUserRequest(transactionId)
        // First step is getting a session token
        val response = communicator.iProovEnrolUser(request)
        token = response.iProovToken
        success = response.success
        return response.success
    }

    /**
     * Sends request to get an IProov token from the IProovService
     */
    private suspend fun getToken(): Boolean {
        val request = IProovTokenRequest(transactionId)
        // First step is getting a session token
        val response = communicator.iProovTokenRequest(request)
        token = response.iProovToken
        success = response.success
        return response.success
    }

    fun retryIProov() {
        AppLog.i(DebugTAG, "Retrying IProov")
        tokenAndCallback { getToken() }
    }

    private fun tokenAndCallback(getaToken: suspend () -> Boolean) {
        CoroutineScope(Dispatchers.IO).launch {
            getaToken()
        }.invokeOnCompletion {
            if (success) {
                matchState = FacematchState.UNSET
                callback.invoke(token, matchState)
            } else {
                // We could not get a token, so request next task instead
                try {
                    transaction.requestNextTask()
                } catch(_: Exception) {
                    // Empty catch handler to handle usecase where user cancels before IProov starts
                }
            }
        }
    }

    init {
        tokenAndCallback { enrolUser() }
    }

    private fun onStarting() {
        AppLog.d(DebugTAG, "onStarting")
    }

    private fun onConnecting() {
        AppLog.d(DebugTAG, "onConnecting")
    }

    private fun onConnected() {
        AppLog.d(DebugTAG, "onConnected")
        showLoading.value = true
    }

    private fun onProcessing(progress: Double, message: String?) {
        AppLog.d(DebugTAG, "OnProcessing: $progress $message")
    }

    private fun onSuccess(result: IProov.SuccessResult) {
        AppLog.i(DebugTAG, "onSuccess")
        onCompletion(ValidateEnrolRequest.IProovSdkReturnStatus.Success)
        showLoading.value = false
    }

    private fun onFailure(result: IProov.FailureResult) {
        AppLog.i(DebugTAG, "onFailure: ${result.toLoggable()}")
        matchState = FacematchState.FAILED
        onCompletion(ValidateEnrolRequest.IProovSdkReturnStatus.Failure)
        if (remainingAttempts > 0)
            callback(token, matchState)
        showLoading.value = false
    }

    private fun onCanceled(canceler: IProov.Canceler) {
        AppLog.i(DebugTAG, "User cancelled the IProov service")
        onCompletion(ValidateEnrolRequest.IProovSdkReturnStatus.Cancelled)
        showLoading.value = false
    }

    private fun onError(exception: IProovException) {
        AppLog.e(DebugTAG, "Error happened during IProov service: ${exception.localizedMessage}")
        matchState = FacematchState.FAILED
        onCompletion(ValidateEnrolRequest.IProovSdkReturnStatus.Error)
        if (remainingAttempts > 0)
            callback(token, matchState)
        showLoading.value = false
    }

    /**
     * When we're done with an IProov Transaction, do this
     */
    private fun onCompletion(status: ValidateEnrolRequest.IProovSdkReturnStatus) {
        when(status){
            // Retry on error or failure
            ValidateEnrolRequest.IProovSdkReturnStatus.Error,
            ValidateEnrolRequest.IProovSdkReturnStatus.Failure -> failed(status)
            ValidateEnrolRequest.IProovSdkReturnStatus.Undefined,
            ValidateEnrolRequest.IProovSdkReturnStatus.Success,
            ValidateEnrolRequest.IProovSdkReturnStatus.Cancelled-> complete(status)
        }
    }

    private fun failed(status: ValidateEnrolRequest.IProovSdkReturnStatus) {
        remainingAttempts -= 1
        AppLog.i(DebugTAG, "Failed to verify identity, remaining attempts: $remainingAttempts")
        if (remainingAttempts <= 0)
            complete(status)
    }

    private fun complete(status: ValidateEnrolRequest.IProovSdkReturnStatus) {
        animate.value = false
        transaction.commsWrapper {
            val request = ValidateEnrolRequest(
                TransactionId = transactionId,
                iProovToken = token,
                VendorId = get<SessionToken>().vendorId,
                Status = status
            )
            val response = communicator.iProovValidateEnrol(request)
            AppLog.i(DebugTAG, "IProov Facematching success: ${response.success}")
        }.invokeOnCompletion {
            transaction.requestNextTask()
        }
    }

    override fun close() {
        super.close()
        iProovSession = null
    }
}
