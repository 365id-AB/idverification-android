package com.id365.idverification.internal.core

import android.app.Application
import android.content.Context
import android.content.Intent
import android.nfc.NfcAdapter
import androidx.lifecycle.MutableLiveData
import com.id365.idverification.DocumentType
import com.id365.idverification.FacematchFeedback
import com.id365.idverification.FacematchSource
import com.id365.idverification.IdVerification
import com.id365.idverification.errors.IdVerificationClientException
import com.id365.idverification.IdVerificationEventHandler
import com.id365.idverification.IdVerificationRequest
import com.id365.idverification.errors.IdVerificationException
import com.id365.idverification.IdVerificationResult
import com.id365.idverification.NfcFeedback
import com.id365.idverification.errors.IdVerificationServerException
import com.id365.idverification.R
import com.id365.idverification.internal.communication.AbortReason
import com.id365.idverification.internal.communication.ICommunicator
import com.id365.idverification.internal.logging.AppLog
import com.id365.idverification.internal.logging.IOtelLogger
import com.id365.idverification.internal.model.ITransactionModel
import com.id365.idverification.internal.utils.CommonUtils.DebugTAG
import com.id365.idverification.internal.utils.VendorId
import com.id365.idverification.internal.viewmodel.INfcViewModel
import io.grpc.StatusException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.koin.android.ext.koin.androidContext
import org.koin.core.Koin
import org.koin.core.KoinApplication
import org.koin.core.error.ClosedScopeException
import org.koin.core.error.InstanceCreationException
import org.koin.core.error.NoBeanDefFoundException
import org.koin.core.parameter.parametersOf
import org.koin.dsl.koinApplication
import java.util.UUID

/**
 * Here we hold the main koin context for 365ID Scanner SDK. It is used throughout the SDK
 * to access the respective dependencies.
 */
internal object SdkContext {
    var sdk: KoinApplication = koinApplication {}
    var nfcViewModel: INfcViewModel? = null
    var mutableSdk: MutableLiveData<KoinApplication?> = MutableLiveData(null)
    var cameraReady = MutableLiveData(LandingPageTransition.START)
    var sessionReady = MutableLiveData(false)
    var customTheme: IdVerification.IdVerificationTheme = IdVerification.IdVerificationTheme()
    var skipModules: List<IdVerification.SkipModule> = emptyList()
    var documentSizeType: IdVerification.DocumentSizeType = IdVerification.DocumentSizeType.DOCUMENT
    var abortJob: Job? = null
    var transactionFinished: Boolean = false
    var encounteredException: Boolean = false
    val transactionModel: ITransactionModel by lazy { sdk.koin.get<ITransactionModel>() }
    private var sdkCoroutineScope: CoroutineScope = CoroutineScope(Dispatchers.Main)

    var eventHandler: IdVerificationEventHandler = object : IdVerificationEventHandler {
        override fun onStarted() {
            // Dummy implementation
        }

        override fun onClosed() {
            // Dummy implementation
        }

        override fun onUserDismissed() {
            // Dummy implementation
        }

        override fun onException(exception: IdVerificationException) {
            // Dummy implementation
        }

        override fun onCompleted(result: IdVerificationResult) {
            // Dummy implementation
        }

        override fun onDocumentFeedback(documentType: DocumentType, countryCode: String) {
            // Dummy implementation
        }

        override fun onNfcFeedback(nfcFeedback: NfcFeedback, expiryDate: String) {
            // Dummy implementation
        }

        override fun onNfcFeedbackWithDataTypes(
            nfcFeedback: NfcFeedback,
            expiryDate: String,
            dataTypes: Int
        ) {
            // Dummy implementation
        }

        override fun onFaceMatchFeedback(faceMatchFeedback: FacematchFeedback) {
            // Dummy implementation
        }

        override fun onFaceMatchFeedbackWithSource(
            faceMatchFeedback: FacematchFeedback,
            faceMatchSource: FacematchSource
        ) {
            // Dummy implementation
        }

        override fun onTransactionCreated(transactionId: String) {
            // Dummy implementation
        }

    }

    internal fun setDocumentSizeType(documentType: DocumentType) {
        when (documentType) {
            DocumentType.Passport,
            DocumentType.DiplomaticPassport,
            DocumentType.EmergencyPassport,
            DocumentType.ServicePassport -> this.documentSizeType = IdVerification.DocumentSizeType.ID3

            DocumentType.DrivingLicense,
            DocumentType.AssociatedDrivingLicense,
            DocumentType.ProvisionalDrivingLicense,
            DocumentType.NationalId,
            DocumentType.PersonalId,
            DocumentType.DiplomaticId,
            DocumentType.MilitaryId,
            DocumentType.OfficialId,
            DocumentType.AssociatedId,
            DocumentType.ResidencePermit,
            DocumentType.TemporaryResidencePermit -> this.documentSizeType = IdVerification.DocumentSizeType.ID1

            DocumentType.TravelDocument,
            DocumentType.TemporaryTravelDocument,
            DocumentType.AuthorizationDocument -> this.documentSizeType = IdVerification.DocumentSizeType.DOCUMENT

            else -> this.documentSizeType = IdVerification.DocumentSizeType.DOCUMENT
        }
        //this.documentSizeType = documentType

    }

    val koin: Koin
        get() = sdk.koin

    private const val PREFS: String = "365iD_SharedPrefs"

    /**
     * With a KoinApplication instance created, we create the persistent singletons early
     */
    private fun createModels(
        ctx: Context,
        koinApp: KoinApplication,
        request: IdVerificationRequest,
    ): Boolean {
        try {
            koinApp.koin.get<ICommunicator>(parameters = {
                parametersOf(
                    VendorId.getVendorId(ctx),
                    request,
                )
            })
            koinApp.koin.get<ITransactionModel>()
            eventHandler.onStarted()
            return true
        } catch (e: StatusException) {
            onException(IdVerificationServerException(exception = e))
        } catch (e: Exception) {
            onException(IdVerificationClientException(exception = e))
        }
        return false
    }

    /**
     * This is for handling overload functions of [IdVerification.start].
     *
     * @param ctx: An ApplicationContext. Should not be an ActivityContext.
     * @param request: A _365iDRequest. Should contain a valid token and a location (Name or ID).
     * @param koinApp: For testing. DO NOT EXPOSE THIS IN PUBLIC FUNCTIONS!
     *
     * @return true if the SDK was initialized successfully, otherwise false.
     */
    internal fun start(
        ctx: Context,
        request: IdVerificationRequest,
        documentSizeType: IdVerification.DocumentSizeType,
        eventHandler: IdVerificationEventHandler,
        skipModules: List<IdVerification.SkipModule> = emptyList(),
        koinApp: KoinApplication = koinApplication {
            // Inject Android Context
            androidContext(ctx)
            modules(appModule, viewModules, nfcTagModules)
        }
    ): Boolean {
        if (isSdkRunning()) {
            onException(IdVerificationClientException(ctx.getString(R.string._365id_sdk_already_running)))
            return false
        }
        if (ctx !is Application) {
            onException(IdVerificationClientException(ctx.getString(R.string._365id_sdk_req_app_context)))
            return false
        }
        if (documentSizeType == IdVerification.DocumentSizeType.ODD) {
            SdkContext.skipModules = listOf(
                IdVerification.SkipModule.FACE_MATCH,
                IdVerification.SkipModule.NFC
            )
        } else {
            SdkContext.skipModules = skipModules
        }
        SdkContext.eventHandler = eventHandler
        SdkContext.documentSizeType = documentSizeType
        AppLog.otelLogger = koinApp.koin.get<IOtelLogger>()
        sdk = koinApp
        mutableSdk.postValue(koinApp)
        cameraReady.postValue(LandingPageTransition.LOGO)

        return createModels(ctx, koinApp, request)
    }

    internal fun stop() {
        if (abortJob == null && !transactionFinished && !encounteredException) {
            AppLog.i(DebugTAG, "Closing SDK")
            sdkCoroutineScope.launch {
                transactionModel.abortTransactionRequest(AbortReason.StopSDKCalled).join()
                closeSdk().join()
                eventHandler.onClosed()
            }
        } else {
            AppLog.i(DebugTAG, "Closing SDK")
            sdkCoroutineScope.launch {
                abortJob?.join()
                closeSdk().join()
                eventHandler.onClosed()
            }
        }
    }

    private fun closeSdk(): Job = transactionModel.commsWrapper {
        sdk.close()
        sdk = koinApplication {}
        mutableSdk.postValue(null)
        cameraReady.postValue(LandingPageTransition.START)
    }

    internal fun onException(exception: IdVerificationException) {
        encounteredException = true
        eventHandler.onException(exception)
    }

    /**
     * Check if SDK is running
     */
    private fun isSdkRunning(): Boolean =
        try {
            koin.get<ITransactionModel>()
            true
        } catch (e: NoBeanDefFoundException) {
            // SDK hasn't run before. SDK can be started.
            false
        } catch (e: ClosedScopeException) {
            // SDK was previously stopped. SDK can be started.
            false
        }

    internal fun sendIntent(
        intent: Intent
    ): Boolean {
        if (!isSdkRunning()) {
            return false
        }
        if (intent.action != NfcAdapter.ACTION_TAG_DISCOVERED) {
            return false
        }

        CoroutineScope(Dispatchers.IO).launch {
            for (i in 1..3) {
                try {
                    AppLog.d(
                        "SdkContext",
                        "Sending intent to sdk: $intent ($i) to ${nfcViewModel?.javaClass?.simpleName}"
                    )
                    nfcViewModel?.handleIntent(intent)

                    return@launch
                } catch (e: InstanceCreationException) {
                    AppLog.e(
                        "SdkContext",
                        "${INfcViewModel::class.java.simpleName} not ready yet, trying again... ($i)"
                    )
                    delay(1000)
                } catch (e: Exception) {
                    AppLog.e(
                        SdkContext.DebugTAG,
                        "Unable to send intent to sdk: $e"
                    )
                }
            }
        }
        return true
    }

    // Function to override scope for testing purposes
    fun setTestScope(scope: CoroutineScope) {
        sdkCoroutineScope = scope
    }
}