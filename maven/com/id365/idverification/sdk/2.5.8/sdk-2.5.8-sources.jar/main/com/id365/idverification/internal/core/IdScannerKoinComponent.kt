package com.id365.idverification.internal.core

import org.koin.core.Koin
import org.koin.core.component.KoinComponent
import java.io.Closeable

/**
 * All components in SDK that use DI should inherit from this class to get the correct context for their dependencies.
 *
 * Once inherited, the class can simply do `model: ISomeModel = koin.get()` to receive a reference to that type
 * of model from our KoinApplication instance.
 */
abstract class IdScannerKoinComponent: KoinComponent, Closeable {
    override fun getKoin(): Koin = SdkContext.koin

    private var closed: Boolean = false
    override fun close() {
        closed = true
    }
}