package com.id365.idverification.internal.integrations.iproov

class IProovTokenRequest(
    val transactionId: String = ""
)