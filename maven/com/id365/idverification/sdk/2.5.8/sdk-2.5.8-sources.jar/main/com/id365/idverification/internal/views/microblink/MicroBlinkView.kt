package com.id365.idverification.internal.views.microblink

import CameraOverlayView
import android.content.Context
import android.view.ViewGroup
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.LifecycleOwner
import com.id365.idverification.IdVerification
import com.id365.idverification.internal.communication.Task
import com.id365.idverification.internal.core.LandingPageTransition
import com.id365.idverification.internal.core.SdkContext
import com.id365.idverification.internal.core.SdkContext.sdk
import com.id365.idverification.internal.logging.AppLog
import com.id365.idverification.internal.ui.theme.Id365ScannerSdkTheme
import com.id365.idverification.internal.utils.WithPermission
import com.id365.idverification.internal.viewmodel.IMicroBlinkViewModel
import com.id365.idverification.internal.views.MissingCameraPermissionView
import kotlinx.coroutines.launch
import org.koin.core.parameter.parametersOf

@Composable
internal fun MicroBlinkView(
    context: Context = LocalContext.current,
    lifecycleOwner: LifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current,
    model: IMicroBlinkViewModel? = try {
        sdk.koin.get(parameters = {
            parametersOf(
                context,
                lifecycleOwner
            )
        })
    } catch(e: Exception) {
        AppLog.e("MicroBlinkView", "Unexpected exception when showing microblink view", e)
        null
    }
) {
    model?.let {
        WithPermission(
            onDenied = @Composable { request ->
                SdkContext.cameraReady.postValue(LandingPageTransition.READY)
                MissingCameraPermissionView(request)
            }
        ) {
            MicroBlinkCameraView(model)
            Box(modifier = Modifier
                .fillMaxSize()
            ) {
                CameraOverlayView(model=model)
            }
        }
    }
}

@Composable
private fun MicroBlinkCameraView(model: IMicroBlinkViewModel) {
    val coroutineScope = rememberCoroutineScope()
    AndroidView(
        modifier = Modifier,
        factory = { context ->
            val previewView = PreviewView(context).apply {
                this.scaleType = scaleType
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            }
            coroutineScope.launch {
                model.startMicroBlinkSdk(previewView)
            }
            previewView
        }
    )
}

@Preview(showBackground = false)
@Composable
private fun  MicroBlinkViewPreview() {
    var show by remember { mutableStateOf(true) }
    val model by remember { mutableStateOf(object : IMicroBlinkViewModel {
        override fun startMicroBlinkSdk(previewView: PreviewView) {}
        override fun getDocumentSizeType() = IdVerification.DocumentSizeType.DOCUMENT
        override val didCaptureImage = mutableStateOf(false)
        override val warningStatusMessage = mutableStateOf<String?>("You are holding it wrong")
        override val warningStatus = mutableStateOf(true)
        override val taskData = mutableStateOf(Task())
        override val playAnimation = mutableStateOf(true)
        override val infoText = mutableStateOf("Frontside text")
        override val buttonCb: () -> Unit = {}
        override val buttonLabel = "OK"
        override val buttonEnabled = mutableStateOf(true)

        override fun close() {}
    })}
    Id365ScannerSdkTheme(darkTheme = false) {
        Column {
            if (show) {
                MicroBlinkView(model=model)
            }
        }
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.BottomEnd) {
            Button(
                onClick = {
                    show = !show
                    model.didCaptureImage.value = false
                }
            ) {
                Text("Show/Hide")
            }
        }
    }
}