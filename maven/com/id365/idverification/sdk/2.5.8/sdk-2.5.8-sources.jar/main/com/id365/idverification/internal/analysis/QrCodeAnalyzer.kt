package com.id365.idverification.internal.analysis

import android.util.Size
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.barcode.BarcodeScanner
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.id365.idverification.internal.core.IdScannerKoinComponent
import com.id365.idverification.internal.dida.DidaProcessor
import com.id365.idverification.internal.model.CameraUtils.inside
import com.id365.idverification.internal.model.CameraUtils.rotate
import com.id365.idverification.internal.model.CameraUtils.scaleToFit
import com.id365.idverification.internal.model.ICameraModel
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import org.koin.core.component.inject

/**
 *  Looks for and detects QR codes. Sends QR codes to DidaProcessor for processing
 */
internal class QrCodeAnalyzer(
    private val model: ICameraModel?,
    private val deviceResolution: Size,
    private val dispatcher: CoroutineDispatcher = Dispatchers.Default,
): ImageAnalysis.Analyzer, IdScannerKoinComponent() {

    private val options = BarcodeScannerOptions.Builder()
        .enableAllPotentialBarcodes()
        .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
        .build()

    private val scanner : BarcodeScanner = BarcodeScanning.getClient(options)

    private val processor: DidaProcessor by inject()

    private val detectionSemaphore = Semaphore(1)

    private fun Semaphore.tryAcquireAndRun(imageProxy: ImageProxy, block: suspend () -> Unit) {
        if (tryAcquire()) {
            CoroutineScope(dispatcher).launch {
                block.invoke()
                imageProxy.close()
                release()
            }
        } else {
            imageProxy.close()
        }
    }

    @androidx.annotation.OptIn(androidx.camera.core.ExperimentalGetImage::class)
    override fun analyze(image: ImageProxy) = detectionSemaphore.tryAcquireAndRun(image) {
        model?.let {
            val input = InputImage.fromMediaImage(image.image!!, image.imageInfo.rotationDegrees)

            val viewFinder = model.regionOfInterest
            scanner.process(input).addOnSuccessListener { barcodes ->
                if (barcodes.size == 0) return@addOnSuccessListener
                barcodes.firstOrNull { it.boundingBox?.rotate()?.inside(viewFinder) == true }
                    ?.let { barcode ->
                        if (barcode.boundingBox?.rotate()?.inside(viewFinder) == true) {
                            updateDebug(barcode)
                            processor.process(barcode)
                        }
                    }
            }
        }
    }

    /**
     * To visualize the area where a QR code was detected, enable this function
     */
    private fun updateDebug(barcode: Barcode) {
        if (false) {
            // if (BuildConfig.DEBUG) {
            barcode.boundingBox?.let { box ->
                val capture = model?.cameraCaptureSize?.rotate()
                val root = model?.rootView
                val scaled = box.rotate().scaleToFit(capture, root)
            }
        }
    }

    companion object {
        const val DebugTAG = "QrCodeDetector"
    }
}