package com.id365.idverification

import androidx.annotation.Keep
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json

/**
 * When starting the SDK an object of this class needs to be supplied with a valid 365id token.
 *
 * @property token An active 365ID App Token.
 */
@Keep
@Serializable
data class IdVerificationRequest(
    @SerialName("Token") val token: String
) {
    @SerialName("LocationName") internal val locationName: String = ""
    @SerialName("LocationId") internal val locationId: Int = 0

    @Keep
    internal companion object {
        private val json: Json by lazy {
            Json {
                ignoreUnknownKeys = true
            }
        }
        internal fun fromJson(string: String): IdVerificationRequest =
            json.decodeFromString(string)
    }
}
