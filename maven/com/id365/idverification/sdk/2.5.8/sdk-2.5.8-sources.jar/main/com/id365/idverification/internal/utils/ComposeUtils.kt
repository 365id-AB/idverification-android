package com.id365.idverification.internal.utils

import android.Manifest
import android.content.pm.ActivityInfo
import android.util.Log
import androidx.activity.compose.ManagedActivityResultLauncher
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.MutableLiveData
import com.id365.idverification.internal.core.SdkContext.koin
import com.id365.idverification.internal.viewmodel.IPermissionsViewModel
import com.id365.idverification.internal.viewmodel.PermissionsViewModel


/**
 * Helper function to help improve readability when using
 * MutableLiveData<Boolean> inside composable functions
 */
@Composable
internal fun <T> observe(
    data: MutableLiveData<T>?,
    initial: T
): T {
    return data?.observeAsState(initial)?.value ?: initial
}


/**
 * Checks if we have permission to use camera and renders different views based on the result
 *
 * @onDenied: A @Composable that will be drawn when permission haven't yet been granted
 * @content: The @Composable to be drawn when permission is granted
 */
@Composable
internal fun WithPermission(
    model: IPermissionsViewModel? = try { koin.get() } catch(_: Exception) { null },
    onDenied: @Composable (requester: () -> Unit) -> Unit = {},
    content: @Composable () -> Unit,
) {
    val permissionGranted = model?.cameraPermission

    if (permissionGranted?.value == true) {
        content.invoke()
    } else {
        val launcher: ManagedActivityResultLauncher<String, Boolean> =
            rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
                permissionGranted?.value = it
            }
        onDenied {
            if (permissionGranted?.value == false) launcher.launch(Manifest.permission.CAMERA)
        }
    }
}

@Composable
internal fun LockScreenOrientation() {
    val context = LocalContext.current
    DisposableEffect(key1 = Unit, effect = {
        val activity = context.getActivity() ?: return@DisposableEffect onDispose {}
        val orientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        Log.d("LockScreenOrientation", "Locking orientation to $orientation")
        val originalOrientation = activity.requestedOrientation
        activity.requestedOrientation = orientation
        onDispose {
            Log.d("LockScreenOrientation", "Restoring orientation to $originalOrientation")
            activity.requestedOrientation = originalOrientation
        }
    })
}
