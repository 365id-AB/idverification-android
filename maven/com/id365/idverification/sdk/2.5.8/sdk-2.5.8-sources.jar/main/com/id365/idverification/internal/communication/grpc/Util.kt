package com.id365.idverification.internal.communication.grpc

import com.google.protobuf.kotlin.toByteString
import com.id365.idverification.DocumentType
import com.id365.idverification.FacematchFeedback
import com.id365.idverification.FacematchSource
import com.id365.idverification.IdVerification
import com.id365.idverification.internal.communication.DeviceInformation
import com.id365.idverification.internal.communication.Task
import com.id365.idverification.internal.communication.UserMessage
import com.id365.idverification.contracts.grpc.coordinator.CoordinatorOuterClass
import com.id365.idverification.contracts.grpc.coordinator.CoordinatorOuterClass.Reason
import com.id365.idverification.contracts.grpc.coordinator.feedback.FeedbackOuterClass
import com.id365.idverification.contracts.grpc.coordinator.feedback.documenttype.FeedbackDocumentType
import com.id365.idverification.contracts.grpc.coordinator.feedback.facematch.FeedbackFaceMatch.FaceMatchStatusEnum
import com.id365.idverification.contracts.grpc.coordinator.feedback.facematch.FeedbackFaceMatch.FaceMatchSourceEnum
import com.id365.idverification.contracts.grpc.coordinator.feedback.nfc.FeedbackNFC.NfcStatusEnum
import com.id365.idverification.contracts.grpc.coordinator.feedback.nfc.FeedbackNFC.NfcDataTypesEnum
import com.id365.idverification.contracts.grpc.coordinator.message.UserMessageOuterClass
import com.id365.idverification.contracts.grpc.coordinator.task.CoordinatorTask.CoordinatorTaskEnum
import com.id365.idverification.contracts.grpc.digitalidentification.DigitalIdentificationOuterClass
import com.id365.idverification.contracts.grpc.documentSizeType.DocumentSizeType.DocumentSizeTypeEnum
import com.id365.idverification.contracts.grpc.nfc.NfcOuterClass
import com.id365.idverification.contracts.grpc.nfc.NfcOuterClass.NfcSkipReason
import com.id365.idverification.contracts.grpc.nfc.processRequest
import com.id365.idverification.contracts.grpc.iproov.IProov
import com.id365.idverification.contracts.grpc.iproov.validateEnrolRequest
import com.id365.idverification.contracts.grpc.session.infromation.DeviceInformationOuterClass
import com.id365.idverification.contracts.grpc.session.infromation.deviceInformation
import com.id365.idverification.contracts.grpc.session.module.Module
import com.id365.idverification.internal.communication.AbortReason
import com.id365.idverification.internal.communication.Feedback
import com.id365.idverification.internal.dida.DidaProviderSignature
import com.id365.idverification.internal.dida.DidaResponse
import com.id365.idverification.internal.dida.DidaStatus
import com.id365.idverification.internal.integrations.iproov.ValidateEnrolRequest.IProovSdkReturnStatus
import com.id365.idverification.internal.integrations.iproov.EnrolUserResponse
import com.id365.idverification.internal.integrations.iproov.IProovTokenResponse
import com.id365.idverification.internal.integrations.iproov.ValidateEnrolRequest
import com.id365.idverification.internal.nfc.ChipRequest
import com.id365.idverification.internal.nfc.ProcessRequest
import com.id365.idverification.internal.nfc.ProcessResponse
import com.id365.idverification.internal.nfc.SkipReason

/**
 * Helper function to convert the gRPC-defined Task type to
 * the generic Task defined in commonMain
 */
internal fun Task(
    task: CoordinatorOuterClass.NextTaskReply,
): Task = Task(
    state = task.state,
    message = userMessage(task.message),
    nextTask = task.nextTask.fromGrpc(),
    taskPayload = task.taskPayload,
    clientPayload = task.clientPayload,
    taskCountCurrent = task.taskCountCurrent,
    taskCountEstimate = task.taskCountEstimate,
    feedback = task.feedback.fromGrpc(),
)

/**
 * Helper function to convert the gRPC-defined DocumentFeedback type to
 * the generic Task defined in commonMain
 */
internal fun FeedbackDocumentType.DocumentTypeEnum.fromGrpc(): DocumentType = when(this) {
    FeedbackDocumentType.DocumentTypeEnum.UNRECOGNIZED,
    FeedbackDocumentType.DocumentTypeEnum.UNDEFINED -> DocumentType.Undefined
    FeedbackDocumentType.DocumentTypeEnum.PASSPORT -> DocumentType.Passport
    FeedbackDocumentType.DocumentTypeEnum.DIPLOMATIC_PASSPORT -> DocumentType.DiplomaticPassport
    FeedbackDocumentType.DocumentTypeEnum.EMERGENCY_PASSPORT -> DocumentType.EmergencyPassport
    FeedbackDocumentType.DocumentTypeEnum.SERVICE_PASSPORT -> DocumentType.ServicePassport
    FeedbackDocumentType.DocumentTypeEnum.DRIVING_LICENSE -> DocumentType.DrivingLicense
    FeedbackDocumentType.DocumentTypeEnum.ASSOCIATED_DRIVING_LICENSE -> DocumentType.AssociatedDrivingLicense
    FeedbackDocumentType.DocumentTypeEnum.PROVISIONAL_DRIVING_LICENSE -> DocumentType.ProvisionalDrivingLicense
    FeedbackDocumentType.DocumentTypeEnum.TRAVEL_DOCUMENT -> DocumentType.TravelDocument
    FeedbackDocumentType.DocumentTypeEnum.TEMPORARY_TRAVEL_DOCUMENT -> DocumentType.TemporaryTravelDocument
    FeedbackDocumentType.DocumentTypeEnum.NATIONAL_ID -> DocumentType.NationalId
    FeedbackDocumentType.DocumentTypeEnum.PERSONAL_ID -> DocumentType.PersonalId
    FeedbackDocumentType.DocumentTypeEnum.DIPLOMATIC_ID -> DocumentType.DiplomaticId
    FeedbackDocumentType.DocumentTypeEnum.MILITARY_ID -> DocumentType.MilitaryId
    FeedbackDocumentType.DocumentTypeEnum.OFFICIAL_ID -> DocumentType.OfficialId
    FeedbackDocumentType.DocumentTypeEnum.ASSOCIATED_ID -> DocumentType.AssociatedId
    FeedbackDocumentType.DocumentTypeEnum.RESIDENCE_PERMIT -> DocumentType.ResidencePermit
    FeedbackDocumentType.DocumentTypeEnum.TEMPORARY_RESIDENCE_PERMIT -> DocumentType.TemporaryResidencePermit
    FeedbackDocumentType.DocumentTypeEnum.AUTHORISATION_DOCUMENT -> DocumentType.AuthorizationDocument
    FeedbackDocumentType.DocumentTypeEnum.DIGITAL_ID -> DocumentType.DigitalId
    FeedbackDocumentType.DocumentTypeEnum.UNKNOWN -> DocumentType.Unknown
}

internal fun FeedbackOuterClass.Feedback.fromGrpc(): Feedback =
    Feedback(
        documentFeedback = documentFeedBack.fromGrpc(),
        nfcFeedback = nfcFeedBack.fromGrpc(),
        facematchFeedback = faceMatchFeedback.fromGrpc()
    )


internal fun FeedbackOuterClass.FaceMatchFeedback.fromGrpc(): Feedback.FaceMatchFeedback =
    Feedback.FaceMatchFeedback(
        faceMatchStatus.fromGrpc(),
        faceMatchSource.fromGrpc()
    )


internal fun FeedbackOuterClass.DocumentFeedback.fromGrpc(): Feedback.DocumentFeedback =
    Feedback.DocumentFeedback(
        country = country,
        documentType = documentType.fromGrpc()
    )

internal fun FeedbackOuterClass.NfcFeedback.fromGrpc(): Feedback.NfcFeedback =
    Feedback.NfcFeedback(
        expiryDate = expiryDate,
        nfcFeedback = nfcStatus.fromGrpc(),
        dataTypes = dataTypesList.fromGrpc()
    )

internal fun CoordinatorTaskEnum.fromGrpc(): Task.Level = when(this) {
    CoordinatorTaskEnum.UNRECOGNIZED,
    CoordinatorTaskEnum.UNDEFINED -> Task.Level.UNDEFINED
    CoordinatorTaskEnum.WAIT -> Task.Level.WAIT
    CoordinatorTaskEnum.FRONT_SIDE -> Task.Level.FRONT_SIDE
    CoordinatorTaskEnum.BACK_SIDE -> Task.Level.BACK_SIDE
    CoordinatorTaskEnum.NFC -> Task.Level.NFC
    CoordinatorTaskEnum.FINISHED_SUCCESSFULLY -> Task.Level.FINISHED_SUCCESSFULLY
    CoordinatorTaskEnum.FINISHED_BUT_FAILED -> Task.Level.FINISHED_BUT_FAILED
    CoordinatorTaskEnum.IPROOV -> Task.Level.IPROOV
    CoordinatorTaskEnum.NO_ACTIVE_PACKAGE -> Task.Level.NO_ACTIVE_PACKAGE
    CoordinatorTaskEnum.INVALID_VERSION -> Task.Level.INVALID_VERSION
    CoordinatorTaskEnum.WAIT_DOCUMENT -> Task.Level.WAIT_DOCUMENT
    CoordinatorTaskEnum.WAIT_NFC -> Task.Level.WAIT_NFC
    CoordinatorTaskEnum.WAIT_IPROOV -> Task.Level.WAIT_IPROOV
    CoordinatorTaskEnum.ODD_SIZE_IMAGE_CAPTURE -> Task.Level.ODD_SIZE_IMAGE_CAPTURE
}

internal fun NfcStatusEnum.fromGrpc(): com.id365.idverification.NfcFeedback = when(this) {
    NfcStatusEnum.UNRECOGNIZED,
    NfcStatusEnum.UNDEFINED -> com.id365.idverification.NfcFeedback.Undefined
    NfcStatusEnum.COMPLETED -> com.id365.idverification.NfcFeedback.Completed
    NfcStatusEnum.FAILED -> com.id365.idverification.NfcFeedback.Failed
    NfcStatusEnum.NFC_ABORTED -> com.id365.idverification.NfcFeedback.Aborted
}

/** A helper function to convert from the gRPC representation into the SDK API feedback format. */
internal fun List<NfcDataTypesEnum>.fromGrpc(): Int {

    /* an empty result is created to store the flags during the iteration operation */
    var result = com.id365.idverification.NfcDataTypeFlags.NONE

    for (type in this) {
        /* each data type is added to the final result */
        val mapped = when (type) {
            NfcDataTypesEnum.MRZ -> com.id365.idverification.NfcDataTypeFlags.MRZ
            NfcDataTypesEnum.SIGNATURE -> com.id365.idverification.NfcDataTypeFlags.SIGNATURE
            NfcDataTypesEnum.PORTRAIT -> com.id365.idverification.NfcDataTypeFlags.PORTRAIT
            NfcDataTypesEnum.UNRECOGNIZED -> continue
        }

        /* the result is or:ed with the result i.e. appended to the result */
        result = result.or(mapped)
    }

    return result
}

internal fun FaceMatchStatusEnum.fromGrpc(): FacematchFeedback = when(this) {
    FaceMatchStatusEnum.UNRECOGNIZED,
    FaceMatchStatusEnum.UNDEFINED -> FacematchFeedback.Undefined
    FaceMatchStatusEnum.MATCHED -> FacematchFeedback.Matched
    FaceMatchStatusEnum.NOT_MATCHED -> FacematchFeedback.NoMatch
    FaceMatchStatusEnum.FACE_MATCH_ABORTED -> FacematchFeedback.Aborted
}

internal fun FaceMatchSourceEnum.fromGrpc(): FacematchSource = when(this) {
    FaceMatchSourceEnum.NFC_IMAGE -> FacematchSource.Nfc
    FaceMatchSourceEnum.DOCUMENT_IMAGE -> FacematchSource.Document
    FaceMatchSourceEnum.NONE -> FacematchSource.None
    FaceMatchSourceEnum.UNRECOGNIZED -> FacematchSource.Undefined
}

/**
 * Helper function to convert the gRPC-defined UserMessage type to
 * the generic Task defined in commonMain
 */
internal fun userMessage(
    message: UserMessageOuterClass.UserMessage
): UserMessage = UserMessage(
    title = message.title,
    subtitle = message.text,
    level = message.typeOfMessage.toString()
)

/**
 * Helper function to convert internal data type to protobuf
 */
internal fun deviceInformation(
    deviceInfo: DeviceInformation,
) : DeviceInformationOuterClass.DeviceInformation =
    deviceInformation{
        model = deviceInfo.model
        cameraResolution = deviceInfo.cameraResolution
        displayResolution = deviceInfo.displayResolution
        manufacturer = deviceInfo.manufacturer
        sdkVersion = deviceInfo.sdkVersion
        osVersion = deviceInfo.osVersion
        platform = deviceInfo.platform
        nfcAvailable = deviceInfo.nfcAvailable
}

/**
 * Helper function to convert a ProcessResponse protobuf to our internal datatype
 */
internal fun ProcessResponse(other: NfcOuterClass.ProcessResponse): ProcessResponse =
    ProcessResponse(
        state = other.state,
        requests = other.requestsList.map { ChipRequest(it) },
        isCompleted = other.isCompleted,
        status = other.status,
        progressPercent = other.progressPercent
    )


/**
 * Helper function to convert a ChipRequest protobuf to our internal datatype
 */
internal fun ChipRequest(other: NfcOuterClass.ChipRequest): ChipRequest = ChipRequest(
    apdu = other.apdu.toByteArray(),
    sw1 = other.sw1.toUByte(),
    sw2 = other.sw2.toUByte(),
)

internal fun didaResponse(other: DigitalIdentificationOuterClass.DidaResponse): DidaResponse = DidaResponse(
    assessmentStatus = when(other.assessmentStatus) {
        DigitalIdentificationOuterClass.Status.Incompatible -> DidaStatus.Incompatible
        DigitalIdentificationOuterClass.Status.MultipleCompatible -> DidaStatus.MultipleCompatible
        DigitalIdentificationOuterClass.Status.Processing -> DidaStatus.Processing
        DigitalIdentificationOuterClass.Status.UNRECOGNIZED -> DidaStatus.UNKNOWN
        else -> DidaStatus.UNKNOWN
    },
    compatibleProviders = other.compatibleProvidersList.map {
        DidaProviderSignature(
            ProviderId = it.providerId,
            ProviderName = it.providerName,
        )
    }
)

/**
 * Helper function describing how to create a processRequest from internal datatype
 * TODO: Add processRequest.extendedApduSupported to the request
 */
internal fun processRequest(request: ProcessRequest): NfcOuterClass.ProcessRequest =
    processRequest {
        state = request.state
        chipStandard = request.chipStandard
        responses.addAll(request.responses.map { it.toByteArray().toByteString() })
        skip = request.skipReason.toGrpc()
    }

/**
 * Converts internal nfc skip reason enum to GRPC representation
 */
internal fun SkipReason.toGrpc(): NfcSkipReason = when(this) {
    SkipReason.Undefined -> NfcSkipReason.Undefined
    SkipReason.UserSkipped -> NfcSkipReason.UserSkipped
    SkipReason.NfcNotSupported -> NfcSkipReason.NfcNotSupported
}

/**
 * Converts internal abort reason enum to GRPC representation
 */
internal fun AbortReason.toGrpc(): Reason = when(this) {
    AbortReason.Undefined -> Reason.Undefined
    AbortReason.UserCancelled -> Reason.UserCancelled
    AbortReason.StopSDKCalled -> Reason.StopSDKCalled
}

/**
 * Converts internal document size type enum to GRPC representation
 */
internal fun IdVerification.DocumentSizeType.toGrpcDocumentSizeTypeEnum(): DocumentSizeTypeEnum {
    return when(this) {
        IdVerification.DocumentSizeType.DOCUMENT -> DocumentSizeTypeEnum.DOCUMENT
        IdVerification.DocumentSizeType.ID1 -> DocumentSizeTypeEnum.ID1
        IdVerification.DocumentSizeType.ID3 -> DocumentSizeTypeEnum.ID3
        IdVerification.DocumentSizeType.ODD -> DocumentSizeTypeEnum.ODD
    }
}
/**
 * Translates a [IProov.EnrolUserResponse] to SDK internal [EnrolUserResponse]
 */
internal fun EnrolUserResponse(other: IProov.EnrolUserResponse): EnrolUserResponse =
    EnrolUserResponse(
        success = other.success,
        iProovToken = other.iProovToken,
    )

/**
 * Translates an SDK internal [ValidateEnrolRequest]
 * into the grpc equivalent [IProov.ValidateEnrolRequest]
 */
internal fun validateEnrolRequest(other: ValidateEnrolRequest): IProov.ValidateEnrolRequest =
    validateEnrolRequest {
        this.transactionId = other.TransactionId
        this.vendorId = other.VendorId
        this.status = when(other.Status) {
            IProovSdkReturnStatus.Undefined -> IProov.iProovSdkReturnStatus.Undefined
            IProovSdkReturnStatus.Success -> IProov.iProovSdkReturnStatus.Success
            IProovSdkReturnStatus.Failure -> IProov.iProovSdkReturnStatus.Failure
            IProovSdkReturnStatus.Cancelled -> IProov.iProovSdkReturnStatus.Cancelled
            IProovSdkReturnStatus.Error -> IProov.iProovSdkReturnStatus.Error
        }
        this.iProovToken = other.iProovToken
    }

/**
 * Translates a grpc [IProov.TokenResponse] to SDK internal [IProovTokenResponse]
 */
internal fun iProovTokenResponse(other: IProov.TokenResponse): IProovTokenResponse =
    IProovTokenResponse(
        success = other.success,
        iProovToken = other.iProovToken
    )

/** Change public modulesToSkip enum to grpc enum type and return it. */
internal fun List<IdVerification.SkipModule>.getModulesToSkipForGrpc(): MutableList<Module.ModuleEnum> {
    val grpcModulesToSkip: MutableList<Module.ModuleEnum> = mutableListOf()
    for(moduleToSkip in this) {
        val grpcModuleToSkip = when(moduleToSkip) {
            IdVerification.SkipModule.NFC -> Module.ModuleEnum.NFC
            IdVerification.SkipModule.FACE_MATCH -> Module.ModuleEnum.IPROOV
        }
        if (!grpcModulesToSkip.contains(grpcModuleToSkip)) {
            grpcModulesToSkip.add(grpcModuleToSkip)
        }
    }
    return grpcModulesToSkip
}