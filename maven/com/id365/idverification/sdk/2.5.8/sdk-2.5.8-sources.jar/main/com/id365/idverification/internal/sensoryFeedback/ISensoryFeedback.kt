package com.id365.idverification.internal.sensoryFeedback

import android.content.Context

/**
 * Describes the interface of our Sensory Feedback.
 */
internal interface ISensoryFeedback {

    /** This function plays the custom shutter sound using the STREAM_SYSTEM volume setting. */
    fun playShutterSound(context: Context)

    /** Tell the device to vibrate */
    fun vibrate(context: Context)
}