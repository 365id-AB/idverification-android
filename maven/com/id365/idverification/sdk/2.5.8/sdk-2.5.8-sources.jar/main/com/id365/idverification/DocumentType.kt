package com.id365.idverification

import androidx.annotation.Keep

/**
 * Enumeration of different document types
 */
@Keep
enum class DocumentType {
    Undefined,
    Passport,
    DiplomaticPassport,
    EmergencyPassport,
    ServicePassport,
    DrivingLicense,
    AssociatedDrivingLicense,
    ProvisionalDrivingLicense,
    TravelDocument,
    TemporaryTravelDocument,
    NationalId,
    PersonalId,
    DiplomaticId,
    MilitaryId,
    OfficialId,
    AssociatedId,
    ResidencePermit,
    TemporaryResidencePermit,
    AuthorizationDocument,
    DigitalId,
    Unknown
}