package com.id365.idverification.internal.integrations.microblink

import android.util.Size

internal enum class MicroBlinkCameraResolution(val width: Int, val height: Int) {
    RESOLUTION_1080P(1920, 1080),
    RESOLUTION_2160P(3840, 2160);

    fun toTargetResolution(isPortrait: Boolean): Size =
        if (isPortrait) {
            Size(height, width)
        } else {
            Size(width, height)
        }
}