package com.id365.idverification.internal.viewmodel

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.util.Log
import androidx.compose.ui.geometry.Rect
import android.util.Size
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.id365.idverification.errors.IdVerificationClientException
import com.id365.idverification.internal.communication.AbortReason
import com.id365.idverification.internal.core.IdScannerKoinComponent
import com.id365.idverification.internal.core.LandingPageTransition
import com.id365.idverification.internal.core.SdkContext
import com.id365.idverification.internal.model.CameraUtils
import com.id365.idverification.internal.model.ITransactionModel
import com.id365.idverification.internal.sensoryFeedback.SensoryFeedback
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.koin.core.component.inject
import java.util.concurrent.ExecutorService

internal class OddSizeImageCaptureViewModel (
    val context: Context,
    val lifecycleOwner: LifecycleOwner,
    private val sensoryFeedback: SensoryFeedback = SensoryFeedback()
) : IOddSizeImageCaptureViewModel, IdScannerKoinComponent() {
    private val transactionModel: ITransactionModel by inject()
    private var cameraExecutor: ExecutorService? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private var imageCapture: ImageCapture? = null
    private val deviceResolution: Size = CameraUtils.getDeviceResolution(context)

    @ExperimentalCamera2Interop
    override fun startCamera(previewView: PreviewView) {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()
            previewView.post {
                try {
                    val cameraSelector = CameraSelector.Builder()
                        .requireLensFacing(CameraSelector.LENS_FACING_BACK)
                        .build()
                    // Configure Preview use case
                    val preview = Preview.Builder()
                        .build().also {
                            it.setSurfaceProvider(previewView.surfaceProvider)
                        }

                    // Configure ImageCapture use case
                    val imageCaptureConfig = ImageCapture.Builder()
                        .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                        .build()

                    imageCapture = imageCaptureConfig

                    cameraProvider?.unbindAll()
                    cameraProvider?.bindToLifecycle(
                        lifecycleOwner,
                        cameraSelector,
                        imageCapture,
                        preview
                    )

                    // Camera is ready
                    SdkContext.cameraReady.postValue(LandingPageTransition.READY)
                } catch (e: Exception) {
                    // Handle camera initialization error
                    transactionModel.handleError(IdVerificationClientException("Failed to start camera", e))
                }
            }
            this.cameraProvider = cameraProvider
            Log.d("OddSizeImageCaptureViewModel", "Camera started successfully.")
        }, ContextCompat.getMainExecutor(context))
    }
    override fun close() {
        stopCamera()
    }
    override fun stopCamera() {
        CoroutineScope(Dispatchers.Main).launch {
            try {
                // Unbind all use cases to stop the camera
                cameraProvider?.unbindAll()
                // Shutdown the executor to release resources
                cameraExecutor?.shutdown()
                // Release other camera-related resources
                cameraProvider = null
                cameraExecutor = null

                Log.d("OddSizeImageCaptureViewModel", "Camera stopped successfully.")
            } catch (e: Exception) {
                // Handle any exceptions during stopping the camera
                transactionModel.handleError(IdVerificationClientException("Failed to stop camera", e))
                Log.e("OddSizeImageCaptureViewModel", "Failed to stop camera", e)
            }
        }
    }

    override fun buttonCb() {
        CoroutineScope(Dispatchers.Main).launch {
            transactionModel.abortTransactionRequest(AbortReason.UserCancelled).join()
            SdkContext.eventHandler.onUserDismissed()
            close()
        }
    }
    // Function to capture an image
    override fun captureImage(callback: (Bitmap) -> Unit) {
        val imageCapture = imageCapture ?: run {
            return transactionModel.handleError(IdVerificationClientException("Image capture use case is null."))
        }
        imageCapture.takePicture(ContextCompat.getMainExecutor(context), object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                super.onCaptureSuccess(image)

                // Play shutter sound and vibrate the device
                sensoryFeedback.playShutterSound(context)
                sensoryFeedback.vibrate(context)

                val bitmap = image.toBitmap()
                val rotatedBitmap = rotateBitmap(bitmap, image.imageInfo.rotationDegrees.toFloat())
                callback(rotatedBitmap)
                image.close()
                stopCamera()
            }
        })
    }
    private var captureArea: Rect? = null
    private var statusBarHeight: Int? = null
    override fun acceptImage(bitmap: Bitmap) {

        captureArea?.let { rect ->

            val adjustedRect = android.graphics.Rect(rect.left.toInt(), rect.top.toInt(), rect.right.toInt(), rect.bottom.toInt())
            val imageSize = Size(bitmap.width, bitmap.height)
            val rootSize = Size(deviceResolution.width, deviceResolution.height)
            val imageToCrop = CameraUtils.calculateCropImage(imageSize, rootSize, adjustedRect)


            val statusBarOffset = statusBarHeight ?: 0

            val croppedBitmap = Bitmap.createBitmap(
                bitmap,
                imageToCrop.left,
                imageToCrop.top - statusBarOffset,
                imageToCrop.width(),
                imageToCrop.height()
            )
            transactionModel.takePicture(croppedBitmap, bitmap, null, null, true, true)
        }

    }
    override fun setCaptureArea(rect: Rect) {
        captureArea = rect
    }

    override fun setStatusBarHeight(height: Int) {
        statusBarHeight = height
    }

    override fun rotateBitmap(bitmap: Bitmap, degrees: Float): Bitmap {
        val matrix = Matrix().apply { postRotate(degrees) }
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }
}