package com.id365.idverification.internal.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * Colors used in the default 365iD theme.
 */
internal object AppColors {
    val purple = Color(0xff702f8a)
    val white = Color(0xffffffff)
    val lightPurple = Color(0xffe7daeb)
    val black = Color(0xFF000000)
    val green = Color(0xFF009900)
    val lightGreen = Color(0xff93d594)
    val gray = Color(0xffa7a7a7)
    val lightGray = Color(0xfff5f5f5)
    val middleGray = Color(0xffb3b3b3)
    val darkGray = Color(0xff707070)
    val lightBlue = Color(0xffCFEFFF)
}
