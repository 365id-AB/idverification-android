package com.id365.idverification.internal.views

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import com.id365.idverification.internal.ui.theme.Id365ScannerSdkTheme

/**
 * displays an error message when such is needed.
 */
@Composable
internal fun ErrorView(message: String) {
    Box(modifier = Modifier
        .fillMaxSize()
        .background(color = MaterialTheme.colorScheme.error)
    ) {
        Text(
            modifier = Modifier.align(Alignment.Center),
            text = message,
            color = MaterialTheme.colorScheme.onError,
            textAlign = TextAlign.Center
        )
    }
}

@Preview
@Composable
private fun  ErrorViewPreview() {
    Id365ScannerSdkTheme {
        ErrorView("Previewed Error Message")
    }
}