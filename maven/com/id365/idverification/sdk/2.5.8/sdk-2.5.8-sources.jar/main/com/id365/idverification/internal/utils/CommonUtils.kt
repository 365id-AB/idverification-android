package com.id365.idverification.internal.utils

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.os.Build
import com.id365.idverification.internal.logging.AppLog
import com.id365.idverification.internal.utils.CommonUtils.DebugTAG

internal object CommonUtils {
    /**
     * This adds a new property "DebugTAG" to all Kotlin objects/classes. This makes debugging on
     * android easier, since we can just call e.g. Log.d(DebugTAG, "message") from anywhere and get
     * an appropriately named TAG.
     */
    val Any.DebugTAG: String
        get() = this::class.java.simpleName
}


/**
 * Helper function to get an activity reference from a context.
 */
internal fun Context.getActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.getActivity()
    else -> null
}


internal fun StackTraceElement.squash(): String {
    val squashedFilename = fileName?.filter { it in 'A'..'Z' } ?: "?"
    return "[IV$squashedFilename$lineNumber]"
}

internal fun Throwable.squash(): String {
    val packageName = if (Build.VERSION.SDK_INT < 31) {
        CommonUtils.javaClass.`package`?.name ?: ""
    } else {
        CommonUtils.javaClass.packageName
    }.split(".").take(3).joinToString(".")
    val firstId365Element = try {
        stackTrace.first { it.className?.contains(packageName) ?: false }
    } catch(e: NoSuchElementException) {
        AppLog.e(DebugTAG, "No such element? ${stackTraceToString()}")
        stackTrace[0]
    } catch(e: Exception) {
        AppLog.e(DebugTAG, "Exception when trying to find element", e)
        stackTrace[0]
    }
    return firstId365Element.squash()
}

