package com.id365.idverification.internal.nfc

/**
 * The reason given for skipping NFC step
 */
enum class SkipReason{
    Undefined, // Equivalent to NOT skipping.
    UserSkipped,
    NfcNotSupported,
}