package com.id365.idverification.internal.views.microblink

import androidx.compose.animation.EnterExitState
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.core.animateDp
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawStyle
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.id365.idverification.internal.model.CameraConstants

@Composable
internal fun ReticleView(
    modifier: Modifier = Modifier,
    borderColor: Color,
    strokeWidth: Dp = 8.dp,
    radii: Dp = 25.dp
) {
    Canvas(
        modifier = modifier.fillMaxSize(),
        onDraw = {
            val height = size.height
            val width = size.width
            val left = 0F
            val radius = radii.toPx()
            val extra: Float = radius
            val right = width
            val rightCenter = right - radius
            val leftCenter = radius

            val path = Path().apply {
                // Top left
                moveTo(x=leftCenter + extra, y=0f)
                lineTo(x=leftCenter, y=0f)
                arcTo(
                    rect=Rect(center=Offset(x=leftCenter, y=radius), radius=radius),
                    startAngleDegrees = 270f,
                    sweepAngleDegrees = -90f,
                    forceMoveTo = false
                )
                lineTo(x=left, y=radius + extra)

                // Bottom left
                moveTo(x=left, y=height - radius - extra)
                lineTo(x=left, y=height - radius)
                arcTo(
                    rect=Rect(center=Offset(x=leftCenter, y=height-radius), radius=radius),
                    startAngleDegrees = 180f,
                    sweepAngleDegrees = -90f,
                    forceMoveTo = false
                )
                lineTo(x=leftCenter + extra, y=height)

                // Bottom right
                moveTo(x=rightCenter - extra, y=height)
                lineTo(x=rightCenter, y=height)
                arcTo(
                    rect=Rect(center=Offset(x=rightCenter, y=height-radius), radius=radius),
                    startAngleDegrees = 90f,
                    sweepAngleDegrees = -90f,
                    forceMoveTo = false
                )
                lineTo(x=right, y=height - radius - extra)

                // Top right
                moveTo(x=right, y=radius + extra)
                lineTo(x=right, y=radius)
                arcTo(
                    rect=Rect(center=Offset(x=rightCenter, y=radius), radius=radius),
                    startAngleDegrees = 0f,
                    sweepAngleDegrees = -90f,
                    forceMoveTo = false
                )
                lineTo(x=rightCenter - extra, y=0f)
            }
            drawPath(path, color = borderColor, style = Stroke(width=strokeWidth.toPx()))
        }
    )
}

@Preview
@Composable
private fun  ReticleViewPreview() {
    Box(modifier = Modifier
        .fillMaxSize()
        .background(brush=Brush.horizontalGradient(listOf(
            Color.Blue.copy(green=0.45F, red=0.25F),
            Color.Green.copy(blue=0.55F, red=0.25F)
        ))),
        contentAlignment = Alignment.Center
    ) {
        Box(modifier = Modifier
            .aspectRatio(CameraConstants.ID3_RELATIONSHIP)
            .padding(all = 20.dp)
        ) {
            ReticleView(borderColor = Color.White)
        }
    }
}

