package com.id365.idverification.internal.views

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.id365.idverification.internal.ui.theme.Id365ScannerSdkTheme


@Composable
internal fun TransactionProgressIndicator(
    currentStep: Int,
    totalSteps: Int,
    completedColor: Color = MaterialTheme.colorScheme.tertiaryContainer,
    currentColor: Color = MaterialTheme.colorScheme.tertiary,
    futureColor: Color = MaterialTheme.colorScheme.secondary,
    completedTextColor: Color = MaterialTheme.colorScheme.onTertiaryContainer,
    currentTextColor: Color = MaterialTheme.colorScheme.onTertiary,
    futureTextColor: Color = MaterialTheme.colorScheme.onSecondary,
) {
    if(totalSteps < 1) return
    Row(horizontalArrangement = Arrangement.SpaceEvenly, modifier=Modifier.fillMaxWidth().padding(vertical = 20.dp), verticalAlignment = Alignment.CenterVertically) {
        Spacer(modifier = Modifier.weight(1F/(totalSteps*2)))
        for (i in 1..currentStep) {
            CheckMarkCircle(
                modifier = Modifier.padding(horizontal = 10.dp),
                textColor = completedTextColor,
                color = completedColor
            )
            Box(modifier = Modifier
                .weight(1F)
                .background(color = completedColor)
                .height(2.dp)
            )
        }
        CheckMarkCircle(
            modifier = Modifier.padding(horizontal = 10.dp),
            text = "${currentStep+1}",
            textColor = currentTextColor,
            color = currentColor
        )
        for (i in currentStep+2..totalSteps) {
            Box(modifier = Modifier
                .weight(1F)
                .background(color = futureColor)
                .height(2.dp)
            )
            CheckMarkCircle(
                modifier = Modifier.padding(horizontal = 10.dp),
                text="$i",
                textColor = futureTextColor,
                color = futureColor
            )
        }
        Spacer(modifier = Modifier.weight(1F/(totalSteps*2)))
    }
}

@Composable
private fun CheckMarkCircle(
    modifier: Modifier = Modifier,
    text: String = "✓",
    textColor: Color = Color.White,
    color: Color = Color.Magenta,
) {
    var size by remember { mutableStateOf(IntSize.Zero)}
    Box(modifier = modifier
        .clip(shape = CircleShape)
        .background(color = color)
        .onGloballyPositioned {
            size = it.size
        }
        .width(32.dp)
        .aspectRatio(1F), contentAlignment = Alignment.Center
    ) {
        Text(text=text, color=textColor, fontWeight = FontWeight.W900, fontSize = size.height.sp/8,
            modifier = Modifier.scale(5F/3))
    }
}



@Preview
@Composable
private fun TransactionProgressIndicatorPreview()
{
    Id365ScannerSdkTheme {
        Column(
            modifier= Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface),
            horizontalAlignment = Alignment.CenterHorizontally) {
            TransactionProgressIndicator(currentStep = 1, totalSteps = 3)
        }
    }
}
