package com.id365.idverification.internal.utils

import android.content.Context
import org.koin.core.context.GlobalContext
import java.util.UUID
import androidx.core.content.edit

internal object VendorId {

     fun getVendorId(context: Context): String {
        val prefs = context.getSharedPreferences("365iD_SharedPrefs", Context.MODE_PRIVATE)
        val vid = prefs.getString("vendorId", null)
        if (vid == null) {

            val uuid = UUID.randomUUID().toString()
            prefs.edit {
                putString("vendorId", uuid)
            }
            return uuid
        }
        return vid
    }
}