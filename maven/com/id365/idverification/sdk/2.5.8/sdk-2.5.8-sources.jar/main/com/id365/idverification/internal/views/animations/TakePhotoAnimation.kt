package com.id365.idverification.internal.views.animations

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import com.id365.idverification.R

internal enum class DefaultAnimations(
    val resourceId: Int
) {
    ODD_SIZE(R.drawable.odd_size_document),
    GENERIC(R.drawable.passport_drivers_side_by_side_level_alt2),
    FRONT(R.drawable.drivers_licence_front),
    PASSPORT(R.drawable.passport_open),
    BACK(R.drawable.drivers_licence_back),
    FACE(R.drawable.faceid),
    NFC_ID1(R.drawable.nfc_id1),
    NFC_ID3(R.drawable.passport_nfc)
}

@Composable
internal fun DefaultAnimationView(
    animation: DefaultAnimations = DefaultAnimations.GENERIC
) {
    Image(
        painterResource(id = animation.resourceId),
        contentDescription = "Illustration of taking a photo of an ID document",
        contentScale = ContentScale.Inside,
        modifier = Modifier.fillMaxSize()
    )
}


@Preview
@Composable
private fun  DefaultAnimationViewPreview() {
    Box(
        modifier = Modifier
            .background(color = Color.White)
            .fillMaxWidth()
            .aspectRatio(3 / 2F),
        contentAlignment = Alignment.Center
    ) {
        DefaultAnimationView(DefaultAnimations.FRONT)
    }
}
