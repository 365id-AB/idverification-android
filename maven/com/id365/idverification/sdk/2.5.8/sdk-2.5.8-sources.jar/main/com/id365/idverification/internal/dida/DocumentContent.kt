package com.id365.idverification.internal.dida

/**
 * Represents a DocumentContent object as seen here:
 * https://gitlab.365id.com/365id/dida/-/blob/main/_365id.Dida.Contracts/DocumentContent.cs
 */
internal data class DocumentContent(
    val preferedDigitalIdProvider: String,
    val contentSource: String,
    val contentStandard: String,
    val data: ByteArray,
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as DocumentContent

        if (preferedDigitalIdProvider != other.preferedDigitalIdProvider) return false
        if (contentSource != other.contentSource) return false
        if (contentStandard != other.contentStandard) return false
        if (!data.contentEquals(other.data)) return false

        return true
    }

    override fun hashCode(): Int {
        var result = preferedDigitalIdProvider.hashCode()
        result = 31 * result + contentSource.hashCode()
        result = 31 * result + contentStandard.hashCode()
        result = 31 * result + data.contentHashCode()
        return result
    }
}