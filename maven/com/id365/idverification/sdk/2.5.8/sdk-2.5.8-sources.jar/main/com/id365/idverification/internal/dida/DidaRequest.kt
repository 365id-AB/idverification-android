package com.id365.idverification.internal.dida

/**
 * Represents a DIDA request message. See:
 * https://gitlab.365id.com/365id/dida/-/blob/main/_365id.Dida.Contracts/DidaAssessmentRequest.cs
 */
internal data class DidaRequest (
    val transactionId: String,
    val content: DocumentContent,
    val correlationId: String,
    val deviceId: String,
    val tokenId: String,
)
