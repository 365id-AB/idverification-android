package com.id365.idverification.internal.viewmodel

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.provider.Settings
import android.view.View
import androidx.camera.view.PreviewView
import androidx.compose.runtime.MutableState
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.id365.idverification.internal.core.IdScannerKoinComponent
import com.id365.idverification.internal.model.ICameraModel
import com.id365.idverification.internal.model.ITransactionModel
import org.koin.core.component.get
import org.koin.core.component.inject
import org.koin.core.error.InstanceCreationException
import org.koin.core.parameter.parametersOf
import androidx.core.net.toUri

/**
 * Implementation of ICameraViewModel. This is the ViewModel that provides the data
 * used by FrontView.
 *
 * @param lfo: A LifecycleOwner tied to the CameraView.
 */
internal class CameraViewModel(
    val ctx: Context,
    lfo: LifecycleOwner,
    ar: Float,
) : ICameraViewModel, IdScannerKoinComponent() {

    private val cameraModel: ICameraModel by lazy {
        get(parameters = { parametersOf(lfo, ar) })
    }

    val transactionModel: ITransactionModel by inject()

    private val alert: IAlertBoxViewModel = get()

    override val previewView: View
        get() = cameraModel.previewView
    override val previewStreamState: LiveData<PreviewView.StreamState>
        get() = cameraModel.previewStreamState

    /**
     * Controls when manual mode is active
     */
    override val cameraViewState = MutableLiveData(ICameraViewModel.CameraViewState.INIT)

    /**
     * Variable tracks the same value from cameraModel. Exists here for convenience
     */
    override val isCameraRunning: MutableLiveData<Boolean>
        get() = cameraModel.isCameraRunning

    override val isLuminanceAcceptable: MutableState<Boolean>
        get() = cameraModel.luminanceIsAcceptable

    override fun getPreviewImage(): Bitmap? =
        try {
            transactionModel.backPreview.value
        } catch (e: InstanceCreationException) {
            null
        } catch (e: Exception) {
            null
        }

    override fun start() {
        cameraModel.start()
    }

    private var session: Boolean = false
    private var camera: Boolean = false
    private var flip: Boolean = false

    override fun close() {
        super.close()
        cameraModel.close()
    }

    /**
     * When user presses the button, open the device settings directly to NFC
     * @param: context: The context is needed to start a new activity
     */
    private fun openSettings(context: Context) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
        intent.data = ("package:" + context.packageName).toUri()
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ContextCompat.startActivity(context, intent, null)
    }
}
