package com.id365.idverification.internal.integrations.iproov

/**
 * SDK internal representation of an ValidateEnrolRequest
 */
internal data class ValidateEnrolRequest (
    val TransactionId: String,
    val iProovToken: String,
    val VendorId: String,
    val Status: IProovSdkReturnStatus
    ) {

    internal enum class IProovSdkReturnStatus {
        Undefined,
        Success,
        Failure,
        Cancelled,
        Error,
    }
}
