package com.id365.idverification.internal.views.oddsizeimagecaptureview

import android.content.Context
import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.LifecycleOwner
import com.id365.idverification.internal.core.SdkContext
import com.id365.idverification.internal.logging.AppLog
import com.id365.idverification.internal.viewmodel.IOddSizeImageCaptureViewModel
import org.koin.core.parameter.parametersOf
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import com.id365.idverification.internal.core.LandingPageTransition
import com.id365.idverification.internal.utils.WithPermission
import com.id365.idverification.internal.views.MissingCameraPermissionView
import com.id365.idverification.internal.views.WaitingView

@Composable
internal fun OddSizeImageCaptureView(
    context: Context = LocalContext.current,
    lifecycleOwner: LifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current,
    isCaptureButtonPressed: Boolean = false,
    model: IOddSizeImageCaptureViewModel? = try {
        SdkContext.sdk.koin.get(parameters = {
            parametersOf(
                context,
                lifecycleOwner,
                16/9F
            )
        })
    } catch (e: Exception) {
        AppLog.e("TestView", "Ex", e)
        null
    }
) {

    val captureButtonPressed = remember { mutableStateOf(isCaptureButtonPressed) }
    val capturedImage = remember { mutableStateOf<Bitmap?>(null) }
    val accepted = remember { mutableStateOf(false) }

    val opacity = if (capturedImage.value != null) 0.95F else 0.65F

    fun retakePicture() {
        capturedImage.value = null
        captureButtonPressed.value = false
        accepted.value = false
    }

    // SHOW WAITING VIEW WHEN ACCEPTED
    if (accepted.value) {
        WaitingView()
        return
    }


    model?.let {
        WithPermission(
            onDenied = @Composable { request ->
                SdkContext.cameraReady.postValue(LandingPageTransition.READY)
                MissingCameraPermissionView(request)
            }
        ) {

            if (capturedImage.value == null) {
                OddSizeCameraView(model)
            } else {
                Image(
                    bitmap = capturedImage.value!!.asImageBitmap(),
                    contentDescription = "Captured Image",
                    contentScale = ContentScale.FillHeight,
                    alignment = Alignment.Center
                )
            }

            OddSizeImageCaptureOverlayView(
                opacity = opacity,
                captured = captureButtonPressed.value,
                model = model
            )

            Box(modifier = Modifier.fillMaxSize()) {

                if (capturedImage.value == null) {

                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(bottom = 105.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        ShutterButton(
                            modifier = Modifier.testTag("shutterButton"),
                            onCaptureImage = {
                                model.captureImage { bmp ->
                                    capturedImage.value = bmp
                                }
                            },
                            toggleCaptureButton = { captureButtonPressed.value = true }
                        )
                    }

                } else {

                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(bottom = 105.dp),
                        horizontalArrangement = Arrangement.Start,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Spacer(modifier = Modifier.padding(40.dp, 0.dp, 0.dp))
                        RetakePictureButton(
                            modifier = Modifier.testTag("retakeButton")
                        ) { retakePicture() }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(bottom = 105.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        
                        AcceptButton(
                            modifier = Modifier.testTag("acceptButton"),
                            enabled = !accepted.value,
                            onClick = {
                                if (!accepted.value) {
                                    accepted.value = true
                                    model.acceptImage(capturedImage.value!!)
                                }
                            }
                        )
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(bottom = 105.dp),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.Bottom
                ) {
                    CloseButtonView { model.buttonCb() }
                    Spacer(modifier = Modifier.padding(0.dp, 0.dp, 40.dp))
                }
            }
        }
    }
}