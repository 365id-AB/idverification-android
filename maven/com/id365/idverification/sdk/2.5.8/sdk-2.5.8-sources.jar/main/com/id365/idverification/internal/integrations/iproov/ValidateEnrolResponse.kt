package com.id365.idverification.internal.integrations.iproov

/**
 * SDK internal representation of an ValidateEnrolResponse
 */
internal data class ValidateEnrolResponse(
    val success: Boolean
)