package com.id365.idverification.internal.viewmodel

import android.content.Context
import androidx.compose.runtime.MutableState

interface IPermissionsViewModel
{
    val cameraPermission: MutableState<Boolean>

    fun openSettings(context: Context)
}