package com.id365.idverification.internal.views.animations

import androidx.compose.animation.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp

/**
 * Animates the entry of [content], using a slideIn from bottom animation.
 *
 * @param visibility: When should [content] be visible?
 * @param content: The composable to show.
 */
@Composable
internal fun AnimatedEntry(
    visibility: Boolean = false,
    content: @Composable () -> Unit
) {
    val density = LocalDensity.current
    AnimatedVisibility(
        visible = visibility,
        enter = slideInVertically {
            with(density) {400.dp.roundToPx() }
        },
        exit = slideOutVertically {
            with(density) {400.dp.roundToPx() }
        },
    ) {
        content.invoke()
    }
}
