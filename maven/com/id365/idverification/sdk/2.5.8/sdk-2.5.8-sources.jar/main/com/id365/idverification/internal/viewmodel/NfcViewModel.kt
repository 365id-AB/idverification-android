package com.id365.idverification.internal.viewmodel

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.nfc.NfcAdapter
import android.nfc.NfcManager
import com.id365.idverification.internal.logging.AppLog
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import com.id365.idverification.internal.utils.CommonUtils.DebugTAG
import com.id365.idverification.internal.core.IdScannerKoinComponent
import com.id365.idverification.R
import com.id365.idverification.internal.communication.AbortReason
import com.id365.idverification.internal.communication.Task
import com.id365.idverification.internal.core.SdkContext
import com.id365.idverification.internal.model.ITransactionModel
import com.id365.idverification.internal.nfc.INfcProcessor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.koin.core.component.get
import org.koin.core.component.inject
import org.koin.core.parameter.parametersOf

/**
 * The NfcViewModel provides access to NfcProcessor when the NfcView is active
 */
internal class NfcViewModel(
    val activity: Activity,
    val lfo: LifecycleOwner,

) : INfcViewModel, LifecycleEventObserver, IdScannerKoinComponent() {
    private val transactionModel: ITransactionModel by inject()
    override val taskData: MutableState<Task> = transactionModel.viewTaskData
    override val progressBarFill: MutableState<Float> = mutableFloatStateOf(0f)
    override val progressMessage: MutableState<String> = mutableStateOf("")

    init {
       SdkContext.nfcViewModel = this
    }

    private fun setProgressBarFill(value: Double) {
        if (value.isNaN()) return
        CoroutineScope(Dispatchers.Main).launch {
            progressBarFill.value = value.toFloat()
        }
    }
    private fun setProgressMessage(message: String) {
        CoroutineScope(Dispatchers.Main).launch {
            progressMessage.value = message
        }
    }

    private fun setInfoText(message: String) = CoroutineScope(Dispatchers.Main).launch {
        infoText.value = message
    }

    private val updateMessage : ((message: String, progressPercent: Double) -> Unit) = {
             message, progressPercent ->
        updateMessage(message, progressPercent)
    }

    private fun updateMessage(message: String, progressPercent: Double) {
        if (!message.isEmpty()) {
            setProgressMessage(message)
        }
        
        setProgressBarFill(progressPercent)
    }

    private val adapter = (activity.getSystemService(Context.NFC_SERVICE) as NfcManager).defaultAdapter
    override val adapterActive: MutableState<Boolean> = mutableStateOf(false)
    override val nfcSupported: Boolean = adapter != null
    override val nfcEnabled = mutableStateOf(adapter != null && adapter.isEnabled)
    override val buttonEnabled = mutableStateOf(true)
    override val buttonLabel = activity.getString(R.string._365id_button_skip)
    override val infoText = mutableStateOf(activity.getString(R.string._365id_white_information_nfc_subtitle))
    override val playAnimation = mutableStateOf(true)
    override val buttonCb: () -> Unit = {
        buttonEnabled.value = false
        nfcProcessor?.onUserSkipNfc()
    }

    private var nfcProcessor: INfcProcessor? = createNfcProcessor()

    /**
     * Creates a new instance of the NfcProcessor
     */
    private fun createNfcProcessor(): INfcProcessor {
        return get<INfcProcessor>(parameters = { parametersOf(activity, lfo, updateMessage) })
    }

    /**
     * BroadcastReceiver implementation. This updates the information displayed in the NfcView
     * accordingly based on if NFC is enabled or not.
     * This will trigger if the user disables or enables NFC outside of the lifecycle of the SDK
     * i.e if the user enables or disables NFC using pulldown menu.
     */
    private val nfcStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (NfcAdapter.ACTION_ADAPTER_STATE_CHANGED == intent?.action) {
                val state = intent.getIntExtra(NfcAdapter.EXTRA_ADAPTER_STATE, NfcAdapter.STATE_OFF)
                when (state) {
                    NfcAdapter.STATE_ON -> updateNfcState(true)
                    NfcAdapter.STATE_OFF -> updateNfcState(false)
                }
            }
        }
    }

    private fun updateNfcState(isEnabled: Boolean) {
        CoroutineScope(Dispatchers.Main).launch {
            nfcEnabled.value = isEnabled
            setProgressMessage(
                if (isEnabled) activity.getString(R.string._365id_white_information_nfc_subtitle)
                else activity.getString(R.string._365id_read_nfc_status_disabled)
            )
        }
    }

    // Register NFC state receiver
    private fun registerNfcStateReceiver() {
        try {
            val intentFilter = IntentFilter(NfcAdapter.ACTION_ADAPTER_STATE_CHANGED)
            activity.registerReceiver(nfcStateReceiver, intentFilter)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // Unregister NFC state receiver
    private fun unregisterNfcStateReceiver() {
        try {
            activity.unregisterReceiver(nfcStateReceiver)
        } catch (e: IllegalArgumentException) {
            e.printStackTrace()
        }
    }

    /**
     * LifecycleEventObserver implementation. Handles lifecycle events and manages the registration of the NFC state BroadcastReceiver.
     * When NFC is enabled or disabled using system settings,
     * this updates the information displayed in the NfcView accordingly based on if NFC is enabled or not.
     *
     * @param source: The Lifecycle owner that will generate events. Typically NfcView.
     * @param event: The event generated.
     */
    override fun onStateChanged(source: LifecycleOwner, event: Lifecycle.Event) {
        when (event) {
            Lifecycle.Event.ON_RESUME -> {
                registerNfcStateReceiver()
                if (adapter?.isEnabled == true) {
                    updateNfcState(true)
                } else {
                    updateNfcState(false)
                }
            }
            Lifecycle.Event.ON_PAUSE -> {
                unregisterNfcStateReceiver()
            }
            else -> {} /* no-op */
        }
    }

    override fun close() {
        super.close()
        SdkContext.nfcViewModel = null
        unregisterNfcStateReceiver()
        AppLog.d(DebugTAG, "Closing NfcViewModel")
    }

    override suspend fun handleIntent(intent: Intent) {
        nfcProcessor?.resolveIntent(intent)
    }

    init {
        lfo.lifecycle.addObserver(this)
    }
}
