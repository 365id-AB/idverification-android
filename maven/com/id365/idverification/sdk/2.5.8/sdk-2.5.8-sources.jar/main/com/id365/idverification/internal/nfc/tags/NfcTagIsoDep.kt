package com.id365.idverification.internal.nfc.tags

import android.nfc.tech.IsoDep
import android.util.Log
import com.id365.idverification.internal.utils.CommonUtils.DebugTAG

/**
 * Implements Android API "IsoDep" using our Interface
 *
 * @param tag: The Android Nfc object describing this tag
 */
internal class NfcTagIsoDep(private val tag: IsoDep): NfcTag(tag) {

    override fun getChip(): String {
        return standard
    }

    override fun setTimeout(timeout: Int) {
        try {
            tag.timeout = timeout
        } catch(e: SecurityException) {
            Log.e(DebugTAG, "Couldn't set timeout to $timeout")
        }
    }

    override fun transceive(data: ByteArray): ByteArray {
        return tag.transceive(data)
    }

    override fun getMaxTransceiveLength(): Int = tag.maxTransceiveLength

    override fun isExtendedLengthApduSupported(): ExtendedApduSupport
        = try {
        when (tag.isExtendedLengthApduSupported) {
            true -> ExtendedApduSupport.AVAILABLE
            false -> ExtendedApduSupport.UNAVAILABLE
        }
    } catch(se: SecurityException) {
        // Do not upload this message to sentry. Known issue with Pixel 7 devices getting "Permission Denial: Tag is out of date"
        Log.e(DebugTAG, "Can't check isExtendedLengthApduSupported: $se")
        ExtendedApduSupport.UNKNOWN
    } catch(e: Exception) {
        Log.e(DebugTAG, "Error enabling NFC foreground dispatch", e)
        ExtendedApduSupport.UNKNOWN
    }

    companion object{
        const val standard: String = "ISO 14443-4"
        val tech: String = IsoDep::class.java.name
    }
}