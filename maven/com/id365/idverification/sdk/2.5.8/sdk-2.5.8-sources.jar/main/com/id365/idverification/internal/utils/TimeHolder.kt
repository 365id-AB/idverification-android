package com.id365.idverification.internal.utils

import kotlinx.coroutines.*
import java.util.*

/**
 * This class check if a specific amount of time has been executed.
 *
 * @param milliSecondsToHold: Number of milliseconds to hold until completion handler runs
 * @param coroutineDispatcher: The dispatcher that needs to run on the main thread if delay is needed
 */
class TimeHolder(
    milliSecondsToHold: Long,
    val coroutineDispatcher: CoroutineDispatcher = Dispatchers.IO
) {

    private val beginTime: Date = Calendar.getInstance().time
    private var endTime: Date

    init {
        this.endTime = Date(beginTime.time + milliSecondsToHold)
    }

    /**
     * This method has a callback when the added time has been executed.
     * If the added time already been executed while calling this method, the callback runs directly.
     *
     * @param timeHasBeenExecuted: The completion handler to tell when the time is executed.
     */
    fun holdToEndTime(timeHasBeenExecuted: () -> Unit) {

        // Get number of milliseconds left to endTime
        val millisLeft: Long = getMillisecondsLeftToEndTime()

        // If there is no time left, then we run the completion handler
        if (millisLeft <= 0) {
            timeHasBeenExecuted()
            return
        }

        // Run delay with the existing time, then we run the completion handler
        CoroutineScope(coroutineDispatcher).launch() {
            delay(millisLeft)
            timeHasBeenExecuted.invoke()
        }
    }

    /**
     * Get number of milliseconds left to endTime
     * If the time is negative, we return zero
     */
    fun getMillisecondsLeftToEndTime(): Long {
        val timeNow: Date = Calendar.getInstance().time
        val millisLeft: Long = endTime.time - timeNow.time
        if (millisLeft <= 0) return 0
        return millisLeft
    }
}