package com.id365.idverification.errors

import androidx.annotation.Keep
import kotlinx.serialization.Serializable
import kotlinx.serialization.Transient

@Keep
@Serializable
/**
 * Generic error the SDK will use to describe issues that may occur when using
 * the SDK
 */
sealed class IdVerificationException: Exception() {
    val errorType: String
        get() = javaClass.simpleName
    abstract override val message: String
    abstract val exception: Exception?

    override fun equals(other: Any?): Boolean {
        if (other !is IdVerificationException) return false
        if (other.message != message) return false
        return javaClass == other.javaClass
    }

    override fun hashCode(): Int {
        var result = errorType.hashCode()
        result = 31 * result + message.hashCode()
        return result
    }
}

@Serializable
@Keep
/**
 * The token provided to the SDK was invalid. The SDK attempted to authenticate using the provided
 * token, but the 365id cloud services did not accept.
 */
class IdVerificationInvalidTokenException internal constructor(
    override val message: String =
        "The provided token was invalid. Please start the SDK using a valid token.",
    @Transient
    override val exception: Exception? = null
) : IdVerificationException()

@Serializable
@Keep
/**
 * Error raised if a problem internal to the SDK occurred, such as being unable to open and
 * configure the camera
 */
class IdVerificationClientException internal constructor(
    override val message: String =
        "An internal error occurred . If this happens frequently, please contact 365id support.",
    @Transient
    override val exception: Exception? = null
) : IdVerificationException()

@Serializable
@Keep
/**
 * Error raised if a problem occurred when talking to 365id cloud services. Could be a networking issue
 */
class IdVerificationServerException internal constructor(
    override val message: String =
        "There was an error communicating with 365ID cloud services. If this happens frequently, please contact 365id support.",
    @Transient
    override val exception: Exception? = null
) : IdVerificationException()

@Serializable
@Keep
/** When this version of the SDK is no longer supported, this error is returned */
class UnsupportedSdkVersionException internal constructor(
    override val message: String =
        "This version of the 365id IdVerification SDK is no longer supported. Please upgrade your app to a supported version.",
    @Transient
    override val exception: Exception? = null
) : IdVerificationException()

@Serializable
@Keep
/**
 * When the license used to start doesn't have any packages remaining this error is returned.
 */
class NoActivePackagesException internal constructor(
    override val message: String =
        "This license has no remaining transactions. Please contact your 365id sales representative.",
    @Transient
    override val exception: Exception? = null
) : IdVerificationException()

@Serializable
@Keep
/** The session token expired. */
class IdVerificationSessionTokenExpiredException internal constructor(
    override val message: String = "Your session has expired. Please restart the SDK.",
    @Transient
    override val exception: Exception? = null
) : IdVerificationException()

@Serializable
@Keep
/**
 * User error occurred.
 */
class IdVerificationUserException internal constructor(
    override val message: String = "User error occurred.",
    @Transient
    override val exception: Exception? = null
) : IdVerificationException()
