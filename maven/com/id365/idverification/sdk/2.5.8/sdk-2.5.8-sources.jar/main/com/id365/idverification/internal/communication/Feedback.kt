package com.id365.idverification.internal.communication

import com.id365.idverification.DocumentType


internal data class Feedback(
    val documentFeedback: DocumentFeedback = DocumentFeedback(),
    val nfcFeedback: NfcFeedback = NfcFeedback(),
    val facematchFeedback: FaceMatchFeedback = FaceMatchFeedback(),
) {
    internal data class DocumentFeedback(
        val country: String = "",
        val documentType: DocumentType = DocumentType.Undefined
    )

    internal data class NfcFeedback(
        val expiryDate: String = "",
        val nfcFeedback: com.id365.idverification.NfcFeedback = com.id365.idverification.NfcFeedback.Undefined,
        val dataTypes: Int = com.id365.idverification.NfcDataTypeFlags.NONE
    )

    internal data class FaceMatchFeedback(
        val facematchStatus: com.id365.idverification.FacematchFeedback = com.id365.idverification.FacematchFeedback.Undefined,
        val facematchSource: com.id365.idverification.FacematchSource = com.id365.idverification.FacematchSource.Undefined
    )
}
