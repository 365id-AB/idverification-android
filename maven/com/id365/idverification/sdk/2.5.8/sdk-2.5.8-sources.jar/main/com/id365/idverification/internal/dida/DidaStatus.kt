package com.id365.idverification.internal.dida

/**
 * Represents the different status results that DIDA can respond with. See:
 * https://gitlab.365id.com/365id/dida/-/blob/main/_365id.Dida.Contracts/DidaAssessmentResponse.cs
 */
internal enum class DidaStatus {
    Incompatible,
    MultipleCompatible,
    Processing,
    UNKNOWN,
}