package com.id365.idverification.internal.views

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.id365.idverification.R
import com.id365.idverification.internal.core.SdkContext
import com.id365.idverification.internal.ui.theme.Id365ScannerSdkTheme

internal enum class LoadingViewType(val asset: Int?) {
    NFC(R.drawable.nfc_20230605),
    SpinnerWithCard(R.drawable.drivers_licence_front),
    SpinnerWithFace(R.drawable.faceid),
    Spinner(null);
}
@Composable
internal fun LoadingView(
    modifier: Modifier = Modifier,
    loadingViewType: LoadingViewType = LoadingViewType.SpinnerWithCard,
) {
    Box(
        modifier = modifier
            .aspectRatio(3 / 2F)
            .testTag("loadingView")
    ) {
        when(loadingViewType){
            LoadingViewType.NFC -> SdkContext.customTheme.animations.loadingNfc()
            LoadingViewType.SpinnerWithCard -> SdkContext.customTheme.animations.loadingImageCapture()
            LoadingViewType.SpinnerWithFace -> SdkContext.customTheme.animations.loadingFacematch()
            LoadingViewType.Spinner -> SdkContext.customTheme.animations.loadingGeneric()
        }
    }
}

@Composable
internal fun IconView(
    modifier: Modifier = Modifier,
    loadingViewType: LoadingViewType = LoadingViewType.Spinner,
) {
    loadingViewType.asset?.let {asset ->
        val tintColor = MaterialTheme.colorScheme.primary
        Image(
            painter = painterResource(id = asset),
            contentDescription = "Loading...",
            colorFilter = ColorFilter.tint(tintColor),
            modifier = modifier,
        )
    }
}


@Preview(showBackground = true)
@Composable
private fun  LoadingViewPreview() {
    val icon = remember { mutableStateOf(LoadingViewType.NFC) }
    Id365ScannerSdkTheme(darkTheme = false) {
        Box(modifier = Modifier
            .fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {

        LoadingView(loadingViewType=icon.value)
        }
        Box(modifier = Modifier.fillMaxSize()) {
            Button(modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(all = 40.dp), onClick = {
                icon.value = when(icon.value) {
                    LoadingViewType.NFC -> LoadingViewType.SpinnerWithCard
                    LoadingViewType.SpinnerWithCard -> LoadingViewType.SpinnerWithFace
                    LoadingViewType.SpinnerWithFace -> LoadingViewType.Spinner
                    LoadingViewType.Spinner -> LoadingViewType.NFC
                }
            }) {
                Text("Change Preview Icon")
            }
        }
    }
}
