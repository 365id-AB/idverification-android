package com.id365.idverification

import androidx.annotation.Keep
import com.id365.idverification.errors.IdVerificationException
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * Contains information pertaining to the result of a transaction.
 * This type will never contain [error] if implementing
 * [IdVerificationEventHandler]
 *
 * @param transactionId If not empty, contains a unique string that can be used to poll 365id
 *                      cloud services about the verdict for this transaction
 * @param error         If an error occurred, this contains the error
 */
@Keep
@Serializable
class IdVerificationResult internal constructor(
    val transactionId: String,
    val error: IdVerificationException? = null
) {
    @Keep
    fun asJson(): String {
        return Json.encodeToString(this)
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as IdVerificationResult

        if (transactionId != other.transactionId) return false
        return error == other.error
    }

    override fun hashCode(): Int {
        var result = transactionId.hashCode()
        result = 31 * result + (error?.hashCode() ?: 0)
        return result
    }
}

