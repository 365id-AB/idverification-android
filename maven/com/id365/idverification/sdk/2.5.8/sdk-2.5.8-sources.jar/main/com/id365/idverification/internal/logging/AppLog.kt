package com.id365.idverification.internal.logging

import android.util.Log
import com.id365.idverification.BuildConfig
import com.id365.idverification.internal.core.SdkContext.koin
import com.id365.idverification.internal.communication.SessionToken
import org.koin.core.error.NoBeanDefFoundException

/**
 * Custom log class.
 * android.util.Log "Log.e / Log.w / etc" can be used here.
 */
internal object AppLog {

    lateinit var otelLogger: IOtelLogger

    /**
     * Returns info about the current line of code.
     * Ex: "ScannerSdkActivity.onCreate(IdVerificationActivity.kt:31)"
     */
    private fun getLogInfo(vararg properties: Pair<String, String>): Map<String, String> {

        val pathlink = createProperty("logInfo") {
            val currentThread = Thread.currentThread()
            val trace = currentThread.stackTrace.drop(2)
            val traceHead = trace.first() // With any luck, this is always AppLog.getLogInfo
            val stackTrace = trace.first {
                it.fileName != traceHead.fileName
            }
            val link = "(${stackTrace.fileName}:${stackTrace.lineNumber})"
            val path = "${stackTrace.className.substringAfterLast(".")}.${stackTrace.methodName}"
            "$path$link"
        }

        val transactionId = createProperty(name = "TransactionId") {
            try {
                koin.get<SessionToken>().transactionId
            } catch (e: NoBeanDefFoundException) {
                "unknown-transaction"
            }
        }

        return listOfNotNull(
            pathlink,
            transactionId,
            *properties
        ).associate {
            Pair(it.first, it.second)
        }
    }

    /**
     * Helper function to help facilitate the creation of properties we can append to a sentry log
     */
    private fun createProperty(name: String, method: () -> String): Pair<String, String>? {
        return try {
            val value = method.invoke()
            Pair(name, value)
        } catch(e: Exception) {
            null
        }
    }

    /** Custom log for INFO msg */
    fun i(tag: String, msg: String, vararg properties: Pair<String, String>) {
        val logInfo = getLogInfo(*properties)
        val transactionId: String? = logInfo["TransactionId"]
        val path = logInfo["logInfo"]
        if (::otelLogger.isInitialized) {
            otelLogger.log(tag, msg, transactionId, Log.INFO)
        } else {
            Log.i(tag, "Open Telemetry logger not initialized")
        }
        if (BuildConfig.DEBUG)
            Log.i(tag, "[${path}]: $msg")
    }

    /** Custom log for DEBUG msg */
    fun d(tag: String, msg: String, vararg properties: Pair<String, String>) {
        val logInfo = getLogInfo(*properties)
        val transactionId: String? = logInfo["TransactionId"]
        val path = logInfo["logInfo"]
        if (::otelLogger.isInitialized) {
            otelLogger.log(tag, msg, transactionId, Log.DEBUG)
        } else {
            Log.i(tag, "Open Telemetry logger not initialized")
        }
        if (BuildConfig.DEBUG)
            Log.d(tag, "[${path}]: $msg")
    }

    /** Custom log for WARN msg */
    fun w(tag: String, msg: String, vararg properties: Pair<String, String>) {
        val logInfo = getLogInfo(*properties)
        val transactionId: String? = logInfo["TransactionId"]
        val path = logInfo["logInfo"]
        if (::otelLogger.isInitialized) {
            otelLogger.log(tag, msg, transactionId, Log.WARN)
        } else {
            Log.i(tag, "Open Telemetry logger not initialized")
        }
        if (BuildConfig.DEBUG)
            Log.w(tag, "[${path}]: $msg")
        Log.ERROR
    }

    /** Custom log for VERBOSE msg */
    fun v(tag: String, msg: String, vararg properties: Pair<String, String>) {
        val logInfo = getLogInfo(*properties)
        val transactionId: String? = logInfo["TransactionId"]
        val path = logInfo["logInfo"]
        if (::otelLogger.isInitialized) {
            otelLogger.log(tag, msg, transactionId, Log.VERBOSE)
        } else {
            Log.i(tag, "Open Telemetry logger not initialized")
        }
        if (BuildConfig.DEBUG)
            Log.v(tag, "[${path}]: $msg")
    }

    /** Custom log for ERROR msg */
    fun e(tag: String, msg: String, throwable: Throwable? = null, vararg properties: Pair<String, String>) {
        val logInfo = getLogInfo(*properties)
        val transactionId: String? = logInfo["TransactionId"]
        val path = logInfo["logInfo"]
        if (::otelLogger.isInitialized) {
            otelLogger.log(tag, msg, transactionId, Log.ERROR)
        } else {
            Log.i(tag, "Open Telemetry logger not initialized")
        }
        if (BuildConfig.DEBUG) {
            if (throwable == null) Log.e(tag, "[${path}]: $msg")
            else Log.e(tag, "[${path}]: $msg", throwable)
        }
    }
}