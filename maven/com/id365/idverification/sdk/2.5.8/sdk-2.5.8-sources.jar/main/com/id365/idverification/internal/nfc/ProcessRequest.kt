package com.id365.idverification.internal.nfc

import com.id365.idverification.internal.nfc.tags.NfcTag
import kotlinx.serialization.Serializable

/**
 * Describes the responses provided by the Nfc tag so far,
 * with a list of responses to the latest query.
 */
@Serializable
internal data class ProcessRequest(
    /**
     * NfcService state, passed along blindly by the client
     */
    val state: String = "",

    /**
     * Chip standard detected by the client
     */
    val chipStandard: String = "",

    /**
     * Array of response from the NFC chip
     */
    val responses: List<Array<Byte>> = emptyList(),

    /**
     * If this client supports extended APDU commands or not. Used to determine
     * if NfcService should send extended APDU commands for performance
     */
    val extendedApduSupported: NfcTag.ExtendedApduSupport = NfcTag.ExtendedApduSupport.UNKNOWN,

    val skipReason: SkipReason = SkipReason.Undefined
)
