package com.id365.idverification

import android.app.Activity
import android.content.Context
import android.content.Intent
import androidx.activity.result.contract.ActivityResultContract
import androidx.annotation.Keep
import com.id365.idverification.errors.IdVerificationException
import kotlinx.serialization.json.Json
import kotlinx.serialization.decodeFromString

/**
 * This contract is used to start a [IdVerificationActivity]. If using [IdVerificationEventHandler], this is not used.
 */
@Keep
class IdVerificationResultContract : ActivityResultContract<String, IdVerificationResult>() {

    /**
     * Creates an Intent used to start a scan
     * @param input: a valid token from 365id
     * @return an Intent used to start the Scanner Activity
     */
    override fun createIntent(context: Context, input: String): Intent =
        Intent(context, IdVerificationActivity::class.java).also {
            it.putExtra("token", input)
        }

    override fun parseResult(resultCode: Int, intent: Intent?): IdVerificationResult =
        when (resultCode) {
            Activity.RESULT_OK,
            Activity.RESULT_CANCELED -> IdVerificationResult(
                intent?.getStringExtra(
                    transactionIdIntentString
                ) ?: ""
            )

            else -> {
                val decoded = intent?.getStringExtra(errorIntent)?.let {
                    Json.decodeFromString<IdVerificationException>(it)
                }

                IdVerificationResult(
                    transactionId = intent?.getStringExtra(transactionIdIntentString) ?: "",
                    error = decoded,
                )
            }
        }

    internal companion object {
        internal const val errorIntent = "error"
        internal const val transactionIdIntentString = "transactionId"
    }
}