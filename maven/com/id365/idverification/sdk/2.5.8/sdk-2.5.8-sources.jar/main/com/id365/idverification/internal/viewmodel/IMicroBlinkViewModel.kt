package com.id365.idverification.internal.viewmodel

import androidx.camera.view.PreviewView
import androidx.compose.runtime.MutableState
import com.id365.idverification.IdVerification
import java.io.Closeable

internal interface IMicroBlinkViewModel : IInformationOverlayViewModel, Closeable {

    fun startMicroBlinkSdk(previewView: PreviewView)
    fun getDocumentSizeType(): IdVerification.DocumentSizeType
    val didCaptureImage: MutableState<Boolean>
    val warningStatusMessage: MutableState<String?>
    val warningStatus : MutableState<Boolean>
}