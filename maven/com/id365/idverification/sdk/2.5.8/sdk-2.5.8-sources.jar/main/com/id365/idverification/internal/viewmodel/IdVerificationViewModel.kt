package com.id365.idverification.internal.viewmodel

import com.id365.idverification.internal.core.IdScannerKoinComponent
import com.id365.idverification.internal.communication.Task
import com.id365.idverification.internal.model.ITransactionModel
import com.id365.idverification.internal.utils.CommonUtils.DebugTAG
import android.util.Log
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import com.id365.idverification.contracts.grpc.coordinator.CoordinatorOuterClass
import com.id365.idverification.contracts.grpc.coordinator.abortTransactionRequest
import com.id365.idverification.internal.communication.AbortReason
import com.id365.idverification.internal.core.SdkContext
import com.id365.idverification.internal.communication.SessionToken
import com.id365.idverification.internal.logging.AppLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.koin.core.component.get
import org.koin.core.component.inject
import org.koin.core.error.InstanceCreationException

/**
 * Implementation of IIdVerificationViewModel
 */
internal class IdVerificationViewModel(
    val lfo: LifecycleOwner
) : IIdVerificationViewModel, LifecycleEventObserver, IdScannerKoinComponent() {

    init {
        lfo.lifecycle.addObserver(this)
    }

    /** Need access to the active transaction */
    private val transactionModel: ITransactionModel by inject()
    override val showInformationView: MutableState<Boolean> = transactionModel.showInfo

    /** Access the session token for validations */
    override fun getSessionToken(): SessionToken? {
        // If the SDK has not already set the Session Token,
        // then an exception will be thrown when get() is executed.
        return try {
            get()
        } catch (_: Exception) {
            null
        }
    }

    /** Get the current task from the transaction */
    override val task: MutableState<Task.Level>
        get() {
            return try {
                mutableStateOf(transactionModel.viewTaskData.value.nextTask)
            } catch(ise: java.lang.IllegalStateException) {
                mutableStateOf(Task.Level.WAIT)
            } catch(e: InstanceCreationException) {
                // This may happen when user tries to show the SDK view before `startSDK` is finished.
                // We will treat this as an acceptable usecase, and place ourselves in FRONT_SIDE until
                // the first `requestNextTask` returns.
                mutableStateOf(Task.Level.FRONT_SIDE)
            }catch(e: Exception) {
                Log.e(DebugTAG, "Exception when fetching view task", e)
                mutableStateOf(Task.Level.FINISHED_BUT_FAILED)
            }
        }

    /** Run the transaction callback with an empty response when user quits early */
    override val callback: () -> Unit = {
        SdkContext.abortJob = transactionModel.abortTransactionRequest(AbortReason.UserCancelled)
        SdkContext.eventHandler.onUserDismissed()
    }

    /** Activate life cycle events in the SDK */
    override fun onStateChanged(source: LifecycleOwner, event: Lifecycle.Event) {
        when (event) {
            Lifecycle.Event.ON_RESUME,
            Lifecycle.Event.ON_PAUSE -> {
                getSessionToken()?.validateExpireDateOfToken()
            }
            else -> {} /* no-op */
        }
    }

    override fun close() {
        super.close()
        AppLog.d(DebugTAG, "Closing IdVerificationViewModel")
        CoroutineScope(Dispatchers.Main).launch {
            lfo.lifecycle.removeObserver(this@IdVerificationViewModel)
        }
    }
}