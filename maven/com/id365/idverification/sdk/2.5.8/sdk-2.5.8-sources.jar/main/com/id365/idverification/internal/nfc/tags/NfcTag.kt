package com.id365.idverification.internal.nfc.tags

import android.nfc.tech.TagTechnology
import com.id365.idverification.internal.utils.CommonUtils.DebugTAG
import com.id365.idverification.internal.logging.AppLog
import java.io.IOException


/**
 * Provides a generic interface for communicating with any NFC Tag, cross-platform
 */
abstract class NfcTag(private val tag: TagTechnology) {
    /**
     * Get the full identifier of this chip
     *
     * @return The high-level identifier
     */
    abstract fun getChip() : String

    /**
     * Establish a connection to the chip
     *
     * @throws IOException when the operation fails for any reason
     */
    @Throws(IOException::class)
    fun connect() {
        tag.connect()
    }

    /**
     * Close the connection to the chip
     *
     * @throws IOException when the operation fails for any reason
     */
    @Throws(IOException::class)
    fun close() {
        try {
            tag.close()
        } catch(se: SecurityException) {
            AppLog.e(DebugTAG, "Unable to close tag: $se", se)
        } catch(e: Exception) {
            AppLog.e(DebugTAG, "Error closing NFC tag connection", e)
        }
    }

    /**
     * Helper function checks if tag is already connected
     */
    fun isConnected() : Boolean {
        return try {
            tag.isConnected
        } catch (se: SecurityException) {
            AppLog.e(DebugTAG, "Failed connecting to tag: $se", se)
            false
        } catch(e: Exception) {
            AppLog.e(DebugTAG, "Error checking NFC tag connected state", e)
            false
        }
    }

    /**
     * Configures a timeout for the NFC chip
     */
    abstract fun setTimeout(timeout: Int)

    /**
     * Send and receive data
     *
     * @param data The data being sent
     * @return The data received from the chip
     */
    @Throws(IOException::class)
    abstract fun transceive(data: ByteArray) : ByteArray

    /**
     * Calls the equivalent function to provide the maximum number of bytes that can be handled
     * by [tag].transceive
     */
    abstract fun getMaxTransceiveLength(): Int

    /**
     * For the tags that provide this function, return ExtendedApduSupport availability.
     * Tag techs that do not provide [isExtendedLengthApduSupported] should return UNKNOWN
     */
    abstract fun isExtendedLengthApduSupported(): ExtendedApduSupport

    /**
     * enum that provides info about ExtendedApduSupport for this tag tech.
     */
    enum class ExtendedApduSupport {
        AVAILABLE,
        UNAVAILABLE,
        UNKNOWN,
    }
}