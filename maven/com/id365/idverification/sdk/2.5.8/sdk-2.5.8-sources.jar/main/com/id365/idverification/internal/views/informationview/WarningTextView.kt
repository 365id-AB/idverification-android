package com.id365.idverification.internal.views.informationview

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

@Composable
internal fun WarningTextView(
    text: String,
    textAlign: TextAlign
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                color = MaterialTheme.colorScheme.surfaceContainer,
                shape = RoundedCornerShape(8.dp)
            )
            .padding(16.dp)
            .testTag("WarningTextView")
    ) {
        // Blue information icon in the top-left corner of the box.
        Icon(
            imageVector = Icons.Default.Info,
            contentDescription = "Information",
            tint = Color(0xff2424ff),
            modifier = Modifier
                .size(32.dp)
                .align(Alignment.TopStart)
                .offset(y = (-4).dp)
        )

        // Text content
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 40.dp)
        ) {
            // Split text into lines and display each one
            val lines = text.split("\n")
            lines.forEachIndexed { index, line ->
                Text(
                    text = line,
                    style = if (index == 0) {
                        MaterialTheme.typography.labelLarge
                    } else {
                        MaterialTheme.typography.bodyLarge
                    },
                    color = if (index == 0) {
                        MaterialTheme.colorScheme.onSurface
                    } else {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    },
                    textAlign = textAlign,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = if (index != lines.lastIndex) 10.dp else 0.dp)
                )
            }
        }
    }
}