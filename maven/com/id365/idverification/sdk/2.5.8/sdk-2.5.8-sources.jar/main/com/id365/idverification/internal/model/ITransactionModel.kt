package com.id365.idverification.internal.model

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import androidx.compose.runtime.MutableState
import com.id365.idverification.contracts.grpc.coordinator.CoordinatorOuterClass.Reason
import com.id365.idverification.errors.IdVerificationException
import com.id365.idverification.internal.communication.AbortReason
import com.id365.idverification.internal.communication.ICommunicator
import com.id365.idverification.internal.communication.Task
import kotlinx.coroutines.Job

/**
 * Interface describing the main model used in the Sdk. Each instance of this model tracks
 * one transaction.
 */
internal interface ITransactionModel {

    /** The Android Application Context. */
    val context: Context

    /** The backing communicator used to talk to the backend */
    val communicator: ICommunicator

    /** The current task to be performed */
    val viewTaskData: MutableState<Task>

    /**
     * Number of tasks the user has already completed
     */
    val completedTasks: MutableState<Int>

    /**
     * Estimated total number of tasks the user will perform
     */
    val estimatedTotalTasks: MutableState<Int>

    /** Whether the communicator is ready for business */
    val communicatorReady: Boolean

    val showInfo: MutableState<Boolean>

    /** Callback for submitting picture to the transaction when ready
     * @param bitmap: The picture submitted to the transaction
     * @param debug: An extra picture submitted only for debugging when debugging is allowed.
     * @param debugRoi: The Region-Of-Interest that was calculated for [debug].
     * @param preview: What was visible in the viewfinder
     * @param manual: Was this picture taken manually or not?
     *
     * @return true if sending a picture, otherwise false
     **/
    fun takePicture(bitmap: Bitmap, debug: Bitmap? = null, debugRoi: Rect? = null, preview: Bitmap? = null, manual: Boolean = false, skipAnalysis: Boolean = false): Boolean

    /**
     * Tell the transactionModel to request the next task
     * @return a job representing the network call
     */
    fun requestNextTask(): Job

    /**
     * Close the transaction, cleaning up any active coroutines
     */
    fun stop(e: Exception? = null)

    /**
     * Network call wrapper that will close the SDK if we encounter communication related issues, such as connection loss or token expiry
     */
    fun commsWrapper(networkCall: suspend () -> Unit): Job
    fun handleError(exc: IdVerificationException)

    /** The "frozen" image to be displayed as a background while processing */
    val frontPreview: MutableState<Bitmap?>
    val backPreview: MutableState<Bitmap?>
    /** Lets the backend know about the aborted transaction */
    fun abortTransactionRequest(reason: AbortReason): Job
}