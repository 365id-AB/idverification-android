package com.id365.idverification

object OtelConfig {
    /// This file is generated during the 'Run Script' Build Phase to add the OpenTelemetry logging endpoint.
    const val OTEL_ENDPOINT = BuildConfig.OTEL_ENDPOINT
    const val OTEL_API_KEY = BuildConfig.OTEL_API_KEY // <-- This is for development, replaced in production.
}