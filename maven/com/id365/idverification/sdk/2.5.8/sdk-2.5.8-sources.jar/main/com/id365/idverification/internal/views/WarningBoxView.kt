package com.id365.idverification.internal.views

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
internal fun WarningBoxView(
    message: String,
    boxBackgroundColor: Color,
    textColor: Color,
    boxRadius: Dp = 25.dp,
) {
    Box(
        modifier = Modifier
            .wrapContentHeight()
            .fillMaxWidth(),
    ) {
        Column(
            modifier = Modifier
                .background(
                    color = boxBackgroundColor,
                    shape = RoundedCornerShape(
                        topStart = boxRadius,
                        topEnd = boxRadius,
                        bottomEnd = boxRadius,
                        bottomStart = boxRadius
                    )
                )
                .padding(all = 8.dp)
                .align(Alignment.Center),
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = message,
                fontWeight = FontWeight.Bold,
                color = textColor,
                fontSize = 18.sp,
                textAlign = TextAlign.Center,
                maxLines = 2
            )
        }
    }
}

@Preview
@Composable
private fun  WarningBoxViewPreview() {
    WarningBoxView(
        message = "Testing",
        boxBackgroundColor = Color.Blue,
        textColor = Color.White
    )
}