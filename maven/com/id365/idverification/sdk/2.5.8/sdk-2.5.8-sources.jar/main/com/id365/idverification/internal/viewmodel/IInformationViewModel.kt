package com.id365.idverification.internal.viewmodel

import androidx.compose.runtime.MutableState
import androidx.compose.ui.text.substring
import com.id365.idverification.IdVerification
import com.id365.idverification.internal.communication.Task
import com.id365.idverification.internal.communication.UserMessage
import com.id365.idverification.internal.integrations.iproov.FacematchState

internal interface  IInformationViewModel {

    /**
     * Controls if this view should be shown or not
     */
    val showInformationView: MutableState<Boolean>

    /**
     * Gets the current task level which decides what text to be shown to the user
     */
    val taskData: MutableState<Task>

    /**
     * Gets the number of tasks the user has already completed
     */
    val completedTasks: MutableState<Int>

    /**
     * Gets the estimated total number of tasks the user will perform
     */
    val estimatedTotalTasks: MutableState<Int>

    /**
     * Called when the user presses the "OK", "Continue", "Retry" button etc.
     */
    var confirmButtonCallback: () -> Unit

    /**
     * If the user decides to dismiss the main view early, this callback should be triggered.
     */
    val cancelButtonCallback: () -> Unit

    /**
     * Gets the document type with which the sdk was started. This impacts the text shown to the user.
     */
    val documentSizeType: IdVerification.DocumentSizeType

    /**
     * Holds the latest state from the facematching/liveness check. Unset on first use
     */
    var iproovState: FacematchState

    /**
     * Contains text from the next task user message. Includes a title, text and type of message.
     */
    val userMessage: UserMessage
        get() {
            return this.taskData.value.message
        }
}

internal data class InformationViewTextFields(
    val userMessage: UserMessage,
    val buttonText: String,
    val cancelText: String = "Cancel"
)