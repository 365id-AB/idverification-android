package com.id365.idverification.internal.communication

/**
 * The reason why a transaction was aborted.
 */
enum class AbortReason {
    Undefined,
    UserCancelled,
    StopSDKCalled,
}