package com.id365.idverification.internal.communication

import android.graphics.Rect
import com.id365.idverification.IdVerificationRequest
import com.id365.idverification.contracts.grpc.coordinator.CoordinatorOuterClass.AbortTransactionReply
import com.id365.idverification.contracts.grpc.coordinator.CoordinatorOuterClass.AbortTransactionRequest
import com.id365.idverification.contracts.grpc.coordinator.CoordinatorOuterClass.Reason
import com.id365.idverification.internal.dida.DidaRequest
import com.id365.idverification.internal.dida.DidaResponse
import com.id365.idverification.internal.integrations.iproov.EnrolUserRequest
import com.id365.idverification.internal.integrations.iproov.EnrolUserResponse
import com.id365.idverification.internal.integrations.iproov.IProovTokenRequest
import com.id365.idverification.internal.integrations.iproov.IProovTokenResponse
import com.id365.idverification.internal.integrations.iproov.ValidateEnrolRequest
import com.id365.idverification.internal.integrations.iproov.ValidateEnrolResponse
import com.id365.idverification.internal.nfc.ProcessRequest
import com.id365.idverification.internal.nfc.ProcessResponse
import io.grpc.StatusException
import kotlinx.coroutines.Job
import java.net.URL

/**
 * Interface to describe how the client will communicate with the coordinator service
 */
internal interface ICommunicator {

    /** The Backend URL this communicator instance communicates with */
    val url: URL

    /** Unique identifier for the local device */
    val vendorId: String

    /** The request used when starting this instance of the SDK */
    val request: IdVerificationRequest

    /**
     * Retrieve a session token for this session. This function *must* be called before the others.
     *
     * @return a Job that will complete with a token if successful. Sdk should close gracefully if the job does not complete successfully.
     */
    @Throws(StatusException::class)
    fun authenticate(): Job

    /**
     *  Get the next task
     *
     *  @param token: The JWT containing stuff
     *  @param previousState: The previous state
     *  @return: A Task
     */
    @Throws(StatusException::class)
    suspend fun nextTaskRequest(state: String = ""): Task

    /**
     * Upload image to frontend for identification
     *
     * @param image: The JPEG image encoded as a byte array
     *
     * @return: True if image was uploaded. False on error.
     */
    @Throws(StatusException::class)
    suspend fun sendImageForIdentification(
        image: ByteArray,
        debug: ByteArray? = null,
        debugRoi: Rect? = null,
        manuallyTriggered: Boolean = false,
        skipAnalysis: Boolean = false
    ): Boolean

    /**
     * Upload Nfc data to the frontend
     *
     * @param processRequest: The data to upload
     *
     * @return: List of commands to run on the Nfc tag
     */
    @Throws(StatusException::class)
    suspend fun processNfc(processRequest: ProcessRequest): ProcessResponse

    /**
     * Sends request to iProovService to enrol a user
     */
    @Throws(StatusException::class)
    suspend fun iProovEnrolUser(request: EnrolUserRequest): EnrolUserResponse

    /**
     * Sends request to iProovService to validate an enrolled user
     */
    @Throws(StatusException::class)
    suspend fun iProovValidateEnrol(request: ValidateEnrolRequest): ValidateEnrolResponse

    /**
     * Sends request to iProovService to request a new token
     */
    @Throws(StatusException::class)
    suspend fun iProovTokenRequest(request: IProovTokenRequest): IProovTokenResponse

    /**
     * Sends request to DIDA to verify a digital ID
     */
    @Throws(StatusException::class)
    suspend fun didaIdentify(request: DidaRequest): DidaResponse

    /**
     * Close the communicator, cleaning up any remaining connections
     */
    fun close()

    /**
     * Letting coordinator know we are abort transaction
     */
    @Throws(StatusException::class)
    suspend fun abortTransactionRequest(reason: AbortReason): AbortTransactionReply
}
