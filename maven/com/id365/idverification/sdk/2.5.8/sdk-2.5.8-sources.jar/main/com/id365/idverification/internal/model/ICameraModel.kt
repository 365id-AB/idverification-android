package com.id365.idverification.internal.model

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import android.util.Size
import android.view.View
import androidx.camera.view.PreviewView.StreamState
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.res.painterResource
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.id365.idverification.R
import java.io.Closeable

/**
 * Describes the interface of our Camera Model.
 */
internal interface ICameraModel: Closeable {
    /** The lifecycle owner for the Camera. */
    val lifecycleOwner: LifecycleOwner

    /** The PreviewView where the camera feed should be rendered to */
    val previewView: View

    /** StreamState for the preview */
    val previewStreamState: LiveData<StreamState>

    /** Size representing an image resolution supported by the camera sensor */
    val cameraCaptureSize: Size

    /** Of each image taken, this is the region analyzed*/
    val regionOfInterest: Rect

    /** The root view dimensions available to the camera preview */
    val rootView: Size

    /** Informs concerned parties whether the camera is running or not */
    val isCameraRunning: MutableLiveData<Boolean>

    /** Lets the model users know if the light is good or not. */
    val luminanceIsAcceptable: MutableState<Boolean>

    /** Sets if the luminance is ok or not. */
    fun setLuminanceIsAcceptable(acceptable: Boolean)

    /** When an analysis use case detects an image, trigger this callback */
    fun detectionCallback(bitmap: Bitmap, debugBitmap: Bitmap?, manual: Boolean, roi: Rect)

    /**
     * Start the camera
     */
    fun start()

    /**
     * Stop the camera
     */
    fun stop()
}


internal fun mockedCameraModel(context: Context): ICameraModel {
    return object : ICameraModel {
        override val lifecycleOwner: LifecycleOwner
            get() = TODO("Not yet implemented")
        override val previewView: View
            get() = ComposeView(context, null, 0).apply {
                setContent {
                    Image(
                        painterResource(id = R.drawable.preview_2),
                        contentDescription = "Preview of taken picture",
                        contentScale = ContentScale.FillHeight,
                        modifier = Modifier
                            .fillMaxSize()
                    )
                }
            }
        val pss = MutableLiveData(StreamState.STREAMING)
        override val previewStreamState: LiveData<StreamState>
            get() = pss
        override val cameraCaptureSize: Size
            get() = TODO("Not yet implemented")
        override val regionOfInterest: Rect
            get() = TODO("Not yet implemented")
        override val rootView: Size
            get() = TODO("Not yet implemented")
        override val isCameraRunning: MutableLiveData<Boolean>
            get() = TODO("Not yet implemented")

        override fun detectionCallback(
            bitmap: Bitmap,
            debugBitmap: Bitmap?,
            manual: Boolean,
            roi: Rect
        ) {
            TODO("Not yet implemented")
        }

        override fun close() {
            // does nothing
        }

        override fun start() {
            // does nothing
        }

        override fun stop() {
            // does nothing
        }

        override fun setLuminanceIsAcceptable(acceptable: Boolean) {
            luminanceIsAcceptable.value = acceptable
        }

        override val luminanceIsAcceptable = mutableStateOf(true)
    }
}