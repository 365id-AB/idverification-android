package com.id365.idverification.internal.viewmodel

import androidx.lifecycle.MutableLiveData

/**
 * Interface to control the visibility of animations
 */
interface IAnimationViewModel {
    /**
     * Should the animation be visible
     */
    val visible: MutableLiveData<Boolean>

    /**
     * Plays the animation [iterations] times. Stops the animation after [duration]
     */
    fun startAndStopAnimation(duration: Long = 5000, iterations: Int = 1)
}