package com.id365.idverification.internal.nfc

import NfcTaskPayload
import android.app.Activity
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.nfc.NfcAdapter
import android.nfc.NfcManager
import android.nfc.Tag
import android.nfc.TagLostException
import android.nfc.tech.IsoDep
import android.nfc.tech.NfcA
import android.nfc.tech.NfcB
import android.os.Build
import android.util.Log
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import com.id365.idverification.internal.utils.CommonUtils.DebugTAG
import com.id365.idverification.internal.core.IdScannerKoinComponent
import com.id365.idverification.R
import com.id365.idverification.contracts.grpc.coordinator.CoordinatorOuterClass
import com.id365.idverification.internal.communication.ICommunicator
import com.id365.idverification.internal.logging.AppLog
import com.id365.idverification.internal.model.ITransactionModel
import com.id365.idverification.internal.nfc.tags.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import org.koin.core.component.get
import org.koin.core.component.inject
import org.koin.core.parameter.parametersOf
import java.io.IOException

/**
 * This implements communication with NFC chips using Android APIs.
 */

internal class NfcProcessor(
    val activity: Activity,
    lfo: LifecycleOwner,
    override val callback: (( message: String, progressPercent: Double) -> Unit),
    override var lifecycleCallback: (() -> Unit)? = null,
    private val nfcAdapter: NfcAdapter? =
        (activity.getSystemService(Context.NFC_SERVICE) as NfcManager).defaultAdapter
) : INfcProcessor, LifecycleEventObserver, IdScannerKoinComponent() {

    private val communicator: ICommunicator by inject()
    private val transaction: ITransactionModel by inject()
    private var latestCommand: ProcessResponse = ProcessResponse()
    private var isActive: Boolean = true
    private var finalized: Boolean = false


    private val nfcSemaphore: Semaphore = Semaphore(1)

    /**
     * For each detected tag, identify the tag and parse if we support it
     */
    internal suspend fun processTag(tag: Tag) = nfcSemaphore.withPermit {
        if (finalized)
            return
        AppLog.i(DebugTAG, "Processing tag $tag")
        for (tech in tag.techList) {
            val processableTag: NfcTag = when (tech) {
                NfcB::class.java.name -> get<NfcTagB>(parameters = { parametersOf(NfcB.get(tag)) })
                NfcA::class.java.name -> get<NfcTagA>(parameters = { parametersOf(NfcA.get(tag)) })
                IsoDep::class.java.name -> get<NfcTagIsoDep>(parameters = {
                    parametersOf(
                        IsoDep.get(
                            tag
                        )
                    )
                })

                else -> {
                    AppLog.w(DebugTAG, "Not processing unsupported tag type $tech")
                    continue
                }
            }
            onChipDetected(processableTag)

            return
        }
        AppLog.e(DebugTAG, "No supported techs available on the NFC chip!")
    }

    init {
        // if NFC is not supported on this device
        if (nfcAdapter == null) {
            AppLog.i(DebugTAG, "Skipping NFC with reason: NfcNotSupported")
            transaction.commsWrapper {
                val response = communicator.processNfc(
                    ProcessRequest(
                        skipReason = SkipReason.NfcNotSupported
                    )
                )
                if (response.isCompleted) {
                    onComplete()
                }
            }
        }

        // Register this to a Lifecycle
        lfo.lifecycle.addObserver(this)
    }


    override fun onUserSkipNfc() {
        isActive = false
        AppLog.i(DebugTAG, "Skipping NFC with reason: UserSkipped")
        transaction.commsWrapper {
            val response = communicator.processNfc(
                ProcessRequest(
                    skipReason = SkipReason.UserSkipped
                )
            )
            if (response.isCompleted) {
                onComplete()
            }
        }
    }


    override fun close() {
        disableNfcForegroundDispatch()
    }

    /**
     * Used for logging
     */
    private fun ByteArray.toHex(): String = joinToString(separator = " ") { eachByte ->
        String.format("%02x", eachByte)
    }

    /**
     * Run a single command against the tag and catch errors
     */
    private fun executeCommand(
        tag: NfcTag,
        request: ChipRequest,
        retries: Int = 3,
        exception: Exception? = null
    ): ByteArray {
        if (retries == 0) {
            throw exception!!
        }
        tag.setTimeout(5000)
        val apduBytes = request.apdu
        AppLog.v(DebugTAG, "Command: ${apduBytes.toHex()}")
        return try {
            if (!tag.isConnected()) {
                AppLog.v(DebugTAG, "Connecting tag")
                tag.connect()
                AppLog.v(DebugTAG, "Tag connected")
            }
            val chipResponse = tag.transceive(apduBytes)
            AppLog.v(DebugTAG, "Response: ${chipResponse.toHex()}")
            chipResponse
        } catch (e: SecurityException) {
            // Do not upload this message to sentry. Known issue with Pixel 7 devices getting "Permission Denial: Tag is out of date"
            Log.e(DebugTAG, "command failed: $e", e)
            tag.close()
            ByteArray(0)
        } catch (e: TagLostException) {
            // This error usually occurs because the user isn't keeping the tag steady and within range of the NFC reader
            Log.e(DebugTAG, "command failed: $e", e)
            tag.close()
            executeCommand(tag, request, retries - 1, e)
        } catch (e: IOException) {
            AppLog.e(DebugTAG, "Command failed: $e", e)
            tag.close()
            executeCommand(tag, request, retries - 1, e)
        } catch (e: Exception) {
            AppLog.e(DebugTAG, "Command failed", e)
            tag.close()
            executeCommand(tag, request, retries - 1, e)
        }
    }

    /**
     * Send a status message back to user interface for showing what is happening
     */
    private fun reportStatus(message: String, progressPercent: Double) {
        callback(message, progressPercent)
    }

    /**
     * When android detects an NFC chip, an intent is generated, sent and caught by the activity
     * who should send the intent here
     */
    override suspend fun resolveIntent(intent: Intent) {
        AppLog.i(DebugTAG, "Handling intent: $intent")
        when (intent.action) {
            NfcAdapter.ACTION_TAG_DISCOVERED -> {
                val tag: Tag? = if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(NfcAdapter.EXTRA_TAG)
                } else {
                    intent.getParcelableExtra(NfcAdapter.EXTRA_TAG, Tag::class.java)
                }
                if (tag != null) {
                    processTag(tag)
                }
            }

            else -> {
                AppLog.w(
                    DebugTAG,
                    "Received unexpected intent (${intent.action}). Is the activity configured correctly?"
                )
            }
        }
    }

    /**
     * When we detect an NFC chip, request commands to be run from the backend.
     * Continue to request more commands to run until the "isCompleted" flag is true.
     *
     * @param tag: The detected tag
     */
    private suspend fun onChipDetected(tag: NfcTag) {
        val detectedChip = tag.getChip()
        var request = ProcessRequest(
            state = latestCommand.state,
            chipStandard = detectedChip,
            extendedApduSupported = tag.isExtendedLengthApduSupported()
        )
        AppLog.d("REQUEST", "REQUEST: $request")
        val job = transaction.commsWrapper {
            if (latestCommand.state.isEmpty())
                latestCommand = communicator.processNfc(request)

            while (!latestCommand.isCompleted && isActive) {
                val responses = try {

                    processRequest(tag, latestCommand)
                } catch(e: IOException) {
                    // Losing connection to the device because of an exception yields no responses.
                    // We do this so we can properly handle the case where we lose contact with NFC
                    // chipset as a result of NFC chip not responding
                    Pair(0, emptyList<Array<Byte>>().toTypedArray())
                }
                request = ProcessRequest(
                    state = latestCommand.state,
                    chipStandard = request.chipStandard,
                    responses = responses.second.toList(),
                    extendedApduSupported = tag.isExtendedLengthApduSupported(),
                )
                // We request the user to retry
                if (responses.first == 0 && !latestCommand.isCompleted) {
                    latestCommand = communicator.processNfc(request)
                    enableNfcForegroundDispatch()
                    reportStatus(
                        activity.getString(R.string._365id_white_information_nfc_subtitle),
                        0.0
                    )
                    break
                }

                if (isActive) {
                    latestCommand = communicator.processNfc(request)
                }
            }
            if (!isActive) {
                onComplete()
            }
        }
        job.invokeOnCompletion {
            if (latestCommand.isCompleted) {
                onComplete()
            }
        }
        job.join()
    }

    /**
     * Called on Nfc process completion, either due to [ProcessResponse.isCompleted] or on
     * backend communication error
     */
    private fun onComplete() {
        disableNfcForegroundDispatch()
        reportStatus("", 1.0)
        if (!finalized) {
            AppLog.d(DebugTAG, "NfcProcessor Requesting next task")
            finalized = true
            transaction.requestNextTask()
            lifecycleCallback?.invoke()
        }
    }

    /**
     * Each request processed will be broken up into individual commands and executed
     * one by one.
     *
     * @param tag: The tag communicated with
     * @param fromServer: The commands currently being processed
     *
     * @return A Pair with number of successfully processed messages and the messages themselves
     */
    private suspend fun processRequest(
        tag: NfcTag,
        fromServer: ProcessResponse
    ): Pair<Int, Array<Array<Byte>>> {
        val nRequests = fromServer.requests.size
        val responses = mutableListOf<Array<Byte>>()
        for ((index, request: ChipRequest) in fromServer.requests.withIndex()) {
            if (!isActive)
                return Pair(0, emptyArray())
            AppLog.d(DebugTAG, "Status: ${fromServer.status}, $index/$nRequests")
            reportStatus(
                activity.getString(R.string._365id_read_nfc_caption_scanning),
                fromServer.progressPercent
            )

            val response = runCommand(tag, request)
//            AppLog.d("nfc process message", fromServer.status)
//            AppLog.d("APDU COMMAND", request.apdu.toString())
            if (!response.first) {
                AppLog.e(DebugTAG, "Incorrect tag response!")
                return if (response.second.isNotEmpty()) {
                    responses.add(response.second)
                    AppLog.d(DebugTAG, "sending incomplete response to NfcService")
                    Pair(index, responses.toTypedArray())
                } else {
                    Pair(index, responses.toTypedArray())
                }
            } else {
                responses.add(response.second)
            }
        }
        reportStatus(
            activity.getString(R.string._365id_read_nfc_caption_scanning),
            fromServer.progressPercent
        )
        return Pair(nRequests, responses.toTypedArray())
    }

    /**
     * Run one NFC command and verify the response is valid.
     *
     * @param tag: The tag to communicate with
     * @param request: The request containing the apdu command to run, sw1 and sw2 checksum bytes
     *
     * @return: The response if it was OK, otherwise empty
     */
    private fun runCommand(tag: NfcTag, request: ChipRequest): Pair<Boolean, Array<Byte>> {
        val response = executeCommand(tag, request).toTypedArray()
        val ok = verifyResponse(response, listOf(request.sw1.toByte(), request.sw2.toByte()))
        return Pair(ok, response)
    }

    /**
     * Verify a single response item against checksums
     * @param response: The response to verify
     * @param sw1: First checksum byte
     * @param sw2: Second checksum byte
     *
     * @return: true if OK, otherwise false
     */
    private fun verifyResponse(response: Array<Byte>, expectedStatus: List<Byte>): Boolean {
        if (response.size < 2) return false
        val responseStatus = response.takeLast(expectedStatus.size)

        val incorrectChecksum = responseStatus != expectedStatus
        if (incorrectChecksum) {
            // We expect this to fail sometimes when we encounter unsupported NFC tags. So we don't log to sentry here.
            AppLog.e(DebugTAG, "Unexpected response. Got $responseStatus, expected $expectedStatus")
            return false
        }
        return true
    }

    /**
     * Register to the system that we want this activity to receive NFC intents
     */
    private fun enableNfcForegroundDispatch() {
        sdkHasWindowFocus {
            try {
                val intent =
                    Intent(activity, activity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
                // requestCode can be made unique if we want to manage and track many requests...
                val rc = 0
                val flags =
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE
                    else 0
                val pendingIntent = PendingIntent.getActivity(activity, rc, intent, flags)
                nfcAdapter?.enableForegroundDispatch(activity, pendingIntent, null, null)
                AppLog.i(DebugTAG, "NFC foreground dispatch enabled")
            } catch (ex: IllegalStateException) {
                AppLog.e(DebugTAG, "Error enabling NFC foreground dispatch", ex)
            } catch (e: Exception) {
                AppLog.e(DebugTAG, "Error enabling NFC foreground dispatch", e)
            }
        }
    }

    /**
     * Unregister to the system so that we no longer receive NFC intents
     */
    private fun disableNfcForegroundDispatch() {
        sdkHasWindowFocus {
            try {
                nfcAdapter?.disableForegroundDispatch(activity)
                AppLog.i(DebugTAG, "NFC foreground dispatch disabled")
            } catch (ex: IllegalStateException) {
                AppLog.e(DebugTAG, "Error disabling NFC foreground dispatch", ex)
            } catch (e: Exception) {
                AppLog.e(DebugTAG, "Error disabling NFC foreground dispatch", e)
            }
        }
    }

    /**
     * This function makes sure that the activity has window focus.
     * When lifecycle events are involved 'hasWindowFocus()' can return wrong values.
     * Here we use a delay to make it more reliable.
     *
     * @param hasWindowFocusCallback: Only called if the window has focus.
     */
    private fun sdkHasWindowFocus(hasWindowFocusCallback: suspend () -> Unit) {
        CoroutineScope(Dispatchers.Main).launch {
            delay(1000)
            if (!activity.hasWindowFocus()) return@launch
            hasWindowFocusCallback()
        }
    }

    /**
     * LifecycleEventObserver implementation. This is used to make sure we receive NFC events
     * even if the user "pauses" the Nfc task by switching away from this activity, turning the
     * phone screen off etc.
     *
     * @param source: The Lifecycle owner that will generate events. Typically NfcView.
     * @param event: The event generated.
     */
    override fun onStateChanged(source: LifecycleOwner, event: Lifecycle.Event) {
        when (event) {
            Lifecycle.Event.ON_RESUME -> enableNfcForegroundDispatch()
            Lifecycle.Event.ON_PAUSE -> disableNfcForegroundDispatch()
            else -> {} /* no-op */
        }
    }
}