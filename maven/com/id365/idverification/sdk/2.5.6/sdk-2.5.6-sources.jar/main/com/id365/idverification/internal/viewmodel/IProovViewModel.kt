package com.id365.idverification.internal.viewmodel

import android.app.Activity
import androidx.compose.material3.ColorScheme
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.graphics.toArgb
import com.id365.idverification.BuildConfig
import com.id365.idverification.R
import com.id365.idverification.internal.communication.AbortReason
import com.id365.idverification.internal.communication.SessionToken
import com.id365.idverification.internal.core.IdScannerKoinComponent
import com.id365.idverification.internal.core.SdkContext
import com.id365.idverification.internal.integrations.iproov.FacematchState
import com.id365.idverification.internal.integrations.iproov.IProovProcessor
import com.id365.idverification.internal.logging.AppLog
import com.id365.idverification.internal.model.ITransactionModel
import com.id365.idverification.internal.ui.theme.AppColors
import com.id365.idverification.internal.utils.CommonUtils.DebugTAG
import com.iproov.sdk.api.IProov
import com.iproov.sdk.api.exception.IProovException
import com.iproov.sdk.api.exception.NetworkException
import org.koin.core.component.get
import org.koin.core.component.inject
import org.koin.core.parameter.parametersOf
import java.io.Closeable

/**
 * This is the ViewModel for the IProovView. It handles some of the visual elements of the IProov implementation.
 */
internal class IProovViewModel(
    val activity: Activity, // Reference to the current activity,
    val colors: ColorScheme,
) : IIProovViewModel, IdScannerKoinComponent(), Closeable {

    val transactionModel: ITransactionModel by inject()
    private val alertBox: IAlertBoxViewModel by inject()
    private var iProovSession: IProov.Session? = null

    private val callback = {
        iproovToken: String,
        feedback: FacematchState ->
        when(feedback) {
            FacematchState.UNSET -> startIProov(iproovToken)
            else -> {
                showInformation.value = true
                val informationViewModel = get<IInformationViewModel>()
                AppLog.d(DebugTAG, "Feedback from IProov: $feedback ${showInformation.value}")
                informationViewModel.iproovState = FacematchState.FAILED
                true
            }
        }
    }

    private val processor: IProovProcessor =
        get(parameters = { parametersOf(get<SessionToken>().transactionId, callback) })

    override val animationShouldPlay: MutableState<Boolean>
        get() = processor.animate

    override val showLoading: MutableState<Boolean>
        get() = processor.showLoading
    override val showInformation = mutableStateOf(false)

    override val buttonCb: () -> Unit = {
        showInformation.value = false
        processor.retryIProov()
    }

    override fun startIProov(token: String) {
        val options = getIProovOptions(colors)

        try {
            AppLog.d(DebugTAG, "Starting IProov...")

            var session = IProov.createSession(
                activity, // Reference to current activity
                "wss://eu.rp.secure.iproov.me/ws", // Streaming URL
                token, // iProov token
                options // Optional
            )

            processor.registerSession(session)

        } catch (ex: IProovException) {
            // Handle immediate failures: MultiWindowUnsupportedException, ListenerNotRegisteredException or CaptureAlreadyActiveException
            AppLog.e(DebugTAG, "Exception during IProov: $ex")
        } catch (ex: NetworkException) {
            AppLog.e(DebugTAG, "Network Exception during IProov: $ex")
            alertBox.hide()
        } catch (e: Exception) {
            AppLog.e(DebugTAG, "Exception when starting IProov", e)
        }
    }

    override fun close() {
        super.close()
        processor.close()
    }

    companion object {
        /**
         * Configure IProov options
         */
        internal fun getIProovOptions(
            colors: ColorScheme
        ): IProov.Options = IProov.Options().apply {
            title = ""
            titleTextColor = colors.onSurface.toArgb()
            closeButton = IProov.Options.CloseButton(
                icon = IProov.Options.Icon.ResourceIcon(R.drawable.xmark),
                // Tint color applied to the close button.
                colorTint = colors.inverseOnSurface.toArgb()
            )

            // Color applied the area outside the oval.
            surroundColor = colors.inverseSurface.copy(alpha = .65F).toArgb()

            // Prompt instruction/container box
            promptTextColor = colors.onSurface.toArgb()
            promptBackgroundColor = colors.surface.toArgb()

            // Direct visualization of the users face
            filter = IProov.Options.Filter.NaturalFilter(style = IProov.NaturalStyle.CLEAR)

            // Color for oval stroke after LA scan completes.
            livenessAssurance.completedOvalStrokeColor = AppColors.green.toArgb()
            // Color for oval stroke during LA scan.
            livenessAssurance.ovalStrokeColor = colors.inverseOnSurface.toArgb()

            logo = null
            enableScreenshots = BuildConfig.DEBUG
            orientation = IProov.Orientation.PORTRAIT
            timeoutSecs = 10
            camera = IProov.Camera.FRONT

        }
    }
}
